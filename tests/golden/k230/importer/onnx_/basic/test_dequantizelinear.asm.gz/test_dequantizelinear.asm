# case: test_dequantizelinear[None-scale0-2-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 1311
mfu_act1_conf_deq x18, x0, u8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# case: test_dequantizelinear[None-scale0-3-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 1311
mfu_act1_conf_deq x18, x0, i8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, i8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, i8, 0
mfu_act1_conf_deq x19, x0, i8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# case: test_dequantizelinear[zero_point1-scale0-2-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 1311
addi x19, x0, 100
mfu_act1_conf_deq x18, x19, u8, 0
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x24, x0, 256
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 512
add x25, x27, x25
lui x26, 131072
addi x26, x26, 512
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x18, x19, u8, 0
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 65536
addi x28, x28, 1024
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# case: test_dequantizelinear[zero_point2-scale0-2-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 1311
mfu_act1_conf_deq x18, x0, u8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# case: test_dequantizelinear[zero_point2-scale0-3-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 1311
mfu_act1_conf_deq x18, x0, i8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, i8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, i8, 0
mfu_act1_conf_deq x19, x0, i8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
