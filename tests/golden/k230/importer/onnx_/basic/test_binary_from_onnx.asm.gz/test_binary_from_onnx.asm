# case: test_binary_from_onnx[in_shape0-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape0-1-Div]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape0-1-Max]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape0-1-Min]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape0-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape0-1-Pow]
# case: test_binary_from_onnx[in_shape0-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape1-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape1-1-Div]
# case: test_binary_from_onnx[in_shape1-1-Max]
# case: test_binary_from_onnx[in_shape1-1-Min]
# case: test_binary_from_onnx[in_shape1-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape1-1-Pow]
# case: test_binary_from_onnx[in_shape1-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 160
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 1536
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 128
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 428
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65537
addi x23, x23, 3072
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 768
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x30, x0, 12
addi x28, x0, 28
add x28, x30, x28
lui x29, 131072
addi x29, x29, 64
l2_load_w x29, x28, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x29
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x3, x0, 12
addi x31, x0, 70
add x31, x3, x31
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x31, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
addi x4, x0, 48
mfu_act1_conf_src2 x4, ss2, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x5, 2
addi x5, x5, 3076
mfu_act1_conf_deq x5, x0, u8, 0
addi x7, x0, 255
mfu_act1_conf_deq x22, x7, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x8, x0, 4
ccr_decl x8
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x2
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x9, ss6
end x0
# case: test_binary_from_onnx[in_shape10-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape10-1-Div]
# case: test_binary_from_onnx[in_shape10-1-Max]
# case: test_binary_from_onnx[in_shape10-1-Min]
# case: test_binary_from_onnx[in_shape10-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape10-1-Pow]
# case: test_binary_from_onnx[in_shape10-1-Sub]
# case: test_binary_from_onnx[in_shape11-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape11-1-Div]
# case: test_binary_from_onnx[in_shape11-1-Max]
# case: test_binary_from_onnx[in_shape11-1-Min]
# case: test_binary_from_onnx[in_shape11-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape11-1-Pow]
# case: test_binary_from_onnx[in_shape11-1-Sub]
# case: test_binary_from_onnx[in_shape12-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape12-1-Div]
# case: test_binary_from_onnx[in_shape12-1-Max]
# case: test_binary_from_onnx[in_shape12-1-Min]
# case: test_binary_from_onnx[in_shape12-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape12-1-Pow]
# case: test_binary_from_onnx[in_shape12-1-Sub]
# case: test_binary_from_onnx[in_shape13-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape13-1-Div]
# case: test_binary_from_onnx[in_shape13-1-Max]
# case: test_binary_from_onnx[in_shape13-1-Min]
# case: test_binary_from_onnx[in_shape13-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape13-1-Pow]
# case: test_binary_from_onnx[in_shape13-1-Sub]
# case: test_binary_from_onnx[in_shape14-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape14-1-Div]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape14-1-Max]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape14-1-Min]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape14-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape14-1-Pow]
# case: test_binary_from_onnx[in_shape14-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 51
mmu_conf x7, x6, 4
addi x8, x0, 256
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3073
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape15-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x1, ss6
ss_pack_stride x7, x7, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss0
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x7, x1, ss7
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss0
mfu_act1_conf_src2 x1, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape15-1-Div]
# case: test_binary_from_onnx[in_shape15-1-Max]
# case: test_binary_from_onnx[in_shape15-1-Min]
# case: test_binary_from_onnx[in_shape15-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x1, ss6
ss_pack_stride x7, x7, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss0
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x7, x1, ss7
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss0
mfu_act1_conf_src2 x1, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape15-1-Pow]
# case: test_binary_from_onnx[in_shape15-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 48
mmu_conf x1, x2, 1
addi x3, x0, 64
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 68
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 69
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 96
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 512
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 64
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 481
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65536
addi x23, x23, 1024
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 256
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x29, x0, 12
addi x27, x0, 28
add x27, x29, x27
lui x28, 131072
addi x28, x28, 32
l2_load_w x28, x27, x15
ss_pack_stride x6, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x28
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x2, x0, 12
addi x30, x0, 42
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x15
ss_pack_stride x6, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x6, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x1, ss2, 1, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x3, 2
addi x3, x3, 3076
mfu_act1_conf_deq x3, x0, u8, 0
addi x4, x0, 255
mfu_act1_conf_deq x22, x4, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x5, x0, 4
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x31
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x8, x0, 8
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x9, ss6
end x0
# case: test_binary_from_onnx[in_shape16-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x1, ss6
ss_pack_stride x7, x7, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss0
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x7, x1, ss7
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss0
mfu_act1_conf_src2 x1, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape16-1-Div]
# case: test_binary_from_onnx[in_shape16-1-Max]
# case: test_binary_from_onnx[in_shape16-1-Min]
# case: test_binary_from_onnx[in_shape16-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x1, ss6
ss_pack_stride x7, x7, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss0
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x7, x1, ss7
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss0
mfu_act1_conf_src2 x1, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape16-1-Pow]
# case: test_binary_from_onnx[in_shape16-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 48
mmu_conf x1, x2, 1
addi x3, x0, 64
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 68
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 69
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 96
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 512
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 64
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 503
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65536
addi x23, x23, 1024
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 256
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x29, x0, 12
addi x27, x0, 28
add x27, x29, x27
lui x28, 131072
addi x28, x28, 32
l2_load_w x28, x27, x15
ss_pack_stride x6, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x28
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x2, x0, 12
addi x30, x0, 42
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x15
ss_pack_stride x6, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x6, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x1, ss2, 1, l2
ss_pack_shape x6, x6, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x3, 2
addi x3, x3, 3075
mfu_act1_conf_deq x3, x0, u8, 0
addi x4, x0, 255
mfu_act1_conf_deq x22, x4, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x5, x0, 4
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x31
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x8, x0, 8
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x9, ss6
end x0
# case: test_binary_from_onnx[in_shape17-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape17-1-Div]
# case: test_binary_from_onnx[in_shape17-1-Max]
# case: test_binary_from_onnx[in_shape17-1-Min]
# case: test_binary_from_onnx[in_shape17-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape17-1-Pow]
# case: test_binary_from_onnx[in_shape17-1-Sub]
# case: test_binary_from_onnx[in_shape18-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape18-1-Div]
# case: test_binary_from_onnx[in_shape18-1-Max]
# case: test_binary_from_onnx[in_shape18-1-Min]
# case: test_binary_from_onnx[in_shape18-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 512
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape18-1-Pow]
# case: test_binary_from_onnx[in_shape18-1-Sub]
# case: test_binary_from_onnx[in_shape19-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x11, x0, x15
addi x20, x0, 21
l2_load_w_conf x20, x20, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
addi x24, x0, 768
ss_pack_stride x7, x7, x24, ss6
ss_pack_stride x7, x7, x24, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x5, x1, x1, ss1
ss_pack_stride x5, x1, x1, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x5, ss5, 0, l2
mfu_act1_conf_src1 x24, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_dest x24, ss2
lui x28, 2
addi x28, x28, 3073
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x26, x22
ss_pack_stride x7, x7, x24, ss7
ss_pack_stride x7, x7, x24, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x11, ss0
end x0
# case: test_binary_from_onnx[in_shape19-1-Div]
# case: test_binary_from_onnx[in_shape19-1-Max]
# case: test_binary_from_onnx[in_shape19-1-Min]
# case: test_binary_from_onnx[in_shape19-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x11, x0, x15
addi x20, x0, 21
l2_load_w_conf x20, x20, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
addi x24, x0, 768
ss_pack_stride x7, x7, x24, ss6
ss_pack_stride x7, x7, x24, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x5, x1, x1, ss1
ss_pack_stride x5, x1, x1, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x5, ss5, 0, l2
mfu_act1_conf_src1 x24, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_dest x24, ss2
lui x28, 2
addi x28, x28, 3075
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x26, x22
ss_pack_stride x7, x7, x24, ss7
ss_pack_stride x7, x7, x24, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x11, ss0
end x0
# case: test_binary_from_onnx[in_shape19-1-Pow]
# case: test_binary_from_onnx[in_shape19-1-Sub]
# case: test_binary_from_onnx[in_shape2-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape2-1-Div]
# case: test_binary_from_onnx[in_shape2-1-Max]
# case: test_binary_from_onnx[in_shape2-1-Min]
# case: test_binary_from_onnx[in_shape2-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape2-1-Pow]
# case: test_binary_from_onnx[in_shape2-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 160
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 1536
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 128
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 515
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65537
addi x23, x23, 3072
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 768
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x30, x0, 12
addi x28, x0, 28
add x28, x30, x28
lui x29, 131072
addi x29, x29, 64
l2_load_w x29, x28, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x29
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x3, x0, 12
addi x31, x0, 70
add x31, x3, x31
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x31, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
addi x4, x0, 48
mfu_act1_conf_src2 x4, ss2, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x5, 2
addi x5, x5, 3076
mfu_act1_conf_deq x5, x0, u8, 0
addi x7, x0, 255
mfu_act1_conf_deq x22, x7, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x8, x0, 4
ccr_decl x8
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x2
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x9, ss6
end x0
# case: test_binary_from_onnx[in_shape20-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x11, x0, x15
addi x20, x0, 21
l2_load_w_conf x20, x20, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
addi x24, x0, 768
ss_pack_stride x7, x7, x24, ss6
ss_pack_stride x7, x7, x24, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x5, x1, x1, ss1
ss_pack_stride x5, x1, x1, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x5, ss5, 0, l2
mfu_act1_conf_src1 x24, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_dest x24, ss2
lui x28, 2
addi x28, x28, 3075
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x26, x22
ss_pack_stride x7, x7, x24, ss7
ss_pack_stride x7, x7, x24, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x11, ss0
end x0
# case: test_binary_from_onnx[in_shape20-1-Div]
# case: test_binary_from_onnx[in_shape20-1-Max]
# case: test_binary_from_onnx[in_shape20-1-Min]
# case: test_binary_from_onnx[in_shape20-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
addi x9, x0, 256
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x7, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x11, x0, x15
addi x20, x0, 21
l2_load_w_conf x20, x20, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
addi x24, x0, 768
ss_pack_stride x7, x7, x24, ss6
ss_pack_stride x7, x7, x24, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x7, x1, x1, ss3
ss_pack_stride x5, x1, x1, ss1
ss_pack_stride x5, x1, x1, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x1, x1, ss5
mfu_act1_conf_src2 x5, ss5, 0, l2
mfu_act1_conf_src1 x24, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x5, x1, x1, ss2
mfu_act1_conf_dest x24, ss2
lui x28, 2
addi x28, x28, 3075
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x26, x22
ss_pack_stride x7, x7, x24, ss7
ss_pack_stride x7, x7, x24, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x7, x7, x7, x24, ss0
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x11, ss0
end x0
# case: test_binary_from_onnx[in_shape20-1-Pow]
# case: test_binary_from_onnx[in_shape20-1-Sub]
# case: test_binary_from_onnx[in_shape21-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2970
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape21-1-Div]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2614
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape21-1-Max]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2240
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape21-1-Min]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2853
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape21-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2705
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape21-1-Pow]
# case: test_binary_from_onnx[in_shape21-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape22-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
mfu_act1_conf_stride ss1, ss5, ss5
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_src2 x7, ss6, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_dest x1, ss6
lui x26, 2
addi x26, x26, 2880
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape22-1-Div]
# case: test_binary_from_onnx[in_shape22-1-Max]
# case: test_binary_from_onnx[in_shape22-1-Min]
# case: test_binary_from_onnx[in_shape22-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
mfu_act1_conf_stride ss1, ss5, ss5
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_src2 x7, ss6, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_dest x1, ss6
lui x26, 2
addi x26, x26, 2382
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape22-1-Pow]
# case: test_binary_from_onnx[in_shape22-1-Sub]
# case: test_binary_from_onnx[in_shape23-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
mfu_act1_conf_stride ss1, ss5, ss5
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_src2 x7, ss6, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_dest x1, ss6
lui x26, 2
addi x26, x26, 3075
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape23-1-Div]
# case: test_binary_from_onnx[in_shape23-1-Max]
# case: test_binary_from_onnx[in_shape23-1-Min]
# case: test_binary_from_onnx[in_shape23-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
mfu_act1_conf_stride ss1, ss5, ss5
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_src2 x7, ss6, 1, l2
ss_pack_shape x7, x7, x7, x1, ss6
mfu_act1_conf_dest x1, ss6
lui x26, 2
addi x26, x26, 2960
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss5
ss_pack_stride x7, x7, x1, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss6
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape23-1-Pow]
# case: test_binary_from_onnx[in_shape23-1-Sub]
# case: test_binary_from_onnx[in_shape24-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2994
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape24-1-Div]
# case: test_binary_from_onnx[in_shape24-1-Max]
# case: test_binary_from_onnx[in_shape24-1-Min]
# case: test_binary_from_onnx[in_shape24-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2926
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape24-1-Pow]
# case: test_binary_from_onnx[in_shape24-1-Sub]
# case: test_binary_from_onnx[in_shape25-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 3032
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape25-1-Div]
# case: test_binary_from_onnx[in_shape25-1-Max]
# case: test_binary_from_onnx[in_shape25-1-Min]
# case: test_binary_from_onnx[in_shape25-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2900
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape25-1-Pow]
# case: test_binary_from_onnx[in_shape25-1-Sub]
# case: test_binary_from_onnx[in_shape26-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2787
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape26-1-Div]
# case: test_binary_from_onnx[in_shape26-1-Max]
# case: test_binary_from_onnx[in_shape26-1-Min]
# case: test_binary_from_onnx[in_shape26-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2803
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape26-1-Pow]
# case: test_binary_from_onnx[in_shape26-1-Sub]
# case: test_binary_from_onnx[in_shape27-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2749
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape27-1-Div]
# case: test_binary_from_onnx[in_shape27-1-Max]
# case: test_binary_from_onnx[in_shape27-1-Min]
# case: test_binary_from_onnx[in_shape27-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x7, ss0
ss_pack_stride x7, x7, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x7, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x7, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x7, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x7, ss2
mfu_act1_conf_src2 x23, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2824
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape27-1-Pow]
# case: test_binary_from_onnx[in_shape27-1-Sub]
# case: test_binary_from_onnx[in_shape28-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 3043
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape28-1-Div]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 3064
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape28-1-Max]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 3058
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape28-1-Min]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 3038
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape28-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 3052
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape28-1-Pow]
# case: test_binary_from_onnx[in_shape28-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 2969
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_binary_from_onnx[in_shape29-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x7, x1, ss4
l2_load_conf ss4, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss2
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
mfu_act1_conf_stride ss4, ss4, ss4
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x26, 2
addi x26, x26, 3074
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape29-1-Div]
# case: test_binary_from_onnx[in_shape29-1-Max]
# case: test_binary_from_onnx[in_shape29-1-Min]
# case: test_binary_from_onnx[in_shape29-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x7, x1, ss4
l2_load_conf ss4, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss2
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
mfu_act1_conf_stride ss4, ss4, ss4
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x26, 2
addi x26, x26, 3071
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape29-1-Pow]
# case: test_binary_from_onnx[in_shape29-1-Sub]
# case: test_binary_from_onnx[in_shape3-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3075
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape3-1-Div]
# case: test_binary_from_onnx[in_shape3-1-Max]
# case: test_binary_from_onnx[in_shape3-1-Min]
# case: test_binary_from_onnx[in_shape3-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape3-1-Pow]
# case: test_binary_from_onnx[in_shape3-1-Sub]
# case: test_binary_from_onnx[in_shape30-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x7, x1, ss4
l2_load_conf ss4, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss2
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
mfu_act1_conf_stride ss4, ss4, ss4
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x26, 2
addi x26, x26, 3062
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape30-1-Div]
# case: test_binary_from_onnx[in_shape30-1-Max]
# case: test_binary_from_onnx[in_shape30-1-Min]
# case: test_binary_from_onnx[in_shape30-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 50
mmu_conf x5, x4, 3
addi x6, x0, 52
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 53
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 131072
addi x18, x18, 32
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x7, x1, ss4
l2_load_conf ss4, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss2
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
mfu_act1_conf_stride ss4, ss4, ss4
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x1, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x26, 2
addi x26, x26, 3011
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x24, x21
ss_pack_stride x7, x7, x1, ss4
ss_pack_stride x7, x7, x1, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape30-1-Pow]
# case: test_binary_from_onnx[in_shape30-1-Sub]
# case: test_binary_from_onnx[in_shape31-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 3069
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape31-1-Div]
# case: test_binary_from_onnx[in_shape31-1-Max]
# case: test_binary_from_onnx[in_shape31-1-Min]
# case: test_binary_from_onnx[in_shape31-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 3071
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape31-1-Pow]
# case: test_binary_from_onnx[in_shape31-1-Sub]
# case: test_binary_from_onnx[in_shape32-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 3059
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape32-1-Div]
# case: test_binary_from_onnx[in_shape32-1-Max]
# case: test_binary_from_onnx[in_shape32-1-Min]
# case: test_binary_from_onnx[in_shape32-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
mmu_conf x3, x2, 2
addi x4, x0, 80
addi x5, x0, 2
mmu_conf x4, x5, 3
addi x6, x0, 82
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 83
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 256
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 28
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x7, x1, x1, ss7
ss_pack_stride x7, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x1, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x7, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x27, 2
addi x27, x27, 2997
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x28, x0, 4
ccr_decl x28
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape32-1-Pow]
# case: test_binary_from_onnx[in_shape32-1-Sub]
# case: test_binary_from_onnx[in_shape33-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
addi x27, x0, 48
mfu_act1_conf_src2 x27, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x28, 2
addi x28, x28, 3063
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape33-1-Div]
# case: test_binary_from_onnx[in_shape33-1-Max]
# case: test_binary_from_onnx[in_shape33-1-Min]
# case: test_binary_from_onnx[in_shape33-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
addi x27, x0, 48
mfu_act1_conf_src2 x27, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x28, 2
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape33-1-Pow]
# case: test_binary_from_onnx[in_shape33-1-Sub]
# case: test_binary_from_onnx[in_shape34-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
addi x27, x0, 48
mfu_act1_conf_src2 x27, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x28, 2
addi x28, x28, 3027
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape34-1-Div]
# case: test_binary_from_onnx[in_shape34-1-Max]
# case: test_binary_from_onnx[in_shape34-1-Min]
# case: test_binary_from_onnx[in_shape34-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 3
mmu_conf x4, x5, 3
addi x6, x0, 211
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 212
mmu_conf x8, x7, 5
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 1536
mfu_act1_compute x18, x10, x0, x14
addi x19, x0, 21
l2_load_w_conf x19, x19, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x16
addi x23, x0, 768
ss_pack_stride x7, x7, x23, ss4
ss_pack_stride x7, x7, x23, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss6
ss_pack_stride x7, x7, x1, ss1
ss_pack_stride x5, x1, x1, ss7
ss_pack_stride x5, x1, x1, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x1, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x1, ss2
addi x27, x0, 48
mfu_act1_conf_src2 x27, ss2, 0, l2
mfu_act1_conf_src1 x23, x7, x7, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_src2 x7, ss0, 1, l2
ss_pack_shape x7, x5, x1, x1, ss0
mfu_act1_conf_dest x23, ss0
lui x28, 2
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x29, x0, 4
ccr_decl x29
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x25, x21
ss_pack_stride x7, x7, x23, ss5
ss_pack_stride x7, x7, x23, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x7, x7, x7, x23, ss6
ccr_decl x7
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x10, ss6
end x0
# case: test_binary_from_onnx[in_shape34-1-Pow]
# case: test_binary_from_onnx[in_shape34-1-Sub]
# case: test_binary_from_onnx[in_shape4-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape4-1-Div]
# case: test_binary_from_onnx[in_shape4-1-Max]
# case: test_binary_from_onnx[in_shape4-1-Min]
# case: test_binary_from_onnx[in_shape4-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
addi x25, x0, 256
ss_pack_stride x8, x8, x25, ss6
ss_pack_stride x8, x8, x25, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x1, x1, ss1
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x25, x8, x8, 1, l2
ss_pack_shape x8, x8, x1, x1, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x27, x23
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary_from_onnx[in_shape4-1-Pow]
# case: test_binary_from_onnx[in_shape4-1-Sub]
# case: test_binary_from_onnx[in_shape5-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape5-1-Div]
# case: test_binary_from_onnx[in_shape5-1-Max]
# case: test_binary_from_onnx[in_shape5-1-Min]
# case: test_binary_from_onnx[in_shape5-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape5-1-Pow]
# case: test_binary_from_onnx[in_shape5-1-Sub]
# case: test_binary_from_onnx[in_shape6-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape6-1-Div]
# case: test_binary_from_onnx[in_shape6-1-Max]
# case: test_binary_from_onnx[in_shape6-1-Min]
# case: test_binary_from_onnx[in_shape6-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary_from_onnx[in_shape6-1-Pow]
# case: test_binary_from_onnx[in_shape6-1-Sub]
# case: test_binary_from_onnx[in_shape7-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape7-1-Div]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape7-1-Max]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape7-1-Min]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape7-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape7-1-Pow]
# case: test_binary_from_onnx[in_shape7-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_binary_from_onnx[in_shape8-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape8-1-Div]
# case: test_binary_from_onnx[in_shape8-1-Max]
# case: test_binary_from_onnx[in_shape8-1-Min]
# case: test_binary_from_onnx[in_shape8-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape8-1-Pow]
# case: test_binary_from_onnx[in_shape8-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 160
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 1536
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 128
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 514
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65537
addi x23, x23, 3072
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 768
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x30, x0, 12
addi x28, x0, 28
add x28, x30, x28
lui x29, 131072
addi x29, x29, 64
l2_load_w x29, x28, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x29
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x3, x0, 12
addi x31, x0, 70
add x31, x3, x31
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x31, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
addi x4, x0, 48
mfu_act1_conf_src2 x4, ss2, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x5, 2
addi x5, x5, 3075
mfu_act1_conf_deq x5, x0, u8, 0
addi x7, x0, 255
mfu_act1_conf_deq x22, x7, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x8, x0, 4
ccr_decl x8
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x2
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x9, ss6
end x0
# case: test_binary_from_onnx[in_shape9-1-Add]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape9-1-Div]
# case: test_binary_from_onnx[in_shape9-1-Max]
# case: test_binary_from_onnx[in_shape9-1-Min]
# case: test_binary_from_onnx[in_shape9-1-Mul]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 144
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 148
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 149
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x18
ss_pack_stride x8, x8, x1, ss6
ss_pack_stride x8, x8, x1, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x1, ss0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x8, x8, x1, ss7
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss7, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x1, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x1, ss0
addi x28, x0, 48
mfu_act1_conf_src2 x28, ss0, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x21, x26, x23
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary_from_onnx[in_shape9-1-Pow]
# case: test_binary_from_onnx[in_shape9-1-Sub]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 160
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 1536
mfu_act1_compute x17, x9, x0, x13
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 12
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 128
l2_load_w x20, x19, x15
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x22, 2
addi x22, x22, 492
mfu_act1_conf_deq x22, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x23, 65537
addi x23, x23, 3072
mfu_act1_compute x23, x17, x0, x20
addi x24, x0, 768
ss_pack_stride x6, x6, x24, ss4
ss_pack_stride x6, x6, x24, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_set 0, 1
lw x26, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_load x9, x25, ss6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x30, x0, 12
addi x28, x0, 28
add x28, x30, x28
lui x29, 131072
addi x29, x29, 64
l2_load_w x29, x28, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x17, x9, x0, x29
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x3, x0, 12
addi x31, x0, 70
add x31, x3, x31
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x31, x15
ss_pack_stride x18, x1, x1, ss7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x18, x1, x1, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x24, x6, x6, 0, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x1, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
addi x4, x0, 48
mfu_act1_conf_src2 x4, ss2, 1, l2
ss_pack_shape x6, x18, x1, x1, ss0
mfu_act1_conf_dest x24, ss0
lui x5, 2
addi x5, x5, 3076
mfu_act1_conf_deq x5, x0, u8, 0
addi x7, x0, 255
mfu_act1_conf_deq x22, x7, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x8, x0, 4
ccr_decl x8
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x17, x23, x2
ss_pack_stride x6, x6, x24, ss5
ss_pack_stride x6, x6, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x24, ss6
ccr_decl x6
ccr_clr 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x9, ss6
end x0
