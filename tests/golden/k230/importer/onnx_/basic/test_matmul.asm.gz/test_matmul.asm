# case: test_matmul[constant-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 6
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 262144
addi x12, x12, 0
l2_load_w x12, x11, x0
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x4
ccr_set 2, 1
lw x17, x0, 8
addi x15, x0, 1
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x7, x4, x4, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x4, x7, x4, x4, ss4
ccr_decl x4
ccr_clr 0
dm_load_l1 0, 0, x9, x0, ss4, if_
l2_load_w_conf x7, x7, i8, i8, 0
ccr_decl x4
ccr_set 3, 1
lw x21, x0, 8
addi x19, x0, 15
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
addi x22, x0, 5
l2_load_w x20, x19, x22
addi x23, x0, 24
dm_load_w_conf 0, 0, 1, 1, x23
dm_load_w_conf2 0, 0, x4, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x7, x4, ss5
ccr_decl x2
ccr_clr 3
ccr_clr 1
dm_load_w 0, 0, x20, x12, ss5, pu
ss_pack_stride x23, x4, x4, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x7, x0
ss_pack_shape x4, x7, x4, x4, ss4
pu_fetchif_conf3 0, 0, x0, x4, ss4
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x24, x0, 31
pu_fetchif_conf_deq 0, 0, x24, x0, u8
ccr_decl x4
ccr_clr 2
addi x25, x0, 14
dm_load_act0 0, 0, x16, x25, pu, 1
ss_pack_stride x4, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x4, x4, x4, x4, ss1
ccr_decl x4
ccr_set 4, 1
lui x26, 65536
addi x26, x26, 32
dm_store_of 0, 0, x26, ss1, pu
ss_pack_shape x4, x4, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x4, x4, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x4, x4, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x4, x4, x4, ss0
ss_pack_stride x4, x4, x4, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x4, ss1
ccr_decl x4
ccr_clr 4
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss1
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 6
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 21
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x20, x0, 4
lui x19, 0
addi x19, x19, 0
add x19, x20, x19
l2_store x19, x17, ss2
end x0
# case: test_matmul[constant-in_shape10]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 2
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1562
addi x11, x0, 1
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1563
mmu_conf x12, x11, 7
l2_load_w_conf x11, x11, i8, i8, 0
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 458752
addi x14, x14, 0
l2_load_w x14, x13, x0
addi x16, x0, 7
l2_load_w_conf x16, x16, fp16, fp16, 0
lw x19, x0, 8
addi x17, x0, 1
add x17, x19, x17
lui x18, 393216
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 6
ss_pack_stride x11, x11, x21, ss0
addi x22, x0, 4
addi x23, x0, 32
ss_pack_stride x11, x22, x23, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x11
ccr_set 0, 1
lw x26, x0, 0
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 262144
addi x25, x25, 0
l2_load x25, x24, ss2
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x11
ccr_set 1, 1
lw x29, x0, 8
addi x27, x0, 15
add x27, x29, x27
lui x28, 327680
addi x28, x28, 0
addi x30, x0, 5
l2_load_w x28, x27, x30
addi x31, x0, 24
dm_load_w_conf 0, 0, 1, 1, x31
dm_load_w_conf2 0, 0, x11, x11
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x21, x11, ss3
ccr_decl x11
ccr_clr 1
dm_load_w 0, 0, x28, x14, ss3, pu
ss_pack_stride x11, x22, x23, ss1
addi x1, x0, 1024
ss_pack_stride x31, x11, x1, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x9
ccr_clr 0
ccr_set 2, 1
lui x3, 196608
addi x3, x3, 0
mfu_transpose x3, x25, ss2
ss_pack_stride x31, x11, x1, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x11, x21, x11, x22, ss5
ccr_decl x11
ccr_clr 2
dm_load_l1 0, 0, x3, x0, ss5, if_
ss_pack_stride x31, x11, x22, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x21, x0
ss_pack_shape x11, x21, x11, x22, ss5
pu_fetchif_conf3 0, 0, x0, x11, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x2, x0, 31
pu_fetchif_conf_deq 0, 0, x2, x0, u8
addi x4, x0, 14
dm_load_act0 0, 0, x18, x4, pu, 1
ss_pack_stride x23, x11, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x11
ccr_set 3, 1
lui x5, 65536
addi x5, x5, 0
dm_store_of 0, 0, x5, ss3, pu
ss_pack_shape x11, x11, x11, x22, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x11, x11, x22, ss1
pu_of_conf1 0, 0, x11, x0, ss1
ss_pack_shape x11, x11, x11, x22, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x23, x11, x1, ss0
ss_pack_stride x11, x1, x23, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x9
ccr_clr 3
ccr_set 4, 1
lui x6, 131072
addi x6, x6, 0
mfu_transpose x6, x5, ss3
ss_pack_stride x11, x1, x23, ss2
ss_pack_stride x11, x22, x11, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x11, x11, x22, x11, ss6
ccr_decl x11
ccr_clr 4
lw x8, x0, 4
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x6, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 21
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape11]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape12]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
ss_pack_stride x2, x2, x3, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x8, x0, 4
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape13]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 140
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 143
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 185
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape14]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 140
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 143
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 185
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 203
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 206
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 248
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 266
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 269
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 311
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 329
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 332
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 374
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape15]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 24
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1576
addi x9, x0, 2
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1578
addi x11, x0, 1
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1579
mmu_conf x12, x11, 7
l2_load_w_conf x11, x11, i8, i8, 0
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 458752
addi x14, x14, 0
l2_load_w x14, x13, x0
addi x16, x0, 7
l2_load_w_conf x16, x16, fp16, fp16, 0
lw x19, x0, 8
addi x17, x0, 1
add x17, x19, x17
lui x18, 393216
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 6
ss_pack_stride x11, x11, x21, ss0
addi x22, x0, 12
addi x23, x0, 32
ss_pack_stride x11, x22, x23, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x11
ccr_set 0, 1
lw x26, x0, 0
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 262144
addi x25, x25, 0
l2_load x25, x24, ss2
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x11
ccr_set 1, 1
lw x29, x0, 8
addi x27, x0, 15
add x27, x29, x27
lui x28, 327680
addi x28, x28, 0
addi x30, x0, 5
l2_load_w x28, x27, x30
dm_load_w_conf 0, 0, 1, 1, x7
dm_load_w_conf2 0, 0, x11, x11
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x21, x11, ss3
ccr_decl x11
ccr_clr 1
dm_load_w 0, 0, x28, x14, ss3, pu
ss_pack_stride x11, x22, x23, ss1
addi x31, x0, 1024
ss_pack_stride x7, x11, x31, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x9
ccr_clr 0
ccr_set 2, 1
lui x1, 196608
addi x1, x1, 0
mfu_transpose x1, x25, ss2
ss_pack_stride x7, x11, x31, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x11, x21, x11, x22, ss5
ccr_decl x11
ccr_clr 2
dm_load_l1 0, 0, x1, x0, ss5, if_
ss_pack_stride x7, x11, x22, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x21, x0
ss_pack_shape x11, x21, x11, x22, ss5
pu_fetchif_conf3 0, 0, x0, x11, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
addi x2, x0, 14
dm_load_act0 0, 0, x18, x2, pu, 1
ss_pack_stride x23, x11, x31, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x11
ccr_set 3, 1
lui x4, 65536
addi x4, x4, 0
dm_store_of 0, 0, x4, ss3, pu
ss_pack_shape x11, x11, x11, x22, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x11, x11, x22, ss1
pu_of_conf1 0, 0, x11, x0, ss1
ss_pack_shape x11, x11, x11, x22, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x23, x11, x31, ss0
ss_pack_stride x11, x31, x23, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x9
ccr_clr 3
ccr_set 4, 1
lui x5, 131072
addi x5, x5, 0
mfu_transpose x5, x4, ss3
ss_pack_stride x11, x31, x23, ss2
ss_pack_stride x11, x22, x11, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x11, x11, x22, x11, ss6
ccr_decl x11
ccr_clr 4
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x5, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 10
mmu_conf x1, x2, 1
addi x3, x0, 26
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 28
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 29
mmu_conf x7, x6, 4
addi x8, x0, 72
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 21
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 4
addi x19, x0, 6
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss5
mfu_act1_conf_dest x8, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 160
mfu_act1_compute x21, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
end x0
# case: test_matmul[constant-in_shape16]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 24
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1576
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1581
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1583
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 12
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
dm_load_w_conf 0, 0, 1, 1, x7
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x3, x0, 1024
ss_pack_stride x7, x13, x3, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x2, 196608
addi x2, x2, 0
mfu_transpose x2, x27, ss2
ss_pack_stride x7, x13, x3, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x2, x0, ss5, if_
ss_pack_stride x7, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x4, x0, 31
pu_fetchif_conf_deq 0, 0, x4, x0, u8
addi x5, x0, 42
dm_load_act0 0, 0, x20, x5, pu, 1
ss_pack_stride x25, x13, x3, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x6, 65536
addi x6, x6, 0
dm_store_of 0, 0, x6, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x3, ss0
ss_pack_stride x13, x3, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x6, ss3
ss_pack_stride x13, x3, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 10
mmu_conf x1, x2, 1
addi x3, x0, 26
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 28
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 29
mmu_conf x7, x6, 4
addi x8, x0, 72
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 63
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 4
addi x19, x0, 6
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss5
mfu_act1_conf_dest x8, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 160
mfu_act1_compute x21, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
end x0
# case: test_matmul[constant-in_shape17]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 77
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 133
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 119
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 175
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape18]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 157
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 217
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape19]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 157
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 231
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 234
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 276
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 294
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 297
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 339
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 357
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 360
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 402
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 217
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 217
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 3
mmu_conf x1, x2, 1
addi x3, x0, 19
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 23
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 6
ss_pack_stride x7, x7, x8, ss0
ss_pack_stride x7, x7, x8, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x7, x7, x7, x8, ss2
ccr_decl x7
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 131072
addi x10, x10, 0
l2_load x10, x9, ss2
l2_load_w_conf x2, x2, i8, i8, 0
ccr_decl x7
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 262144
addi x13, x13, 0
l2_load_w x13, x12, x4
l2_load_w_conf x5, x5, fp16, fp16, 0
ccr_decl x7
ccr_set 2, 1
lw x17, x0, 8
addi x15, x0, 3
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load_w x16, x15, x6
ss_pack_stride x8, x7, x7, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x8, x7, x7, ss4
ccr_decl x7
ccr_clr 0
dm_load_l1 0, 0, x10, x0, ss4, if_
addi x18, x0, 18
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x21, x0, 8
addi x19, x0, 45
add x19, x21, x19
lui x20, 65536
addi x20, x20, 0
addi x22, x0, 5
l2_load_w x20, x19, x22
addi x23, x0, 24
dm_load_w_conf 0, 0, 1, 1, x23
dm_load_w_conf2 0, 0, x7, x2
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x8, x2, ss5
ccr_decl x4
ccr_clr 3
ccr_clr 1
dm_load_w 0, 0, x20, x13, ss5, pu
ss_pack_stride x23, x7, x7, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x8, x0
ss_pack_shape x7, x8, x7, x7, ss4
pu_fetchif_conf3 0, 0, x0, x7, ss4
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x24, x0, 31
pu_fetchif_conf_deq 0, 0, x24, x0, u8
ccr_decl x7
ccr_clr 2
addi x25, x0, 42
dm_load_act0 0, 0, x16, x25, pu, 1
ss_pack_stride x2, x7, x7, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x2, x7, x7, ss1
ccr_decl x7
ccr_set 4, 1
lui x26, 131072
addi x26, x26, 32
dm_store_of 0, 0, x26, ss1, pu
ss_pack_shape x7, x2, x7, x7, ss1
act0_src1_conf 0, 0, pu, ss1, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x2, x7, x7, ss0
pu_of_conf1 0, 0, x2, x0, ss0
ss_pack_shape x7, x2, x7, x7, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x7, x7, x2, ss2
ss_pack_stride x7, x7, x2, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x2, ss3
ccr_decl x7
ccr_clr 4
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss3
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 6
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x20, x0, 4
lui x19, 0
addi x19, x19, 0
add x19, x20, x19
l2_store x19, x17, ss2
end x0
# case: test_matmul[constant-in_shape20]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 48
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1600
addi x9, x0, 2
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1602
addi x11, x0, 1
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1603
mmu_conf x12, x11, 7
l2_load_w_conf x11, x11, i8, i8, 0
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 458752
addi x14, x14, 0
l2_load_w x14, x13, x0
addi x16, x0, 7
l2_load_w_conf x16, x16, fp16, fp16, 0
lw x19, x0, 8
addi x17, x0, 1
add x17, x19, x17
lui x18, 393216
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 6
ss_pack_stride x11, x11, x21, ss0
addi x22, x0, 24
addi x23, x0, 32
ss_pack_stride x11, x22, x23, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x11
ccr_set 0, 1
lw x26, x0, 0
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 262144
addi x25, x25, 0
l2_load x25, x24, ss2
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x11
ccr_set 1, 1
lw x29, x0, 8
addi x27, x0, 15
add x27, x29, x27
lui x28, 327680
addi x28, x28, 0
addi x30, x0, 5
l2_load_w x28, x27, x30
dm_load_w_conf 0, 0, 1, 1, x22
dm_load_w_conf2 0, 0, x11, x11
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x21, x11, ss3
ccr_decl x11
ccr_clr 1
dm_load_w 0, 0, x28, x14, ss3, pu
ss_pack_stride x11, x22, x23, ss1
addi x31, x0, 1024
ss_pack_stride x22, x11, x31, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x9
ccr_clr 0
ccr_set 2, 1
lui x1, 196608
addi x1, x1, 0
mfu_transpose x1, x25, ss2
ss_pack_stride x22, x11, x31, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x11, x21, x11, x22, ss5
ccr_decl x11
ccr_clr 2
dm_load_l1 0, 0, x1, x0, ss5, if_
ss_pack_stride x22, x11, x22, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x21, x0
ss_pack_shape x11, x21, x11, x22, ss5
pu_fetchif_conf3 0, 0, x0, x11, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
addi x2, x0, 14
dm_load_act0 0, 0, x18, x2, pu, 1
ss_pack_stride x23, x11, x31, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x11
ccr_set 3, 1
lui x4, 65536
addi x4, x4, 0
dm_store_of 0, 0, x4, ss3, pu
ss_pack_shape x11, x11, x11, x22, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x11, x11, x22, ss1
pu_of_conf1 0, 0, x11, x0, ss1
ss_pack_shape x11, x11, x11, x22, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x23, x11, x31, ss0
ss_pack_stride x11, x31, x23, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x9
ccr_clr 3
ccr_set 4, 1
lui x5, 131072
addi x5, x5, 0
mfu_transpose x5, x4, ss3
ss_pack_stride x11, x31, x23, ss2
ss_pack_stride x11, x22, x11, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x11, x11, x22, x11, ss6
ccr_decl x11
ccr_clr 4
lw x7, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x7, x6
l2_store x6, x5, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 18
mmu_conf x1, x2, 1
addi x3, x0, 34
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 36
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 37
mmu_conf x7, x6, 4
addi x8, x0, 72
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x9, x0, 144
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
addi x14, x0, 21
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 4
addi x20, x0, 6
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x4, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x4, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 288
mfu_act1_compute x22, x11, x0, x15
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
end x0
# case: test_matmul[constant-in_shape21]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 48
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1600
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1605
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1607
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 24
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
dm_load_w_conf 0, 0, 1, 1, x24
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x3, x0, 1024
ss_pack_stride x24, x13, x3, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x2, 196608
addi x2, x2, 0
mfu_transpose x2, x27, ss2
ss_pack_stride x24, x13, x3, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x2, x0, ss5, if_
ss_pack_stride x24, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x4, x0, 31
pu_fetchif_conf_deq 0, 0, x4, x0, u8
addi x5, x0, 42
dm_load_act0 0, 0, x20, x5, pu, 1
ss_pack_stride x25, x13, x3, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x6, 65536
addi x6, x6, 0
dm_store_of 0, 0, x6, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x3, ss0
ss_pack_stride x13, x3, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x7, 131072
addi x7, x7, 0
mfu_transpose x7, x6, ss3
ss_pack_stride x13, x3, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x7, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 18
mmu_conf x1, x2, 1
addi x3, x0, 34
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 36
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 37
mmu_conf x7, x6, 4
addi x8, x0, 72
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x9, x0, 144
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
addi x14, x0, 63
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 4
addi x20, x0, 6
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x4, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x4, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 288
mfu_act1_compute x22, x11, x0, x15
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
end x0
# case: test_matmul[constant-in_shape22]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 77
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 133
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 189
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 245
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 119
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 301
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 175
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 231
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 287
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 343
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape23]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 157
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 231
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 287
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 343
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 217
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 273
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 329
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 385
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape24]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 157
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 217
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 220
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 262
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 294
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 297
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 339
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 371
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 374
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 416
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 280
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 357
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 434
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape25]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 80
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 157
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 217
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 77
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 273
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 122
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 154
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 329
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 199
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 140
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 259
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 315
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 371
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape26]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 72
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 24
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 77
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 133
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 189
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 192
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 234
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 189
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 252
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 234
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 119
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 189
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 294
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 234
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 29
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 175
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 119
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 175
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape2]
# case: test_matmul[constant-in_shape3]
# case: test_matmul[constant-in_shape4]
# case: test_matmul[constant-in_shape5]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 2
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1562
addi x11, x0, 1
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1563
mmu_conf x12, x11, 7
l2_load_w_conf x11, x11, i8, i8, 0
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 458752
addi x14, x14, 0
l2_load_w x14, x13, x0
addi x16, x0, 7
l2_load_w_conf x16, x16, fp16, fp16, 0
lw x19, x0, 8
addi x17, x0, 1
add x17, x19, x17
lui x18, 393216
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 6
ss_pack_stride x11, x11, x21, ss0
addi x22, x0, 4
addi x23, x0, 32
ss_pack_stride x11, x22, x23, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x11
ccr_set 0, 1
lw x26, x0, 0
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 262144
addi x25, x25, 0
l2_load x25, x24, ss2
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x11
ccr_set 1, 1
lw x29, x0, 8
addi x27, x0, 15
add x27, x29, x27
lui x28, 327680
addi x28, x28, 0
addi x30, x0, 5
l2_load_w x28, x27, x30
addi x31, x0, 24
dm_load_w_conf 0, 0, 1, 1, x31
dm_load_w_conf2 0, 0, x11, x11
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x21, x11, ss3
ccr_decl x11
ccr_clr 1
dm_load_w 0, 0, x28, x14, ss3, pu
ss_pack_stride x11, x22, x23, ss1
addi x1, x0, 1024
ss_pack_stride x31, x11, x1, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x11, x11, x22, x21, ss2
ccr_decl x9
ccr_clr 0
ccr_set 2, 1
lui x3, 196608
addi x3, x3, 0
mfu_transpose x3, x25, ss2
ss_pack_stride x31, x11, x1, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x11, x21, x11, x22, ss5
ccr_decl x11
ccr_clr 2
dm_load_l1 0, 0, x3, x0, ss5, if_
ss_pack_stride x31, x11, x22, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x21, x0
ss_pack_shape x11, x21, x11, x22, ss5
pu_fetchif_conf3 0, 0, x0, x11, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x2, x0, 31
pu_fetchif_conf_deq 0, 0, x2, x0, u8
addi x4, x0, 14
dm_load_act0 0, 0, x18, x4, pu, 1
ss_pack_stride x23, x11, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x11
ccr_set 3, 1
lui x5, 65536
addi x5, x5, 0
dm_store_of 0, 0, x5, ss3, pu
ss_pack_shape x11, x11, x11, x22, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x11, x11, x22, ss1
pu_of_conf1 0, 0, x11, x0, ss1
ss_pack_shape x11, x11, x11, x22, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x23, x11, x1, ss0
ss_pack_stride x11, x1, x23, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x11, x11, x11, x22, ss3
ccr_decl x9
ccr_clr 3
ccr_set 4, 1
lui x6, 131072
addi x6, x6, 0
mfu_transpose x6, x5, ss3
ss_pack_stride x11, x1, x23, ss2
ss_pack_stride x11, x22, x11, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x11, x11, x22, x11, ss6
ccr_decl x11
ccr_clr 4
lw x8, x0, 4
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x6, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 21
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_matmul[constant-in_shape6]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
ss_pack_stride x13, x13, x13, ss0
addi x23, x0, 4
addi x24, x0, 32
ss_pack_stride x13, x23, x24, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x23, x13, ss2
ccr_decl x13
ccr_set 0, 1
lw x27, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load x26, x25, ss2
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x30, x0, 8
addi x28, x0, 45
add x28, x30, x28
lui x29, 327680
addi x29, x29, 0
l2_load_w x29, x28, x0
addi x31, x0, 24
dm_load_w_conf 0, 0, 1, 1, x31
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x13, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x29, x16, ss3, pu
ss_pack_stride x13, x23, x24, ss1
addi x1, x0, 1024
ss_pack_stride x31, x13, x1, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x23, x13, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x3, 196608
addi x3, x3, 0
mfu_transpose x3, x26, ss2
ss_pack_stride x31, x13, x1, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x13, x13, x23, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x3, x0, ss5, if_
ss_pack_stride x31, x13, x23, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x13, x0
ss_pack_shape x13, x13, x13, x23, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x2, x0, 31
pu_fetchif_conf_deq 0, 0, x2, x0, u8
addi x4, x0, 42
dm_load_act0 0, 0, x20, x4, pu, 1
ss_pack_stride x24, x13, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x23, ss3
ccr_decl x13
ccr_set 3, 1
lui x5, 65536
addi x5, x5, 0
dm_store_of 0, 0, x5, ss3, pu
ss_pack_shape x13, x14, x13, x23, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x23, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x23, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x24, x13, x1, ss0
ss_pack_stride x13, x1, x24, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x23, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x6, 131072
addi x6, x6, 0
mfu_transpose x6, x5, ss3
ss_pack_stride x13, x1, x24, ss2
ss_pack_stride x13, x23, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x23, x14, ss6
ccr_decl x13
ccr_clr 4
lw x8, x0, 4
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x6, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 4
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 48
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x7, x4, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x7, x4, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x7, x4, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x7, x4, ss5
mfu_act1_conf_dest x7, ss5
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x18, x0, 3
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x20, x0, 4
lui x19, 0
addi x19, x19, 0
add x19, x20, x19
l2_store x19, x17, ss2
end x0
# case: test_matmul[constant-in_shape7]
# case: test_matmul[constant-in_shape8]
# case: test_matmul[constant-in_shape9]
# case: test_matmul[non_constant-in_shape0]
# case: test_matmul[non_constant-in_shape10]
# case: test_matmul[non_constant-in_shape11]
# case: test_matmul[non_constant-in_shape12]
# case: test_matmul[non_constant-in_shape13]
# case: test_matmul[non_constant-in_shape14]
# case: test_matmul[non_constant-in_shape15]
# case: test_matmul[non_constant-in_shape16]
# case: test_matmul[non_constant-in_shape17]
# case: test_matmul[non_constant-in_shape18]
# case: test_matmul[non_constant-in_shape19]
# case: test_matmul[non_constant-in_shape1]
# case: test_matmul[non_constant-in_shape20]
# case: test_matmul[non_constant-in_shape21]
# case: test_matmul[non_constant-in_shape22]
# case: test_matmul[non_constant-in_shape23]
# case: test_matmul[non_constant-in_shape24]
# case: test_matmul[non_constant-in_shape25]
# case: test_matmul[non_constant-in_shape26]
# case: test_matmul[non_constant-in_shape2]
# case: test_matmul[non_constant-in_shape3]
# case: test_matmul[non_constant-in_shape4]
# case: test_matmul[non_constant-in_shape5]
# case: test_matmul[non_constant-in_shape6]
# case: test_matmul[non_constant-in_shape7]
# case: test_matmul[non_constant-in_shape8]
# case: test_matmul[non_constant-in_shape9]
