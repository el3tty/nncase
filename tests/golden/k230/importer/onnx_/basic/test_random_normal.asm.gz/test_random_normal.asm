# case: test_random_normal[shape0-1.0-2.0-1.0-1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_random_normal[shape0-1.0-2.0-None-1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_random_normal[shape0-1.0-None-1.0-1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_random_normal[shape0-1.0-None-None-1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 4
mmu_conf x4, x5, 3
addi x6, x0, 212
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 213
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load_w x22, x21, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 84
add x24, x26, x24
lui x25, 131072
addi x25, x25, 0
l2_load x25, x24, ss2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x5
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x20, x25, x22
ss_pack_stride x7, x7, x9, ss6
ss_pack_stride x7, x7, x9, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
