# case: test_instancenorm[0.01-in_shape0]
# case: test_instancenorm[None-in_shape0]
