# case: test_reducel1[1-0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3970
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[1-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3972
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[1-0-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1420
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[1-None-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[1-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1460
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[1-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 4000
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[1-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3075
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3963
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[1-None-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3934
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[11-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3971
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[11-0-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1516
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[11-None-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[11-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1476
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[11-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3988
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[11-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3976
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[11-None-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3074
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3943
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[13-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3991
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[13-0-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1432
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[13-None-axes10-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes11-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes12-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes4-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes5-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_reducel1[13-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 532
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 533
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 0
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x1, x6, x23, ss7
mfu_transpose_conf ss7, ss6, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss5
addi x25, x0, 2
ccr_decl x25
ccr_clr 0
ccr_set 2, 1
mfu_transpose x19, x10, ss5
ss_pack_stride x1, x6, x23, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x26, 0
addi x26, x26, 3584
mfu_pdp1_conf3 x1, x1, x26, ss4
mfu_pdp1_conf4 x17, x6, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x27, 5
addi x27, x27, 1461
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x25
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x19, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss3
end x0
# case: test_reducel1[13-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3964
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[13-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x23, x0, 32
ss_pack_stride x17, x1, x23, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x17, x1, x23, ss6
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss6, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x25, 0
addi x25, x25, 3584
mfu_pdp1_conf3 x6, x6, x25, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
mfu_pdp1_conf_deq x24, x0, u8
lui x26, 4
addi x26, x26, 3988
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x1, x1, ss5
addi x27, x0, 2
ccr_decl x27
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x19, x10, ss5
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x19, ss1
end x0
# case: test_reducel1[13-None-axes9-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
