# case: test_constantofshape[None-in_shape0]
# case: test_constantofshape[value1-in_shape0]
# case: test_constantofshape[value2-in_shape0]
