# case: test_reducel2[1-0-None-in_shape0]
# case: test_reducel2[1-0-axes1-in_shape0]
# case: test_reducel2[1-0-axes10-in_shape0]
# case: test_reducel2[1-0-axes11-in_shape0]
# case: test_reducel2[1-0-axes12-in_shape0]
# case: test_reducel2[1-0-axes2-in_shape0]
# case: test_reducel2[1-0-axes3-in_shape0]
# case: test_reducel2[1-0-axes4-in_shape0]
# case: test_reducel2[1-0-axes5-in_shape0]
# case: test_reducel2[1-0-axes6-in_shape0]
# case: test_reducel2[1-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 287
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[1-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3074
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 377
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[1-0-axes9-in_shape0]
# case: test_reducel2[1-None-None-in_shape0]
# case: test_reducel2[1-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3072
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2049
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[1-None-axes10-in_shape0]
# case: test_reducel2[1-None-axes11-in_shape0]
# case: test_reducel2[1-None-axes12-in_shape0]
# case: test_reducel2[1-None-axes2-in_shape0]
# case: test_reducel2[1-None-axes3-in_shape0]
# case: test_reducel2[1-None-axes4-in_shape0]
# case: test_reducel2[1-None-axes5-in_shape0]
# case: test_reducel2[1-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3075
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2069
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[1-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3074
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 399
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[1-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3073
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 326
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[1-None-axes9-in_shape0]
# case: test_reducel2[11-0-None-in_shape0]
# case: test_reducel2[11-0-axes1-in_shape0]
# case: test_reducel2[11-0-axes10-in_shape0]
# case: test_reducel2[11-0-axes11-in_shape0]
# case: test_reducel2[11-0-axes12-in_shape0]
# case: test_reducel2[11-0-axes2-in_shape0]
# case: test_reducel2[11-0-axes3-in_shape0]
# case: test_reducel2[11-0-axes4-in_shape0]
# case: test_reducel2[11-0-axes5-in_shape0]
# case: test_reducel2[11-0-axes6-in_shape0]
# case: test_reducel2[11-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 396
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[11-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 376
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[11-0-axes9-in_shape0]
# case: test_reducel2[11-None-None-in_shape0]
# case: test_reducel2[11-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3074
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2052
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[11-None-axes10-in_shape0]
# case: test_reducel2[11-None-axes11-in_shape0]
# case: test_reducel2[11-None-axes12-in_shape0]
# case: test_reducel2[11-None-axes2-in_shape0]
# case: test_reducel2[11-None-axes3-in_shape0]
# case: test_reducel2[11-None-axes4-in_shape0]
# case: test_reducel2[11-None-axes5-in_shape0]
# case: test_reducel2[11-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2054
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[11-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 354
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[11-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 408
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[11-None-axes9-in_shape0]
# case: test_reducel2[13-0-None-in_shape0]
# case: test_reducel2[13-0-axes1-in_shape0]
# case: test_reducel2[13-0-axes10-in_shape0]
# case: test_reducel2[13-0-axes11-in_shape0]
# case: test_reducel2[13-0-axes12-in_shape0]
# case: test_reducel2[13-0-axes2-in_shape0]
# case: test_reducel2[13-0-axes3-in_shape0]
# case: test_reducel2[13-0-axes4-in_shape0]
# case: test_reducel2[13-0-axes5-in_shape0]
# case: test_reducel2[13-0-axes6-in_shape0]
# case: test_reducel2[13-0-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3074
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 380
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[13-0-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 333
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[13-0-axes9-in_shape0]
# case: test_reducel2[13-None-None-in_shape0]
# case: test_reducel2[13-None-axes1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2066
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[13-None-axes10-in_shape0]
# case: test_reducel2[13-None-axes11-in_shape0]
# case: test_reducel2[13-None-axes12-in_shape0]
# case: test_reducel2[13-None-axes2-in_shape0]
# case: test_reducel2[13-None-axes3-in_shape0]
# case: test_reducel2[13-None-axes4-in_shape0]
# case: test_reducel2[13-None-axes5-in_shape0]
# case: test_reducel2[13-None-axes6-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 530
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x2, ss0
ss_pack_stride x4, x4, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x2, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 14
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
addi x15, x0, 2
ss_pack_stride x15, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x16, x0, 32
ss_pack_stride x15, x1, x16, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x2, x4, x4, 0, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x1, x1, ss6
mfu_act1_conf_dest x2, ss6
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65538
addi x18, x18, 0
mfu_act1_compute x18, x8, x0, x12
ss_pack_stride x15, x1, x16, ss5
ss_pack_stride x1, x4, x16, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x4, x15, x1, x1, ss6
ccr_decl x15
ccr_clr 2
ccr_set 0, 1
mfu_transpose x8, x18, ss6
ss_pack_stride x1, x4, x16, ss7
ss_pack_stride x1, x4, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x20, 0
addi x20, x20, 3584
mfu_pdp1_conf3 x1, x1, x20, ss4
mfu_pdp1_conf4 x15, x4, x17, 0, 0
lui x21, 2
addi x21, x21, 3075
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 2066
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x4, x15, ss1
ccr_decl x15
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x18, x8, ss1
ss_pack_stride x1, x4, x1, ss0
ss_pack_stride x1, x4, x4, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x4, x4, ss3
ccr_decl x4
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x18, ss3
end x0
# case: test_reducel2[13-None-axes7-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 446
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[13-None-axes8-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 81
mmu_conf x5, x4, 3
addi x6, x0, 82
mmu_conf x6, x4, 4
addi x7, x0, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
ss_pack_stride x16, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x17, x0, 32
ss_pack_stride x16, x1, x17, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_src2 x4, ss6, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x16, x1, x1, ss6
mfu_act1_conf_dest x7, ss6
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x16, x1, x17, ss5
ss_pack_stride x16, x4, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x4, x4, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x4, x4, x21, ss4
mfu_pdp1_conf4 x1, x1, x18, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 402
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x4, x16, x1, x1, ss6
ccr_decl x16
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x9, x19, ss6
ss_pack_stride x16, x4, x1, ss7
ss_pack_stride x16, x4, x4, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x4, x16, x4, x4, ss1
ccr_decl x4
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x9, ss1
end x0
# case: test_reducel2[13-None-axes9-in_shape0]
