# case: test_transpose[1-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 49
mmu_conf x5, x4, 3
addi x6, x0, 256
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
ss_pack_stride x4, x1, x1, ss3
ss_pack_stride x4, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x4, x1, x1, ss4
addi x11, x0, 2
ccr_decl x11
ccr_clr 0
ccr_set 1, 1
lui x10, 65536
addi x10, x10, 512
mfu_transpose x10, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x13, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_store x12, x10, ss2
end x0
# case: test_transpose[1-None-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-None-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3072
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3088
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, WHCN
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x10, x1, ss4
ss_pack_stride x1, x10, x5, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x1, x1, x10, x5, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis1-in_shape0]
# case: test_transpose[1-axis10-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x10, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x5, x10, x1, x1, ss4
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss4
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis11-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHCW
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis12-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1024
mmu_conf x1, x2, 1
addi x3, x0, 1040
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHWC
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x5, x1, x1, x10, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis13-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWCH
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis14-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1024
mmu_conf x1, x2, 1
addi x3, x0, 1040
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x5, x1, x1, x10, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis15-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3072
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3088
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, WHCN
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x10, x1, ss4
ss_pack_stride x1, x10, x5, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x1, x1, x10, x5, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 49
mmu_conf x5, x4, 3
addi x6, x0, 256
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
ss_pack_stride x4, x1, x1, ss3
ss_pack_stride x4, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x4, x1, x1, ss4
addi x11, x0, 2
ccr_decl x11
ccr_clr 0
ccr_set 1, 1
lui x10, 65536
addi x10, x10, 512
mfu_transpose x10, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x13, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_store x12, x10, ss2
end x0
# case: test_transpose[1-axis3-in_shape1]
# case: test_transpose[1-axis4-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x10, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x10, x1, x1, ss4
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis5-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHCW
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss5
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis6-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHWC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis7-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWCH
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss5
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[1-axis8-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[1-axis9-in_shape2]
# case: test_transpose[13-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 49
mmu_conf x5, x4, 3
addi x6, x0, 256
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
ss_pack_stride x4, x1, x1, ss3
ss_pack_stride x4, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x4, x1, x1, ss4
addi x11, x0, 2
ccr_decl x11
ccr_clr 0
ccr_set 1, 1
lui x10, 65536
addi x10, x10, 512
mfu_transpose x10, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x13, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_store x12, x10, ss2
end x0
# case: test_transpose[13-None-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-None-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3072
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3088
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, WHCN
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x10, x1, ss4
ss_pack_stride x1, x10, x5, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x1, x1, x10, x5, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis1-in_shape0]
# case: test_transpose[13-axis10-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x10, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x5, x10, x1, x1, ss4
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss4
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis11-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHCW
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis12-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1024
mmu_conf x1, x2, 1
addi x3, x0, 1040
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHWC
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x5, x1, x1, x10, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis13-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWCH
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis14-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1024
mmu_conf x1, x2, 1
addi x3, x0, 1040
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x5, x1, x1, x10, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis15-in_shape2]
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3072
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3088
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 1
addi x6, x0, 768
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, WHCN
ss_pack_shape x5, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x10, x1, ss4
ss_pack_stride x1, x10, x5, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x1, x1, x10, x5, ss7
ccr_decl x5
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 32
mmu_conf x1, x2, 1
addi x3, x0, 48
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 49
mmu_conf x5, x4, 3
addi x6, x0, 256
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
ss_pack_stride x4, x1, x1, ss3
ss_pack_stride x4, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x4, x1, x1, ss4
addi x11, x0, 2
ccr_decl x11
ccr_clr 0
ccr_set 1, 1
lui x10, 65536
addi x10, x10, 512
mfu_transpose x10, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x13, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_store x12, x10, ss2
end x0
# case: test_transpose[13-axis3-in_shape1]
# case: test_transpose[13-axis4-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x10, x1, x1, ss3
mfu_transpose_conf ss3, ss3, fp16, NCWH
ss_pack_shape x4, x10, x1, x1, ss4
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss4
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis5-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHCW
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss5
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis6-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NHWC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis7-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 113
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x10, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWCH
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65536
addi x11, x11, 1536
mfu_transpose x11, x8, ss5
ss_pack_stride x4, x4, x6, ss1
ss_pack_stride x4, x4, x6, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss2
end x0
# case: test_transpose[13-axis8-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 529
mmu_conf x5, x4, 3
addi x6, x0, 768
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss3
ss_pack_stride x1, x1, x1, ss4
mfu_transpose_conf ss4, ss3, fp16, NWHC
ss_pack_shape x4, x10, x1, x1, ss5
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x11, 65538
addi x11, x11, 0
mfu_transpose x11, x8, ss5
ss_pack_stride x1, x1, x1, ss4
ss_pack_stride x1, x1, x10, ss6
l2_store_conf ss6, ss4, fp16, fp32
ss_pack_shape x4, x1, x1, x10, ss7
ccr_decl x4
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x11, ss7
end x0
# case: test_transpose[13-axis9-in_shape2]
