# case: test_softplus[in_shape0]
