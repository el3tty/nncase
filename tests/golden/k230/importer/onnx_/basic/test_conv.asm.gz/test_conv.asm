# case: test_conv[None-None-kernel_shape0-1-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-1-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape0-None-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x7, x18, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x7, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x7
ccr_clr 4
addi x5, x0, 28
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_stride x4, x1, x1, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x1, x1, ss1
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x7, x4, x1, x1, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x1, x1, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x1, x1, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x6, x0, 512
ss_pack_stride x7, x7, x6, ss2
ss_pack_stride x7, x7, x6, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x7, x7, x7, x6, ss3
ccr_decl x7
ccr_clr 0
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
l2_store x8, x11, ss3
end x0
# case: test_conv[None-None-kernel_shape1-1-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-1-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-1-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-1-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-1-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-1-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-1-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-1-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-None-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-None-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-None-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-None-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-None-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-None-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 18
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x8, x8, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
ss_pack_stride x6, x1, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x1, x1, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x1, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x1, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x11, x0, 512
ss_pack_stride x8, x8, x11, ss3
ss_pack_stride x8, x8, x11, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x11, ss5
ccr_decl x8
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x12, ss5
end x0
# case: test_conv[None-None-kernel_shape1-None-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-None-kernel_shape1-None-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x1, x1, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x8
ccr_clr 4
addi x7, x0, 28
dm_load_act0 0, 0, x26, x7, pu, 1
ss_pack_stride x6, x4, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x4, x4, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x6, x4, x4, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x4, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x4, x4, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 392
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_conv[None-pad1-kernel_shape0-1-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
addi x3, x0, 17
ss_pack_shape x7, x18, x3, x1, ss0
pu_fetchif_conf3 0, 0, x0, x7, ss0
ss_pack_shape x0, x7, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x26, x6, pu, 1
ss_pack_stride x4, x3, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x7, x4, x3, x1, ss4
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss4, pu
ss_pack_shape x7, x4, x3, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x3, x1, ss2
pu_of_conf1 0, 0, x4, x0, ss2
ss_pack_shape x7, x4, x3, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x8, x0, 544
ss_pack_stride x7, x7, x8, ss3
ss_pack_stride x7, x7, x8, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x8, ss5
ccr_decl x7
ccr_clr 0
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x11, ss5
end x0
# case: test_conv[None-pad1-kernel_shape0-1-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
addi x3, x0, 17
ss_pack_shape x7, x18, x3, x1, ss0
pu_fetchif_conf3 0, 0, x0, x7, ss0
ss_pack_shape x0, x7, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x26, x6, pu, 1
ss_pack_stride x4, x3, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x7, x4, x3, x1, ss4
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss4, pu
ss_pack_shape x7, x4, x3, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x3, x1, ss2
pu_of_conf1 0, 0, x4, x0, ss2
ss_pack_shape x7, x4, x3, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x8, x0, 544
ss_pack_stride x7, x7, x8, ss3
ss_pack_stride x7, x7, x8, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x8, ss5
ccr_decl x7
ccr_clr 0
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x11, ss5
end x0
# case: test_conv[None-pad1-kernel_shape0-None-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
addi x3, x0, 17
ss_pack_shape x7, x18, x3, x1, ss0
pu_fetchif_conf3 0, 0, x0, x7, ss0
ss_pack_shape x0, x7, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x26, x6, pu, 1
ss_pack_stride x4, x3, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x7, x4, x3, x1, ss4
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss4, pu
ss_pack_shape x7, x4, x3, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x3, x1, ss2
pu_of_conf1 0, 0, x4, x0, ss2
ss_pack_shape x7, x4, x3, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x8, x0, 544
ss_pack_stride x7, x7, x8, ss3
ss_pack_stride x7, x7, x8, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x8, ss5
ccr_decl x7
ccr_clr 0
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x11, ss5
end x0
# case: test_conv[None-pad1-kernel_shape0-None-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
mmu_conf x5, x4, 3
addi x6, x0, 116
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 117
mmu_conf x8, x7, 5
addi x9, x0, 768
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x1, x1, ss5
mfu_act1_conf_dest x9, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x11, x0, x15
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 327680
addi x22, x22, 0
l2_load_w x22, x21, x7
addi x24, x0, 14
l2_load_w_conf x24, x24, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x7, x18, x1, x1, ss5
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x20, x0, ss5, if_
addi x28, x0, 6
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x4
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x4, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x22, ss6, pu
ss_pack_stride x2, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
addi x3, x0, 17
ss_pack_shape x7, x18, x3, x1, ss0
pu_fetchif_conf3 0, 0, x0, x7, ss0
ss_pack_shape x0, x7, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x26, x6, pu, 1
ss_pack_stride x4, x3, x1, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x7, x4, x3, x1, ss4
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x11, ss4, pu
ss_pack_shape x7, x4, x3, x1, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x3, x1, ss2
pu_of_conf1 0, 0, x4, x0, ss2
ss_pack_shape x7, x4, x3, x1, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x8, x0, 544
ss_pack_stride x7, x7, x8, ss3
ss_pack_stride x7, x7, x8, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x8, ss5
ccr_decl x7
ccr_clr 0
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x11, ss5
end x0
# case: test_conv[None-pad1-kernel_shape1-1-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x1, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 15
ss_pack_stride x6, x11, x4, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x4, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x4, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x4, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x4, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 420
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[None-pad1-kernel_shape1-1-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x1, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 15
ss_pack_stride x6, x11, x4, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x4, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x4, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x4, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x4, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 420
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[None-pad1-kernel_shape1-None-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x1, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 15
ss_pack_stride x6, x11, x4, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x4, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x4, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x4, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x4, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 420
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[None-pad1-kernel_shape1-None-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x1, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 15
ss_pack_stride x6, x11, x4, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x4, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x4, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x4, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x4, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 420
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-1-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape0-None-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 104
mmu_conf x5, x4, 3
addi x6, x0, 106
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 107
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x10, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x10, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x10, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 675
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x10, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1376
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x10, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x10, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x10, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x7, x9, x10, x10, ss2
pu_fetchif_conf3 0, 0, x0, x7, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x7
ccr_clr 4
addi x6, x0, 28
dm_load_act0 0, 0, x27, x6, pu, 1
addi x8, x0, 8
ss_pack_stride x4, x8, x8, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x7, x4, x8, x8, ss7
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss7, pu
ss_pack_shape x7, x4, x8, x8, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x8, x8, ss6
pu_of_conf1 0, 0, x4, x0, ss6
ss_pack_shape x7, x4, x8, x8, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x1, x0, 128
ss_pack_stride x7, x7, x1, ss0
ss_pack_stride x7, x7, x1, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x1, ss1
ccr_decl x7
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x0, x8, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x0, x8, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-1-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-NOTSET-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-NOTSET-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-SAME_LOWER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x0, x8, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-SAME_LOWER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x8, x0, x8, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-SAME_UPPER-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-SAME_UPPER-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 126
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 768
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x1, x1, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 44
add x25, x27, x25
lui x26, 262144
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x19, x1, x1, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x1, x1, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 54
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 72
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x2, x0, 216
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x6, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
addi x3, x0, 24
ss_pack_stride x3, x1, x1, ss7
pu_fetchif_conf1 0, 0, 2, 2, ss7
pu_fetchif_conf2 0, 0, x19, x0
addi x5, x0, 17
ss_pack_shape x8, x19, x5, x5, ss0
pu_fetchif_conf3 0, 0, x0, x8, ss0
ss_pack_shape x0, x8, x0, x8, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x26, x9, pu, 1
addi x11, x0, 8
ss_pack_stride x6, x11, x11, ss2
dm_store_of_conf 0, 0, ss2, fp16
ss_pack_shape x8, x6, x11, x11, ss4
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss4, pu
ss_pack_shape x8, x6, x11, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x11, x11, ss2
pu_of_conf1 0, 0, x6, x0, ss2
ss_pack_shape x8, x6, x11, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 128
ss_pack_stride x8, x8, x13, ss3
ss_pack_stride x8, x8, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x13, ss5
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-VALID-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-None-kernel_shape1-None-None-VALID-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 86
mmu_conf x1, x2, 1
addi x3, x0, 102
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 118
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 119
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x11, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x11, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x11, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 675
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x11, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1376
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x11, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x11, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x11, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x11, x11, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
ss_pack_shape x0, x0, x0, x0, ss3
pu_fetchif_conf4 0, 0, x0, ss3
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 28
dm_load_act0 0, 0, x27, x9, pu, 1
addi x1, x0, 7
ss_pack_stride x6, x1, x1, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x6, x1, x1, ss7
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss7, pu
ss_pack_shape x8, x6, x1, x1, ss7
act0_src1_conf 0, 0, pu, ss7, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x1, x1, ss6
pu_of_conf1 0, 0, x6, x0, ss6
ss_pack_shape x8, x6, x1, x1, ss7
pu_of_conf2 0, 0, x0, ss7
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x12, x0, 98
ss_pack_stride x8, x8, x12, ss0
ss_pack_stride x8, x8, x12, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x12, ss1
ccr_decl x8
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x13, ss1
end x0
# case: test_conv[stride1-pad1-kernel_shape0-1-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 108
mmu_conf x5, x4, 3
addi x6, x0, 110
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 111
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x1, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x1, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x1, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 720
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1440
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x1, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x1, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
addi x5, x0, 17
ss_pack_shape x7, x9, x5, x10, ss6
pu_fetchif_conf3 0, 0, x0, x7, ss6
ss_pack_shape x0, x7, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x6, x0, 31
pu_fetchif_conf_deq 0, 0, x6, x0, u8
ccr_decl x7
ccr_clr 4
addi x8, x0, 28
dm_load_act0 0, 0, x27, x8, pu, 1
addi x11, x0, 9
addi x13, x0, 8
ss_pack_stride x4, x11, x13, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x11, x13, ss3
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss3, pu
ss_pack_shape x7, x4, x11, x13, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x11, x13, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x11, x13, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x14, x0, 144
ss_pack_stride x7, x7, x14, ss1
ss_pack_stride x7, x7, x14, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x14, ss2
ccr_decl x7
ccr_clr 0
lw x17, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
l2_store x15, x12, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape0-1-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 108
mmu_conf x5, x4, 3
addi x6, x0, 110
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 111
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x1, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x1, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x1, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 720
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1440
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x1, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x1, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
addi x5, x0, 17
ss_pack_shape x7, x9, x5, x10, ss6
pu_fetchif_conf3 0, 0, x0, x7, ss6
ss_pack_shape x0, x7, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x6, x0, 31
pu_fetchif_conf_deq 0, 0, x6, x0, u8
ccr_decl x7
ccr_clr 4
addi x8, x0, 28
dm_load_act0 0, 0, x27, x8, pu, 1
addi x11, x0, 9
addi x13, x0, 8
ss_pack_stride x4, x11, x13, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x11, x13, ss3
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss3, pu
ss_pack_shape x7, x4, x11, x13, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x11, x13, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x11, x13, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x14, x0, 144
ss_pack_stride x7, x7, x14, ss1
ss_pack_stride x7, x7, x14, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x14, ss2
ccr_decl x7
ccr_clr 0
lw x17, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
l2_store x15, x12, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape0-None-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 108
mmu_conf x5, x4, 3
addi x6, x0, 110
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 111
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x1, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x1, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x1, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 720
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1440
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x1, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x1, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
addi x5, x0, 17
ss_pack_shape x7, x9, x5, x10, ss6
pu_fetchif_conf3 0, 0, x0, x7, ss6
ss_pack_shape x0, x7, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x6, x0, 31
pu_fetchif_conf_deq 0, 0, x6, x0, u8
ccr_decl x7
ccr_clr 4
addi x8, x0, 28
dm_load_act0 0, 0, x27, x8, pu, 1
addi x11, x0, 9
addi x13, x0, 8
ss_pack_stride x4, x11, x13, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x11, x13, ss3
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss3, pu
ss_pack_shape x7, x4, x11, x13, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x11, x13, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x11, x13, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x14, x0, 144
ss_pack_stride x7, x7, x14, ss1
ss_pack_stride x7, x7, x14, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x14, ss2
ccr_decl x7
ccr_clr 0
lw x17, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
l2_store x15, x12, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape0-None-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 108
mmu_conf x5, x4, 3
addi x6, x0, 110
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 111
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x9, x1, x1, ss0
addi x10, x0, 15
ss_pack_stride x9, x1, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x9, x1, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x9, x1, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x19, x0, 720
mfu_act1_conf_src1 x19, x7, x7, 0, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x9, x1, x10, ss2
mfu_act1_conf_dest x19, ss2
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1440
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x7
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x7
addi x25, x0, 14
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x7
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x9, x1, x10, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x7, x9, x1, x10, ss2
ccr_decl x7
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss2, if_
addi x29, x0, 6
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x7
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x7, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x4, ss4
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x23, ss4, pu
ss_pack_stride x3, x1, x10, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x9, x0
addi x5, x0, 17
ss_pack_shape x7, x9, x5, x10, ss6
pu_fetchif_conf3 0, 0, x0, x7, ss6
ss_pack_shape x0, x7, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x6, x0, 31
pu_fetchif_conf_deq 0, 0, x6, x0, u8
ccr_decl x7
ccr_clr 4
addi x8, x0, 28
dm_load_act0 0, 0, x27, x8, pu, 1
addi x11, x0, 9
addi x13, x0, 8
ss_pack_stride x4, x11, x13, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x7, x4, x11, x13, ss3
ccr_decl x7
ccr_set 0, 1
dm_store_of 0, 0, x12, ss3, pu
ss_pack_shape x7, x4, x11, x13, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x11, x13, ss0
pu_of_conf1 0, 0, x4, x0, ss0
ss_pack_shape x7, x4, x11, x13, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x14, x0, 144
ss_pack_stride x7, x7, x14, ss1
ss_pack_stride x7, x7, x14, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x14, ss2
ccr_decl x7
ccr_clr 0
lw x17, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
l2_store x15, x12, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape1-1-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 120
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 122
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 123
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x1, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x1, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x1, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 720
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1440
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x1, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x1, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 17
ss_pack_shape x8, x10, x7, x11, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x8, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
ccr_decl x8
ccr_clr 4
addi x12, x0, 28
dm_load_act0 0, 0, x27, x12, pu, 1
addi x14, x0, 8
addi x15, x0, 7
ss_pack_stride x6, x14, x15, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x14, x15, ss3
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss3, pu
ss_pack_shape x8, x6, x14, x15, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x14, x15, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x14, x15, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x16, x0, 112
ss_pack_stride x8, x8, x16, ss1
ss_pack_stride x8, x8, x16, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x16, ss2
ccr_decl x8
ccr_clr 0
lw x20, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x20, x18
l2_store x18, x13, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape1-1-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 120
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 122
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 123
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x1, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x1, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x1, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 720
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1440
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x1, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x1, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 17
ss_pack_shape x8, x10, x7, x11, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x8, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
ccr_decl x8
ccr_clr 4
addi x12, x0, 28
dm_load_act0 0, 0, x27, x12, pu, 1
addi x14, x0, 8
addi x15, x0, 7
ss_pack_stride x6, x14, x15, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x14, x15, ss3
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss3, pu
ss_pack_shape x8, x6, x14, x15, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x14, x15, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x14, x15, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x16, x0, 112
ss_pack_stride x8, x8, x16, ss1
ss_pack_stride x8, x8, x16, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x16, ss2
ccr_decl x8
ccr_clr 0
lw x20, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x20, x18
l2_store x18, x13, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape1-None-None-None-None-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 120
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 122
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 123
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x1, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x1, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x1, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 720
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1440
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x1, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x1, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 17
ss_pack_shape x8, x10, x7, x11, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x8, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
ccr_decl x8
ccr_clr 4
addi x12, x0, 28
dm_load_act0 0, 0, x27, x12, pu, 1
addi x14, x0, 8
addi x15, x0, 7
ss_pack_stride x6, x14, x15, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x14, x15, ss3
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss3, pu
ss_pack_shape x8, x6, x14, x15, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x14, x15, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x14, x15, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x16, x0, 112
ss_pack_stride x8, x8, x16, ss1
ss_pack_stride x8, x8, x16, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x16, ss2
ccr_decl x8
ccr_clr 0
lw x20, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x20, x18
l2_store x18, x13, ss2
end x0
# case: test_conv[stride1-pad1-kernel_shape1-None-None-None-bias_shape1-2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 90
mmu_conf x1, x2, 1
addi x3, x0, 106
addi x4, x0, 14
mmu_conf x3, x4, 2
addi x5, x0, 120
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 122
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 123
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x10, x1, x1, ss0
addi x11, x0, 15
ss_pack_stride x10, x1, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
ss_pack_stride x10, x1, x11, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x10, x1, x11, ss1
mfu_act1_conf_stride ss1, ss3, ss1
addi x20, x0, 720
mfu_act1_conf_src1 x20, x8, x8, 0, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x10, x1, x11, ss2
mfu_act1_conf_dest x20, ss2
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1440
mfu_act1_compute x22, x13, x0, x17
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x8
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 44
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x19
ss_pack_stride x10, x1, x11, ss1
dm_load_l1_conf 0, 0, ss1, i8, if_
ss_pack_shape x8, x10, x1, x11, ss2
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss2, if_
addi x29, x0, 54
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x30, x0, 72
add x30, x2, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x6
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x6, ss4
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss4, pu
addi x5, x0, 24
ss_pack_stride x5, x1, x11, ss5
pu_fetchif_conf1 0, 0, 2, 2, ss5
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 17
ss_pack_shape x8, x10, x7, x11, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x8, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
ccr_decl x8
ccr_clr 4
addi x12, x0, 28
dm_load_act0 0, 0, x27, x12, pu, 1
addi x14, x0, 8
addi x15, x0, 7
ss_pack_stride x6, x14, x15, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x6, x14, x15, ss3
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x13, ss3, pu
ss_pack_shape x8, x6, x14, x15, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x14, x15, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x8, x6, x14, x15, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x16, x0, 112
ss_pack_stride x8, x8, x16, ss1
ss_pack_stride x8, x8, x16, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x16, ss2
ccr_decl x8
ccr_clr 0
lw x20, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x20, x18
l2_store x18, x13, ss2
end x0
