# case: test_grid_sample[shape0]
# case: test_grid_sample[shape1]
# case: test_grid_sample[shape2]
