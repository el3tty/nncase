# case: test_split[op_versions_and_value_format0-2-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-2-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-2-split1--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-2-split1-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split2--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split2-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split3--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split3-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split4--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-3-split4-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-4-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-4-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-4-split5--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format0-4-split5-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-2-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-2-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-2-split1--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-2-split1-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split2--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split2-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split3--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split3-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split4--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-3-split4-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-4-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-4-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-4-split5--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format1-4-split5-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-2-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-2-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-2-split1--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-2-split1-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split2--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split2-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split3--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split3-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split4--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-3-split4-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-4-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-4-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-4-split5--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format2-4-split5-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-2-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-2-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-2-split1--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-2-split1-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split2--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split2-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split3--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split3-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split4--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-3-split4-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 128
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-4-None--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-4-None-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-4-split5--3-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
# case: test_split[op_versions_and_value_format3-4-split5-None-in_shape0]
# tile: k230/ptq TileSplit_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 256
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 512
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 256
ss_pack_stride x3, x3, x4, ss0
addi x5, x0, 64
ss_pack_stride x3, x3, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
addi x6, x0, 768
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x5, ss1
ss_pack_stride x3, x3, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x5, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 16
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
end x0
