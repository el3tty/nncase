# case: test_erf[in_shape0]
