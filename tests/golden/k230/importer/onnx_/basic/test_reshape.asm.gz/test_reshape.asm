# case: test_reshape[1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 2
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2178
addi x6, x0, 1
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2179
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2180
mmu_conf x8, x6, 5
lui x9, 4
addi x9, x9, 896
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 28
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
addi x19, x0, 60
addi x20, x0, 72
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65544
addi x22, x22, 1792
mfu_act1_compute x22, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x17
ss_pack_stride x18, x19, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x31, x0, 14
ss_pack_shape x6, x18, x31, x20, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 71
add x1, x3, x1
lui x2, 196608
addi x2, x2, 0
l2_load_w x2, x1, x23
addi x4, x0, 24
dm_load_w_conf 0, 0, 1, 1, x4
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss7
addi x5, x0, 2
ccr_decl x5
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x4, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x31, x20, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x6
ccr_clr 4
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_stride x6, x19, x20, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x31, x20, ss2
dm_store_of 0, 0, x11, ss2, pu
ss_pack_shape x6, x6, x31, x20, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x31, x20, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x31, x20, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x18, x31, x20, ss6
lui x8, 65545
addi x8, x8, 2800
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x6, x6, x31, x20, ss2
lui x10, 65536
addi x10, x10, 2016
dm_store_of 0, 0, x10, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x18, x31, x20, ss6
lui x12, 65545
addi x12, x12, 3808
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x6, x6, x31, x20, ss2
lui x13, 65537
addi x13, x13, 4032
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x18, x31, x20, ss6
lui x14, 65545
addi x14, x14, 720
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x6, x6, x31, x20, ss2
lui x16, 65537
addi x16, x16, 1952
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x18, x18, x20, ss3
ccr_decl x6
ccr_clr 2
lui x9, 65545
addi x9, x9, 1728
dm_load_l1 0, 0, x9, x0, ss3, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x4, x18, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x6, x18, x18, x20, ss3
pu_fetchif_conf3 0, 0, x0, x6, ss3
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x6, x6, x18, x20, ss4
ccr_decl x6
ccr_set 0, 1
lui x21, 65538
addi x21, x21, 3968
dm_store_of 0, 0, x21, ss4, pu
ss_pack_shape x6, x6, x18, x20, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x18, x20, ss1
pu_of_conf1 0, 0, x6, x0, ss1
ss_pack_shape x6, x6, x18, x20, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x15, 1
addi x15, x15, 224
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x15, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss6
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
l2_store x24, x11, ss6
end x0
# case: test_reshape[1-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 2
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2450
addi x6, x0, 1
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2451
mmu_conf x7, x6, 4
lui x8, 5
addi x8, x8, 2452
mmu_conf x8, x6, 5
addi x9, x0, 3
lui x10, 12
addi x10, x10, 1024
ss_pack_stride x9, x6, x10, ss0
ss_pack_stride x9, x6, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x9, x6, x10, ss2
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 224
ss_pack_stride x9, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x9, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x6, x6, 0, l2
ss_pack_shape x6, x9, x19, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x9, x19, x19, ss5
lui x20, 37
addi x20, x20, 3072
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65610
addi x22, x22, 2048
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x0
addi x26, x0, 7
l2_load_w_conf x26, x26, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x29, x0, 8
addi x27, x0, 43
add x27, x29, x27
lui x28, 262144
addi x28, x28, 0
l2_load_w x28, x27, x18
ss_pack_stride x9, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x30, x0, 4
ss_pack_shape x6, x9, x30, x19, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x9, x9, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 57
add x31, x2, x31
lui x1, 196608
addi x1, x1, 0
l2_load_w x1, x31, x4
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x9, x6, ss7
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x3, x30, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x9, x0
ss_pack_shape x6, x9, x30, x19, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x6
ccr_clr 4
addi x7, x0, 14
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_stride x6, x19, x19, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x30, x19, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x6, x6, x30, x19, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x30, x19, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x30, x19, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x8, 65610
addi x8, x8, 2944
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x11, 65536
addi x11, x11, 1792
dm_store_of 0, 0, x11, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x13, 65610
addi x13, x13, 3840
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x14, 65537
addi x14, x14, 3584
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x15, 65610
addi x15, x15, 640
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x17, 65537
addi x17, x17, 1280
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x10, 65610
addi x10, x10, 1536
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x20, 65538
addi x20, x20, 3072
dm_store_of 0, 0, x20, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x21, 65611
addi x21, x21, 2432
dm_load_l1 0, 0, x21, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x16, 65538
addi x16, x16, 768
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x23, 65611
addi x23, x23, 3328
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x25, 65539
addi x25, x25, 2560
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x26, 65611
addi x26, x26, 128
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x27, 65539
addi x27, x27, 256
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x29, 65611
addi x29, x29, 1024
dm_load_l1 0, 0, x29, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x18, 65540
addi x18, x18, 2048
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x22, 65611
addi x22, x22, 1920
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x31, 65540
addi x31, x31, 3840
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x2, 65612
addi x2, x2, 2816
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x4, 65540
addi x4, x4, 1536
dm_store_of 0, 0, x4, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x3, 65612
addi x3, x3, 3712
dm_load_l1 0, 0, x3, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x5, 65541
addi x5, x5, 3328
dm_store_of 0, 0, x5, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x12, 65612
addi x12, x12, 512
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x8, 65541
addi x8, x8, 1024
dm_store_of 0, 0, x8, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x11, 65612
addi x11, x11, 1408
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x13, 65542
addi x13, x13, 2816
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x14, 65613
addi x14, x14, 2304
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x15, 65542
addi x15, x15, 512
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x17, 65613
addi x17, x17, 3200
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x10, 65543
addi x10, x10, 2304
dm_store_of 0, 0, x10, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x20, 65613
addi x20, x20, 0
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x21, 65543
addi x21, x21, 0
dm_store_of 0, 0, x21, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x16, 65613
addi x16, x16, 896
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x23, 65543
addi x23, x23, 1792
dm_store_of 0, 0, x23, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x25, 65613
addi x25, x25, 1792
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x26, 65544
addi x26, x26, 3584
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x27, 65614
addi x27, x27, 2688
dm_load_l1 0, 0, x27, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x29, 65544
addi x29, x29, 1280
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x18, 65614
addi x18, x18, 3584
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x22, 65545
addi x22, x22, 3072
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x31, 65614
addi x31, x31, 384
dm_load_l1 0, 0, x31, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x2, 65545
addi x2, x2, 768
dm_store_of 0, 0, x2, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x4, 65614
addi x4, x4, 1280
dm_load_l1 0, 0, x4, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x3, 65546
addi x3, x3, 2560
dm_store_of 0, 0, x3, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x5, 65615
addi x5, x5, 2176
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x12, 65546
addi x12, x12, 256
dm_store_of 0, 0, x12, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x8, 65615
addi x8, x8, 3072
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x11, 65547
addi x11, x11, 2048
dm_store_of 0, 0, x11, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x13, 65615
addi x13, x13, 3968
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x14, 65547
addi x14, x14, 3840
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x15, 65615
addi x15, x15, 768
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x17, 65547
addi x17, x17, 1536
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x10, 65615
addi x10, x10, 1664
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x20, 65548
addi x20, x20, 3328
dm_store_of 0, 0, x20, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x21, 65616
addi x21, x21, 2560
dm_load_l1 0, 0, x21, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x16, 65548
addi x16, x16, 1024
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x23, 65616
addi x23, x23, 3456
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x25, 65549
addi x25, x25, 2816
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x26, 65616
addi x26, x26, 256
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x27, 65549
addi x27, x27, 512
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x29, 65616
addi x29, x29, 1152
dm_load_l1 0, 0, x29, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x18, 65550
addi x18, x18, 2304
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x22, 65617
addi x22, x22, 2048
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x31, 65550
addi x31, x31, 0
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x2, 65617
addi x2, x2, 2944
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x4, 65550
addi x4, x4, 1792
dm_store_of 0, 0, x4, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x3, 65617
addi x3, x3, 3840
dm_load_l1 0, 0, x3, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x5, 65551
addi x5, x5, 3584
dm_store_of 0, 0, x5, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x12, 65617
addi x12, x12, 640
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x8, 65551
addi x8, x8, 1280
dm_store_of 0, 0, x8, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x11, 65617
addi x11, x11, 1536
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x13, 65552
addi x13, x13, 3072
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x14, 65618
addi x14, x14, 2432
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x15, 65552
addi x15, x15, 768
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x17, 65618
addi x17, x17, 3328
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x10, 65553
addi x10, x10, 2560
dm_store_of 0, 0, x10, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x20, 65618
addi x20, x20, 128
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x21, 65553
addi x21, x21, 256
dm_store_of 0, 0, x21, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x16, 65618
addi x16, x16, 1024
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x23, 65554
addi x23, x23, 2048
dm_store_of 0, 0, x23, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x25, 65618
addi x25, x25, 1920
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x26, 65554
addi x26, x26, 3840
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x27, 65619
addi x27, x27, 2816
dm_load_l1 0, 0, x27, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x29, 65554
addi x29, x29, 1536
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x18, 65619
addi x18, x18, 3712
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x22, 65555
addi x22, x22, 3328
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x31, 65619
addi x31, x31, 512
dm_load_l1 0, 0, x31, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x2, 65555
addi x2, x2, 1024
dm_store_of 0, 0, x2, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x4, 65619
addi x4, x4, 1408
dm_load_l1 0, 0, x4, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x3, 65556
addi x3, x3, 2816
dm_store_of 0, 0, x3, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x5, 65620
addi x5, x5, 2304
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x12, 65556
addi x12, x12, 512
dm_store_of 0, 0, x12, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x8, 65620
addi x8, x8, 3200
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x11, 65557
addi x11, x11, 2304
dm_store_of 0, 0, x11, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x13, 65620
addi x13, x13, 0
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x14, 65557
addi x14, x14, 0
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x15, 65620
addi x15, x15, 896
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x17, 65557
addi x17, x17, 1792
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x10, 65620
addi x10, x10, 1792
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x20, 65558
addi x20, x20, 3584
dm_store_of 0, 0, x20, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x21, 65621
addi x21, x21, 2688
dm_load_l1 0, 0, x21, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x16, 65558
addi x16, x16, 1280
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x23, 65621
addi x23, x23, 3584
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x25, 65559
addi x25, x25, 3072
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x26, 65621
addi x26, x26, 384
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x27, 65559
addi x27, x27, 768
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
lui x29, 65621
addi x29, x29, 1280
dm_load_l1 0, 0, x29, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
lui x18, 65560
addi x18, x18, 2560
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x6, x9, x30, x19, ss6
ccr_decl x6
ccr_clr 2
lui x22, 65622
addi x22, x22, 2176
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x9, x6, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x28, x7, pu, 1
ss_pack_shape x6, x6, x30, x19, ss2
ccr_decl x6
ccr_set 0, 1
lui x31, 65560
addi x31, x31, 256
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
lui x2, 12
addi x2, x2, 1024
ss_pack_stride x6, x6, x2, ss3
ss_pack_stride x6, x6, x2, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x2, ss0
ccr_decl x6
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
lui x4, 65536
addi x4, x4, 0
l2_store x3, x4, ss0
end x0
# case: test_reshape[1-16-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 448
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 464
addi x4, x0, 12
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 476
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 2
addi x7, x7, 483
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 2
addi x9, x9, 485
addi x10, x0, 1
mmu_conf x9, x10, 5
lui x11, 4
addi x11, x11, 896
ss_pack_stride x10, x10, x11, ss0
ss_pack_stride x10, x10, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x10, x10, x11, ss2
ccr_decl x10
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 28
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 262144
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 4
addi x21, x0, 60
addi x22, x0, 72
ss_pack_stride x20, x21, x22, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x21, x22, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x10, x10, 0, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_dest x11, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x25, x0, 3
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65570
addi x24, x24, 3072
mfu_act1_compute x24, x13, x0, x17
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 56
add x26, x28, x26
lui x27, 327680
addi x27, x27, 0
addi x29, x0, 15
l2_load_w x27, x26, x29
addi x30, x0, 112
l2_load_w_conf x30, x30, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x3, x0, 8
addi x31, x0, 72
add x31, x3, x31
lui x2, 196608
addi x2, x2, 0
l2_load_w x2, x31, x19
ss_pack_stride x20, x21, x22, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x4, x0, 14
ss_pack_shape x10, x20, x4, x22, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x5, x0, 64
l2_load_w_conf x5, x5, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x8, x0, 8
addi x6, x0, 296
add x6, x8, x6
lui x7, 131072
addi x7, x7, 0
l2_load_w x7, x6, x25
addi x9, x0, 24
dm_load_w_conf 0, 0, 1, 1, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x20, x1, ss7
addi x12, x0, 2
ccr_decl x12
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_stride x9, x4, x22, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x20, x0
ss_pack_shape x10, x20, x4, x22, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x14, x0, 31
pu_fetchif_conf_deq 0, 0, x14, x0, u8
ccr_decl x10
ccr_clr 4
addi x15, x0, 224
dm_load_act0 0, 0, x2, x15, pu, 1
ss_pack_stride x1, x21, x22, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x10, x1, x4, x22, ss2
dm_store_of 0, 0, x13, ss2, pu
ss_pack_shape x10, x1, x4, x22, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x1, x4, x22, ss5
pu_of_conf1 0, 0, x1, x0, ss5
ss_pack_shape x10, x1, x4, x22, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x16, 65570
addi x16, x16, 4080
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x15, pu, 1
ss_pack_shape x10, x1, x4, x22, ss2
lui x18, 65536
addi x18, x18, 2016
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x11, 65570
addi x11, x11, 992
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x15, pu, 1
ss_pack_shape x10, x1, x4, x22, ss2
lui x23, 65537
addi x23, x23, 4032
dm_store_of 0, 0, x23, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x17, 65570
addi x17, x17, 2000
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x15, pu, 1
ss_pack_shape x10, x1, x4, x22, ss2
lui x26, 65537
addi x26, x26, 1952
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x20, x22, ss3
ccr_decl x10
ccr_clr 2
lui x28, 65571
addi x28, x28, 3008
dm_load_l1 0, 0, x28, x0, ss3, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_stride x9, x20, x22, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x20, x20, x22, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
dm_load_act0 0, 0, x2, x15, pu, 1
ss_pack_shape x10, x1, x20, x22, ss4
ccr_decl x10
ccr_set 0, 1
lui x29, 65538
addi x29, x29, 3968
dm_store_of 0, 0, x29, ss4, pu
ss_pack_shape x10, x1, x20, x22, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x1, x20, x22, ss1
pu_of_conf1 0, 0, x1, x0, ss1
ss_pack_shape x10, x1, x20, x22, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x30, 1
addi x30, x30, 224
ss_pack_stride x1, x10, x30, ss5
ss_pack_stride x1, x10, x30, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x10, x1, x10, x30, ss6
ccr_decl x10
ccr_clr 0
lw x3, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x3, x31
l2_store x31, x13, ss6
end x0
# case: test_reshape[1-16-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 25
addi x2, x2, 2048
mmu_conf x1, x2, 1
lui x3, 25
addi x3, x3, 2064
addi x4, x0, 12
mmu_conf x3, x4, 2
lui x5, 25
addi x5, x5, 2076
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 25
addi x7, x7, 2083
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 25
addi x9, x9, 2085
addi x10, x0, 1
mmu_conf x9, x10, 5
addi x11, x0, 3
lui x12, 12
addi x12, x12, 1024
ss_pack_stride x11, x10, x12, ss0
ss_pack_stride x11, x10, x12, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x11, x10, x12, ss2
ccr_decl x10
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 65536
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 21
l2_load_w_conf x16, x16, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x19, x0, 8
lui x17, 0
addi x17, x17, 0
add x17, x19, x17
lui x18, 262144
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 224
ss_pack_stride x11, x21, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x11, x21, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x12, x10, x10, 0, l2
ss_pack_shape x10, x11, x21, x21, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x11, x21, x21, ss5
lui x22, 37
addi x22, x22, 3072
mfu_act1_conf_dest x22, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x11
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65928
addi x24, x24, 0
mfu_act1_compute x24, x14, x0, x18
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 42
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
addi x28, x0, 15
l2_load_w x26, x25, x28
addi x29, x0, 112
l2_load_w_conf x29, x29, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x2, x0, 8
addi x30, x0, 58
add x30, x2, x30
lui x31, 196608
addi x31, x31, 0
l2_load_w x31, x30, x20
ss_pack_stride x11, x21, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x3, x0, 4
ss_pack_shape x10, x11, x3, x21, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x4, x0, 48
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x7, x0, 8
addi x5, x0, 282
add x5, x7, x5
lui x6, 131072
addi x6, x6, 0
l2_load_w x6, x5, x8
addi x9, x0, 24
dm_load_w_conf 0, 0, 1, 1, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x11, x1, ss7
ccr_decl x8
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x9, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x11, x0
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x13, x0, 31
pu_fetchif_conf_deq 0, 0, x13, x0, u8
ccr_decl x10
ccr_clr 4
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_stride x1, x21, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x10, x1, x3, x21, ss2
dm_store_of 0, 0, x14, ss2, pu
ss_pack_shape x10, x1, x3, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x1, x3, x21, ss5
pu_of_conf1 0, 0, x1, x0, ss5
ss_pack_shape x10, x1, x3, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65928
addi x15, x15, 896
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x16, 65536
addi x16, x16, 1792
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x17, 65928
addi x17, x17, 1792
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x19, 65537
addi x19, x19, 3584
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x12, 65929
addi x12, x12, 2688
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x22, 65537
addi x22, x22, 1280
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x23, 65929
addi x23, x23, 3584
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x18, 65538
addi x18, x18, 3072
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x25, 65929
addi x25, x25, 384
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x27, 65538
addi x27, x27, 768
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65929
addi x28, x28, 1280
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x29, 65539
addi x29, x29, 2560
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x30, 65930
addi x30, x30, 2176
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x2, 65539
addi x2, x2, 256
dm_store_of 0, 0, x2, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x20, 65930
addi x20, x20, 3072
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x24, 65540
addi x24, x24, 2048
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65930
addi x4, x4, 3968
dm_load_l1 0, 0, x4, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x5, 65540
addi x5, x5, 3840
dm_store_of 0, 0, x5, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x7, 65930
addi x7, x7, 768
dm_load_l1 0, 0, x7, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x8, 65540
addi x8, x8, 1536
dm_store_of 0, 0, x8, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x9, 65930
addi x9, x9, 1664
dm_load_l1 0, 0, x9, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x13, 65541
addi x13, x13, 3328
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x14, 65931
addi x14, x14, 2560
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x15, 65541
addi x15, x15, 1024
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x16, 65931
addi x16, x16, 3456
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x17, 65542
addi x17, x17, 2816
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x19, 65931
addi x19, x19, 256
dm_load_l1 0, 0, x19, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x12, 65542
addi x12, x12, 512
dm_store_of 0, 0, x12, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65931
addi x22, x22, 1152
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x23, 65543
addi x23, x23, 2304
dm_store_of 0, 0, x23, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65932
addi x18, x18, 2048
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x25, 65543
addi x25, x25, 0
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x27, 65932
addi x27, x27, 2944
dm_load_l1 0, 0, x27, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x28, 65543
addi x28, x28, 1792
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x29, 65932
addi x29, x29, 3840
dm_load_l1 0, 0, x29, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x30, 65544
addi x30, x30, 3584
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65932
addi x2, x2, 640
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x20, 65544
addi x20, x20, 1280
dm_store_of 0, 0, x20, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x24, 65932
addi x24, x24, 1536
dm_load_l1 0, 0, x24, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x4, 65545
addi x4, x4, 3072
dm_store_of 0, 0, x4, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x5, 65933
addi x5, x5, 2432
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x7, 65545
addi x7, x7, 768
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x8, 65933
addi x8, x8, 3328
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x9, 65546
addi x9, x9, 2560
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x13, 65933
addi x13, x13, 128
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x14, 65546
addi x14, x14, 256
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65933
addi x15, x15, 1024
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x16, 65547
addi x16, x16, 2048
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x17, 65933
addi x17, x17, 1920
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x19, 65547
addi x19, x19, 3840
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x12, 65934
addi x12, x12, 2816
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x22, 65547
addi x22, x22, 1536
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x23, 65934
addi x23, x23, 3712
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x18, 65548
addi x18, x18, 3328
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x25, 65934
addi x25, x25, 512
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x27, 65548
addi x27, x27, 1024
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65934
addi x28, x28, 1408
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x29, 65549
addi x29, x29, 2816
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x30, 65935
addi x30, x30, 2304
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x2, 65549
addi x2, x2, 512
dm_store_of 0, 0, x2, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x20, 65935
addi x20, x20, 3200
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x24, 65550
addi x24, x24, 2304
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65935
addi x4, x4, 0
dm_load_l1 0, 0, x4, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x5, 65550
addi x5, x5, 0
dm_store_of 0, 0, x5, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x7, 65935
addi x7, x7, 896
dm_load_l1 0, 0, x7, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x8, 65550
addi x8, x8, 1792
dm_store_of 0, 0, x8, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x9, 65935
addi x9, x9, 1792
dm_load_l1 0, 0, x9, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x13, 65551
addi x13, x13, 3584
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x14, 65936
addi x14, x14, 2688
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x15, 65551
addi x15, x15, 1280
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x16, 65936
addi x16, x16, 3584
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x17, 65552
addi x17, x17, 3072
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x19, 65936
addi x19, x19, 384
dm_load_l1 0, 0, x19, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x12, 65552
addi x12, x12, 768
dm_store_of 0, 0, x12, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65936
addi x22, x22, 1280
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x23, 65553
addi x23, x23, 2560
dm_store_of 0, 0, x23, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65937
addi x18, x18, 2176
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x25, 65553
addi x25, x25, 256
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x27, 65937
addi x27, x27, 3072
dm_load_l1 0, 0, x27, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x28, 65554
addi x28, x28, 2048
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x29, 65937
addi x29, x29, 3968
dm_load_l1 0, 0, x29, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x30, 65554
addi x30, x30, 3840
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65937
addi x2, x2, 768
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x20, 65554
addi x20, x20, 1536
dm_store_of 0, 0, x20, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x24, 65937
addi x24, x24, 1664
dm_load_l1 0, 0, x24, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x4, 65555
addi x4, x4, 3328
dm_store_of 0, 0, x4, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x5, 65938
addi x5, x5, 2560
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x7, 65555
addi x7, x7, 1024
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x8, 65938
addi x8, x8, 3456
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x9, 65556
addi x9, x9, 2816
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x13, 65938
addi x13, x13, 256
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x14, 65556
addi x14, x14, 512
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65938
addi x15, x15, 1152
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x16, 65557
addi x16, x16, 2304
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x17, 65939
addi x17, x17, 2048
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x19, 65557
addi x19, x19, 0
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x12, 65939
addi x12, x12, 2944
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x22, 65557
addi x22, x22, 1792
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x23, 65939
addi x23, x23, 3840
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x18, 65558
addi x18, x18, 3584
dm_store_of 0, 0, x18, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x25, 65939
addi x25, x25, 640
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x27, 65558
addi x27, x27, 1280
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65939
addi x28, x28, 1536
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x29, 65559
addi x29, x29, 3072
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x30, 65940
addi x30, x30, 2432
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x2, 65559
addi x2, x2, 768
dm_store_of 0, 0, x2, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x20, 65940
addi x20, x20, 3328
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
lui x24, 65560
addi x24, x24, 2560
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
ccr_decl x10
ccr_clr 2
lui x4, 65940
addi x4, x4, 128
dm_load_l1 0, 0, x4, x0, ss6, if_
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x3, x21, ss2
ccr_decl x10
ccr_set 0, 1
lui x5, 65560
addi x5, x5, 256
dm_store_of 0, 0, x5, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
lui x7, 12
addi x7, x7, 1024
ss_pack_stride x1, x10, x7, ss3
ss_pack_stride x1, x10, x7, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x10, x1, x10, x7, ss0
ccr_decl x10
ccr_clr 0
lw x13, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x13, x9
lui x8, 65536
addi x8, x8, 0
l2_store x9, x8, ss0
end x0
# case: test_reshape[1-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 3
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2179
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2181
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2183
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 4
addi x10, x10, 896
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 60
addi x21, x0, 72
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65544
addi x23, x23, 1792
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x31, x0, 14
ss_pack_shape x9, x19, x31, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x1, x0, 12
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x5, x0, 8
addi x2, x0, 101
add x2, x5, x2
lui x3, 131072
addi x3, x3, 0
l2_load_w x3, x2, x4
addi x7, x0, 24
dm_load_w_conf 0, 0, 1, 1, x7
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_stride x7, x31, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x31, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
ccr_decl x9
ccr_clr 4
addi x11, x0, 42
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_stride x4, x20, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x9, x4, x31, x21, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x4, x31, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x31, x21, ss5
pu_of_conf1 0, 0, x4, x0, ss5
ss_pack_shape x9, x4, x31, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x13, 65545
addi x13, x13, 2800
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x4, x31, x21, ss2
lui x14, 65536
addi x14, x14, 2016
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x15, 65545
addi x15, x15, 3808
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x4, x31, x21, ss2
lui x17, 65537
addi x17, x17, 4032
dm_store_of 0, 0, x17, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x10, 65545
addi x10, x10, 720
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x4, x31, x21, ss2
lui x22, 65537
addi x22, x22, 1952
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x19, x21, ss3
ccr_decl x9
ccr_clr 2
lui x16, 65545
addi x16, x16, 1728
dm_load_l1 0, 0, x16, x0, ss3, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_stride x7, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x4, x19, x21, ss4
ccr_decl x9
ccr_set 0, 1
lui x24, 65538
addi x24, x24, 3968
dm_store_of 0, 0, x24, ss4, pu
ss_pack_shape x9, x4, x19, x21, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x19, x21, ss1
pu_of_conf1 0, 0, x4, x0, ss1
ss_pack_shape x9, x4, x19, x21, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x26, 3
addi x26, x26, 672
ss_pack_stride x9, x9, x26, ss5
ss_pack_stride x9, x9, x26, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x26, ss6
ccr_decl x9
ccr_clr 0
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x12, ss6
end x0
# case: test_reshape[1-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 3
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2451
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2453
mmu_conf x7, x6, 4
lui x8, 5
addi x8, x8, 2455
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 12
addi x10, x10, 1024
ss_pack_stride x4, x9, x10, ss0
ss_pack_stride x4, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x4, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 224
ss_pack_stride x4, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x4, x19, x19, ss5
lui x20, 37
addi x20, x20, 3072
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65610
addi x22, x22, 2048
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x6
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 45
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x4, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x29, x0, 4
ss_pack_shape x9, x4, x29, x19, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
addi x30, x0, 9
l2_load_w_conf x30, x30, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 87
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x6
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x4, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x3, x29, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x4, x0
ss_pack_shape x9, x4, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x9
ccr_clr 4
addi x7, x0, 42
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_stride x4, x19, x19, ss3
dm_store_of_conf 0, 0, ss3, fp16
ss_pack_shape x9, x4, x29, x19, ss6
dm_store_of 0, 0, x12, ss6, pu
ss_pack_shape x9, x4, x29, x19, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x29, x19, ss1
pu_of_conf1 0, 0, x4, x0, ss1
ss_pack_shape x9, x4, x29, x19, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x8, 65610
addi x8, x8, 2944
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x11, 65536
addi x11, x11, 1792
dm_store_of 0, 0, x11, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x13, 65610
addi x13, x13, 3840
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x15, 65537
addi x15, x15, 3584
dm_store_of 0, 0, x15, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x17, 65610
addi x17, x17, 640
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x10, 65537
addi x10, x10, 1280
dm_store_of 0, 0, x10, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x20, 65610
addi x20, x20, 1536
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x21, 65538
addi x21, x21, 3072
dm_store_of 0, 0, x21, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x16, 65611
addi x16, x16, 2432
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x23, 65538
addi x23, x23, 768
dm_store_of 0, 0, x23, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x25, 65611
addi x25, x25, 3328
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x14, 65539
addi x14, x14, 2560
dm_store_of 0, 0, x14, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x26, 65611
addi x26, x26, 128
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x28, 65539
addi x28, x28, 256
dm_store_of 0, 0, x28, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x18, 65611
addi x18, x18, 1024
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x22, 65540
addi x22, x22, 2048
dm_store_of 0, 0, x22, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x30, 65611
addi x30, x30, 1920
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x31, 65540
addi x31, x31, 3840
dm_store_of 0, 0, x31, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x2, 65612
addi x2, x2, 2816
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x6, 65540
addi x6, x6, 1536
dm_store_of 0, 0, x6, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x3, 65612
addi x3, x3, 3712
dm_load_l1 0, 0, x3, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x5, 65541
addi x5, x5, 3328
dm_store_of 0, 0, x5, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x12, 65612
addi x12, x12, 512
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x8, 65541
addi x8, x8, 1024
dm_store_of 0, 0, x8, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x11, 65612
addi x11, x11, 1408
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x13, 65542
addi x13, x13, 2816
dm_store_of 0, 0, x13, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x15, 65613
addi x15, x15, 2304
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x17, 65542
addi x17, x17, 512
dm_store_of 0, 0, x17, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x10, 65613
addi x10, x10, 3200
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x20, 65543
addi x20, x20, 2304
dm_store_of 0, 0, x20, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x21, 65613
addi x21, x21, 0
dm_load_l1 0, 0, x21, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x16, 65543
addi x16, x16, 0
dm_store_of 0, 0, x16, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x23, 65613
addi x23, x23, 896
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x25, 65543
addi x25, x25, 1792
dm_store_of 0, 0, x25, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x14, 65613
addi x14, x14, 1792
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x26, 65544
addi x26, x26, 3584
dm_store_of 0, 0, x26, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x28, 65614
addi x28, x28, 2688
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x18, 65544
addi x18, x18, 1280
dm_store_of 0, 0, x18, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x22, 65614
addi x22, x22, 3584
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x30, 65545
addi x30, x30, 3072
dm_store_of 0, 0, x30, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x31, 65614
addi x31, x31, 384
dm_load_l1 0, 0, x31, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x2, 65545
addi x2, x2, 768
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x6, 65614
addi x6, x6, 1280
dm_load_l1 0, 0, x6, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x3, 65546
addi x3, x3, 2560
dm_store_of 0, 0, x3, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x5, 65615
addi x5, x5, 2176
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x12, 65546
addi x12, x12, 256
dm_store_of 0, 0, x12, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x8, 65615
addi x8, x8, 3072
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x11, 65547
addi x11, x11, 2048
dm_store_of 0, 0, x11, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x13, 65615
addi x13, x13, 3968
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x15, 65547
addi x15, x15, 3840
dm_store_of 0, 0, x15, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x17, 65615
addi x17, x17, 768
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x10, 65547
addi x10, x10, 1536
dm_store_of 0, 0, x10, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x20, 65615
addi x20, x20, 1664
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x21, 65548
addi x21, x21, 3328
dm_store_of 0, 0, x21, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x16, 65616
addi x16, x16, 2560
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x23, 65548
addi x23, x23, 1024
dm_store_of 0, 0, x23, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x25, 65616
addi x25, x25, 3456
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x14, 65549
addi x14, x14, 2816
dm_store_of 0, 0, x14, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x26, 65616
addi x26, x26, 256
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x28, 65549
addi x28, x28, 512
dm_store_of 0, 0, x28, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x18, 65616
addi x18, x18, 1152
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x22, 65550
addi x22, x22, 2304
dm_store_of 0, 0, x22, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x30, 65617
addi x30, x30, 2048
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x31, 65550
addi x31, x31, 0
dm_store_of 0, 0, x31, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x2, 65617
addi x2, x2, 2944
dm_load_l1 0, 0, x2, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x6, 65550
addi x6, x6, 1792
dm_store_of 0, 0, x6, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x3, 65617
addi x3, x3, 3840
dm_load_l1 0, 0, x3, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x5, 65551
addi x5, x5, 3584
dm_store_of 0, 0, x5, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x12, 65617
addi x12, x12, 640
dm_load_l1 0, 0, x12, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x8, 65551
addi x8, x8, 1280
dm_store_of 0, 0, x8, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x11, 65617
addi x11, x11, 1536
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x13, 65552
addi x13, x13, 3072
dm_store_of 0, 0, x13, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x15, 65618
addi x15, x15, 2432
dm_load_l1 0, 0, x15, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x17, 65552
addi x17, x17, 768
dm_store_of 0, 0, x17, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x10, 65618
addi x10, x10, 3328
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x20, 65553
addi x20, x20, 2560
dm_store_of 0, 0, x20, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x21, 65618
addi x21, x21, 128
dm_load_l1 0, 0, x21, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x16, 65553
addi x16, x16, 256
dm_store_of 0, 0, x16, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x23, 65618
addi x23, x23, 1024
dm_load_l1 0, 0, x23, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x25, 65554
addi x25, x25, 2048
dm_store_of 0, 0, x25, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x14, 65618
addi x14, x14, 1920
dm_load_l1 0, 0, x14, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x26, 65554
addi x26, x26, 3840
dm_store_of 0, 0, x26, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x28, 65619
addi x28, x28, 2816
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x18, 65554
addi x18, x18, 1536
dm_store_of 0, 0, x18, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x22, 65619
addi x22, x22, 3712
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x30, 65555
addi x30, x30, 3328
dm_store_of 0, 0, x30, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x31, 65619
addi x31, x31, 512
dm_load_l1 0, 0, x31, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x2, 65555
addi x2, x2, 1024
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x6, 65619
addi x6, x6, 1408
dm_load_l1 0, 0, x6, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x3, 65556
addi x3, x3, 2816
dm_store_of 0, 0, x3, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x5, 65620
addi x5, x5, 2304
dm_load_l1 0, 0, x5, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x12, 65556
addi x12, x12, 512
dm_store_of 0, 0, x12, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x8, 65620
addi x8, x8, 3200
dm_load_l1 0, 0, x8, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x11, 65557
addi x11, x11, 2304
dm_store_of 0, 0, x11, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x13, 65620
addi x13, x13, 0
dm_load_l1 0, 0, x13, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x15, 65557
addi x15, x15, 0
dm_store_of 0, 0, x15, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x17, 65620
addi x17, x17, 896
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x10, 65557
addi x10, x10, 1792
dm_store_of 0, 0, x10, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x20, 65620
addi x20, x20, 1792
dm_load_l1 0, 0, x20, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x21, 65558
addi x21, x21, 3584
dm_store_of 0, 0, x21, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x16, 65621
addi x16, x16, 2688
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x23, 65558
addi x23, x23, 1280
dm_store_of 0, 0, x23, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x25, 65621
addi x25, x25, 3584
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x14, 65559
addi x14, x14, 3072
dm_store_of 0, 0, x14, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x26, 65621
addi x26, x26, 384
dm_load_l1 0, 0, x26, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x28, 65559
addi x28, x28, 768
dm_store_of 0, 0, x28, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
lui x18, 65621
addi x18, x18, 1280
dm_load_l1 0, 0, x18, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
lui x22, 65560
addi x22, x22, 2560
dm_store_of 0, 0, x22, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x4, x29, x19, ss6
ccr_decl x9
ccr_clr 2
lui x30, 65622
addi x30, x30, 2176
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x4, x4, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
dm_load_act0 0, 0, x27, x7, pu, 1
ss_pack_shape x9, x4, x29, x19, ss6
ccr_decl x9
ccr_set 0, 1
lui x31, 65560
addi x31, x31, 256
dm_store_of 0, 0, x31, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
lui x2, 12
addi x2, x2, 1024
ss_pack_stride x4, x9, x2, ss2
ss_pack_stride x4, x9, x2, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x9, x4, x9, x2, ss5
ccr_decl x9
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
lui x6, 65536
addi x6, x6, 0
l2_store x3, x6, ss5
end x0
# case: test_reshape[3-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 7
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2183
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2185
addi x8, x0, 1
mmu_conf x7, x8, 4
lui x9, 1
addi x9, x9, 2186
mmu_conf x9, x8, 5
lui x10, 4
addi x10, x10, 896
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 60
addi x21, x0, 72
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65544
addi x23, x23, 1792
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x31, x0, 14
ss_pack_shape x8, x19, x31, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x1, x0, 36
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x5, x0, 8
addi x2, x0, 71
add x2, x5, x2
lui x3, 131072
addi x3, x3, 0
l2_load_w x3, x2, x24
addi x6, x0, 216
dm_load_w_conf 0, 0, 3, 3, x6
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
addi x7, x0, 2
ccr_decl x7
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x3, x26, ss7, pu
addi x9, x0, 24
ss_pack_stride x9, x31, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x31, x21, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x11, x0, 31
pu_fetchif_conf_deq 0, 0, x11, x0, u8
ccr_decl x8
ccr_clr 4
dm_load_act0 0, 0, x29, x31, pu, 1
addi x13, x0, 58
addi x14, x0, 70
ss_pack_stride x8, x13, x14, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x15, x0, 12
ss_pack_shape x8, x8, x15, x14, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x8, x8, x15, x14, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x15, x14, ss5
pu_of_conf1 0, 0, x8, x0, ss5
ss_pack_shape x8, x8, x15, x14, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x31, x21, ss6
lui x17, 65545
addi x17, x17, 2656
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x8, x8, x15, x14, ss2
lui x10, 65536
addi x10, x10, 1680
dm_store_of 0, 0, x10, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x8, x19, x31, x21, ss6
lui x22, 65545
addi x22, x22, 3520
dm_load_l1 0, 0, x22, x0, ss6, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x8, x8, x15, x14, ss2
lui x16, 65537
addi x16, x16, 3360
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x8, x19, x31, x21, ss6
lui x25, 65545
addi x25, x25, 288
dm_load_l1 0, 0, x25, x0, ss6, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x31, pu, 1
ss_pack_shape x8, x8, x15, x14, ss2
lui x27, 65537
addi x27, x27, 944
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x8, x19, x15, x21, ss3
ccr_decl x8
ccr_clr 2
lui x4, 65545
addi x4, x4, 1152
dm_load_l1 0, 0, x4, x0, ss3, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
ss_pack_stride x9, x15, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x19, x15, x21, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
dm_load_act0 0, 0, x29, x31, pu, 1
addi x28, x0, 10
ss_pack_shape x8, x8, x28, x14, ss4
ccr_decl x8
ccr_set 0, 1
lui x30, 65538
addi x30, x30, 2624
dm_store_of 0, 0, x30, ss4, pu
ss_pack_shape x8, x8, x28, x14, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x28, x14, ss1
pu_of_conf1 0, 0, x8, x0, ss1
ss_pack_shape x8, x8, x28, x14, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x18, 1
addi x18, x18, 4060
ss_pack_stride x8, x8, x18, ss5
ss_pack_stride x8, x8, x18, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x18, ss6
ccr_decl x8
ccr_clr 0
lw x23, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x23, x20
l2_store x20, x12, ss6
end x0
# case: test_reshape[3-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 7
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2455
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2457
addi x8, x0, 1
mmu_conf x7, x8, 4
lui x9, 5
addi x9, x9, 2458
mmu_conf x9, x8, 5
addi x10, x0, 3
lui x11, 12
addi x11, x11, 1024
ss_pack_stride x10, x8, x11, ss0
ss_pack_stride x10, x8, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x8, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 224
ss_pack_stride x10, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x10, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
ss_pack_shape x8, x10, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x10, x20, x20, ss5
lui x21, 37
addi x21, x21, 3072
mfu_act1_conf_dest x21, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65610
addi x23, x23, 2048
mfu_act1_compute x23, x13, x0, x17
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x29, x0, 8
addi x27, x0, 43
add x27, x29, x27
lui x28, 262144
addi x28, x28, 0
l2_load_w x28, x27, x19
ss_pack_stride x10, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x30, x0, 4
ss_pack_shape x8, x10, x30, x20, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 18
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 57
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x6
addi x5, x0, 144
dm_load_w_conf 0, 0, 2, 3, x5
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 2, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
addi x7, x0, 24
ss_pack_stride x7, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
addi x12, x0, 222
ss_pack_stride x8, x10, x12, ss1
pu_of_conf1 0, 0, x8, x0, ss1
ss_pack_shape x8, x8, x10, x12, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x14, 65610
addi x14, x14, 2496
dm_load_l1 0, 0, x14, x0, ss5, if_
addi x15, x0, 9
l2_load_w_conf x15, x15, i8, i8, 0
ccr_decl x8
ccr_set 6, 1
lw x11, x0, 8
addi x16, x0, 75
add x16, x11, x16
lui x18, 131072
addi x18, x18, 144
l2_load_w x18, x16, x6
addi x21, x0, 72
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 6
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ccr_decl x8
ccr_clr 4
addi x22, x0, 14
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_stride x8, x12, x12, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x8, x10, x12, ss2
dm_store_of 0, 0, x13, ss2, pu
ss_pack_shape x8, x8, x10, x12, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65610
addi x17, x17, 2720
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65610
addi x24, x24, 3168
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65536
addi x26, x26, 1332
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65610
addi x4, x4, 3392
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65610
addi x27, x27, 3840
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65537
addi x29, x29, 2664
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65610
addi x19, x19, 4064
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65610
addi x23, x23, 416
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65537
addi x31, x31, 3996
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65610
addi x1, x1, 640
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65610
addi x3, x3, 1088
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65537
addi x9, x9, 1232
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65610
addi x14, x14, 1312
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65610
addi x15, x15, 1760
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65538
addi x16, x16, 2564
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65610
addi x11, x11, 1984
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65611
addi x6, x6, 2432
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65538
addi x13, x13, 3896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65611
addi x17, x17, 2656
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65611
addi x24, x24, 3104
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65538
addi x26, x26, 1132
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65611
addi x4, x4, 3328
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65611
addi x27, x27, 3776
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65539
addi x29, x29, 2464
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65611
addi x19, x19, 4000
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65611
addi x23, x23, 352
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65539
addi x31, x31, 3796
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65611
addi x1, x1, 576
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65611
addi x3, x3, 1024
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65539
addi x9, x9, 1032
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65611
addi x14, x14, 1248
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65611
addi x15, x15, 1696
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65540
addi x16, x16, 2364
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65611
addi x11, x11, 1920
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65612
addi x6, x6, 2368
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65540
addi x13, x13, 3696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65612
addi x17, x17, 2592
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65612
addi x24, x24, 3040
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65540
addi x26, x26, 932
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65612
addi x4, x4, 3264
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65612
addi x27, x27, 3712
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65541
addi x29, x29, 2264
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65612
addi x19, x19, 3936
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65612
addi x23, x23, 288
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65541
addi x31, x31, 3596
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65612
addi x1, x1, 512
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65612
addi x3, x3, 960
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65541
addi x9, x9, 832
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65612
addi x14, x14, 1184
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65612
addi x15, x15, 1632
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65542
addi x16, x16, 2164
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65612
addi x11, x11, 1856
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65613
addi x6, x6, 2304
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65542
addi x13, x13, 3496
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65613
addi x17, x17, 2528
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65613
addi x24, x24, 2976
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65542
addi x26, x26, 732
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65613
addi x4, x4, 3200
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65613
addi x27, x27, 3648
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65543
addi x29, x29, 2064
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65613
addi x19, x19, 3872
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65613
addi x23, x23, 224
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65543
addi x31, x31, 3396
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65613
addi x1, x1, 448
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65613
addi x3, x3, 896
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65543
addi x9, x9, 632
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65613
addi x14, x14, 1120
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65613
addi x15, x15, 1568
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65543
addi x16, x16, 1964
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65613
addi x11, x11, 1792
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65614
addi x6, x6, 2240
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65544
addi x13, x13, 3296
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65614
addi x17, x17, 2464
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65614
addi x24, x24, 2912
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65544
addi x26, x26, 532
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65614
addi x4, x4, 3136
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65614
addi x27, x27, 3584
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65544
addi x29, x29, 1864
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65614
addi x19, x19, 3808
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65614
addi x23, x23, 160
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65545
addi x31, x31, 3196
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65614
addi x1, x1, 384
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65614
addi x3, x3, 832
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65545
addi x9, x9, 432
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65614
addi x14, x14, 1056
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65614
addi x15, x15, 1504
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65545
addi x16, x16, 1764
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65614
addi x11, x11, 1728
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65615
addi x6, x6, 2176
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65546
addi x13, x13, 3096
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65615
addi x17, x17, 2400
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65615
addi x24, x24, 2848
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65546
addi x26, x26, 332
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65615
addi x4, x4, 3072
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65615
addi x27, x27, 3520
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65546
addi x29, x29, 1664
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65615
addi x19, x19, 3744
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65615
addi x23, x23, 96
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65547
addi x31, x31, 2996
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65615
addi x1, x1, 320
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65615
addi x3, x3, 768
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65547
addi x9, x9, 232
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65615
addi x14, x14, 992
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65615
addi x15, x15, 1440
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65547
addi x16, x16, 1564
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65615
addi x11, x11, 1664
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65616
addi x6, x6, 2112
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65548
addi x13, x13, 2896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65616
addi x17, x17, 2336
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65616
addi x24, x24, 2784
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65548
addi x26, x26, 132
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65616
addi x4, x4, 3008
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65616
addi x27, x27, 3456
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65548
addi x29, x29, 1464
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65616
addi x19, x19, 3680
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65616
addi x23, x23, 32
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65549
addi x31, x31, 2796
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65616
addi x1, x1, 256
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65616
addi x3, x3, 704
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65549
addi x9, x9, 32
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65616
addi x14, x14, 928
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65616
addi x15, x15, 1376
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65549
addi x16, x16, 1364
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65616
addi x11, x11, 1600
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65617
addi x6, x6, 2048
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65550
addi x13, x13, 2696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65617
addi x17, x17, 2272
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65617
addi x24, x24, 2720
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65550
addi x26, x26, 4028
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65617
addi x4, x4, 2944
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65617
addi x27, x27, 3392
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65550
addi x29, x29, 1264
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65617
addi x19, x19, 3616
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65617
addi x23, x23, 4064
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65551
addi x31, x31, 2596
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65617
addi x1, x1, 192
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65617
addi x3, x3, 640
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65551
addi x9, x9, 3928
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65617
addi x14, x14, 864
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65617
addi x15, x15, 1312
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65551
addi x16, x16, 1164
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65617
addi x11, x11, 1536
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65617
addi x6, x6, 1984
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65552
addi x13, x13, 2496
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65618
addi x17, x17, 2208
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65618
addi x24, x24, 2656
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65552
addi x26, x26, 3828
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65618
addi x4, x4, 2880
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65618
addi x27, x27, 3328
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65552
addi x29, x29, 1064
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65618
addi x19, x19, 3552
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65618
addi x23, x23, 4000
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65553
addi x31, x31, 2396
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65618
addi x1, x1, 128
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65618
addi x3, x3, 576
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65553
addi x9, x9, 3728
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65618
addi x14, x14, 800
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65618
addi x15, x15, 1248
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65553
addi x16, x16, 964
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65618
addi x11, x11, 1472
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65618
addi x6, x6, 1920
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65554
addi x13, x13, 2296
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65619
addi x17, x17, 2144
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65619
addi x24, x24, 2592
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65554
addi x26, x26, 3628
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65619
addi x4, x4, 2816
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65619
addi x27, x27, 3264
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65554
addi x29, x29, 864
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65619
addi x19, x19, 3488
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65619
addi x23, x23, 3936
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65555
addi x31, x31, 2196
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65619
addi x1, x1, 64
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65619
addi x3, x3, 512
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65555
addi x9, x9, 3528
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65619
addi x14, x14, 736
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65619
addi x15, x15, 1184
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65555
addi x16, x16, 764
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65619
addi x11, x11, 1408
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65619
addi x6, x6, 1856
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65556
addi x13, x13, 2096
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65620
addi x17, x17, 2080
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65620
addi x24, x24, 2528
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65556
addi x26, x26, 3428
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65620
addi x4, x4, 2752
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65620
addi x27, x27, 3200
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65556
addi x29, x29, 664
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65620
addi x19, x19, 3424
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65620
addi x23, x23, 3872
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65556
addi x31, x31, 1996
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65620
addi x1, x1, 0
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65620
addi x3, x3, 448
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65557
addi x9, x9, 3328
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65620
addi x14, x14, 672
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65620
addi x15, x15, 1120
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65557
addi x16, x16, 564
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65620
addi x11, x11, 1344
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65620
addi x6, x6, 1792
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65557
addi x13, x13, 1896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65620
addi x17, x17, 2016
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65621
addi x24, x24, 2464
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x26, 65558
addi x26, x26, 3228
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x4, 65621
addi x4, x4, 2688
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x27, 65621
addi x27, x27, 3136
dm_load_l1 0, 0, x27, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x29, 65558
addi x29, x29, 464
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x19, 65621
addi x19, x19, 3360
dm_load_l1 0, 0, x19, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x23, 65621
addi x23, x23, 3808
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x31, 65558
addi x31, x31, 1796
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x1, 65621
addi x1, x1, 4032
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x3, 65621
addi x3, x3, 384
dm_load_l1 0, 0, x3, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x9, 65559
addi x9, x9, 3128
dm_store_of 0, 0, x9, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x14, 65621
addi x14, x14, 608
dm_load_l1 0, 0, x14, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x15, 65621
addi x15, x15, 1056
dm_load_l1 0, 0, x15, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x16, 65559
addi x16, x16, 364
dm_store_of 0, 0, x16, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x11, 65621
addi x11, x11, 1280
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65621
addi x6, x6, 1728
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
lui x13, 65559
addi x13, x13, 1696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x30, x20, ss6
lui x17, 65621
addi x17, x17, 1952
dm_load_l1 0, 0, x17, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x5
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x7, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x30, x20, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
ccr_decl x8
ccr_clr 2
lui x24, 65622
addi x24, x24, 2400
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x21
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_stride x7, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x8, x10, x10, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
dm_load_act0 0, 0, x28, x22, pu, 1
ss_pack_shape x8, x8, x10, x12, ss2
ccr_decl x8
ccr_set 0, 1
lui x26, 65560
addi x26, x26, 3028
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x4, 12
addi x4, x4, 132
ss_pack_stride x8, x8, x4, ss1
ss_pack_stride x8, x8, x4, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x4, ss0
ccr_decl x8
ccr_clr 0
lw x19, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x19, x29
lui x27, 65536
addi x27, x27, 0
l2_store x29, x27, ss0
end x0
# case: test_reshape[3-16-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 4024
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 4040
addi x4, x0, 108
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 52
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 2
addi x7, x7, 59
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 2
addi x9, x9, 61
addi x10, x0, 1
mmu_conf x9, x10, 5
lui x11, 4
addi x11, x11, 896
ss_pack_stride x10, x10, x11, ss0
ss_pack_stride x10, x10, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x10, x10, x11, ss2
ccr_decl x10
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 28
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 262144
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 4
addi x21, x0, 60
addi x22, x0, 72
ss_pack_stride x20, x21, x22, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x21, x22, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x10, x10, 0, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_dest x11, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x25, x0, 3
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65568
addi x24, x24, 2944
mfu_act1_compute x24, x13, x0, x17
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 56
add x26, x28, x26
lui x27, 327680
addi x27, x27, 0
addi x29, x0, 15
l2_load_w x27, x26, x29
addi x30, x0, 112
l2_load_w_conf x30, x30, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x3, x0, 8
addi x31, x0, 72
add x31, x3, x31
lui x2, 196608
addi x2, x2, 0
l2_load_w x2, x31, x19
ss_pack_stride x20, x21, x22, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x4, x0, 14
ss_pack_shape x10, x20, x4, x22, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x5, x0, 576
l2_load_w_conf x5, x5, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x8, x0, 8
addi x6, x0, 296
add x6, x8, x6
lui x7, 131072
addi x7, x7, 0
l2_load_w x7, x6, x25
addi x9, x0, 216
dm_load_w_conf 0, 0, 3, 3, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x20, x1, ss7
addi x12, x0, 2
ccr_decl x12
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x7, x27, ss7, pu
addi x14, x0, 24
ss_pack_stride x14, x4, x22, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x20, x0
ss_pack_shape x10, x20, x4, x22, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x15, x0, 31
pu_fetchif_conf_deq 0, 0, x15, x0, u8
ccr_decl x10
ccr_clr 4
addi x16, x0, 224
dm_load_act0 0, 0, x2, x16, pu, 1
addi x18, x0, 58
addi x11, x0, 70
ss_pack_stride x1, x18, x11, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x23, x0, 12
ss_pack_shape x10, x1, x23, x11, ss2
dm_store_of 0, 0, x13, ss2, pu
ss_pack_shape x10, x1, x23, x11, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x1, x23, x11, ss5
pu_of_conf1 0, 0, x1, x0, ss5
ss_pack_shape x10, x1, x23, x11, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x17, 65568
addi x17, x17, 3808
dm_load_l1 0, 0, x17, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x16, pu, 1
ss_pack_shape x10, x1, x23, x11, ss2
lui x26, 65536
addi x26, x26, 1680
dm_store_of 0, 0, x26, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x28, 65568
addi x28, x28, 576
dm_load_l1 0, 0, x28, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x16, pu, 1
ss_pack_shape x10, x1, x23, x11, ss2
lui x29, 65537
addi x29, x29, 3360
dm_store_of 0, 0, x29, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss6
lui x30, 65568
addi x30, x30, 1440
dm_load_l1 0, 0, x30, x0, ss6, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
dm_load_act0 0, 0, x2, x16, pu, 1
ss_pack_shape x10, x1, x23, x11, ss2
lui x31, 65537
addi x31, x31, 944
dm_store_of 0, 0, x31, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x10, x20, x23, x22, ss3
ccr_decl x10
ccr_clr 2
lui x3, 65569
addi x3, x3, 2304
dm_load_l1 0, 0, x3, x0, ss3, if_
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_stride x14, x23, x22, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x20, x23, x22, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
dm_load_act0 0, 0, x2, x16, pu, 1
addi x19, x0, 10
ss_pack_shape x10, x1, x19, x11, ss4
ccr_decl x10
ccr_set 0, 1
lui x21, 65538
addi x21, x21, 2624
dm_store_of 0, 0, x21, ss4, pu
ss_pack_shape x10, x1, x19, x11, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x1, x19, x11, ss1
pu_of_conf1 0, 0, x1, x0, ss1
ss_pack_shape x10, x1, x19, x11, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x24, 16
addi x24, x24, 3520
ss_pack_stride x10, x10, x24, ss5
ss_pack_stride x10, x10, x24, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x10, x10, x10, x24, ss6
ccr_decl x10
ccr_clr 0
lw x6, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x6, x5
l2_store x5, x13, ss6
end x0
# case: test_reshape[3-16-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 24
addi x2, x2, 264
mmu_conf x1, x2, 1
lui x3, 24
addi x3, x3, 280
addi x4, x0, 108
mmu_conf x3, x4, 2
lui x5, 24
addi x5, x5, 388
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 24
addi x7, x7, 395
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 24
addi x9, x9, 397
addi x10, x0, 1
mmu_conf x9, x10, 5
addi x11, x0, 3
lui x12, 12
addi x12, x12, 1024
ss_pack_stride x11, x10, x12, ss0
ss_pack_stride x11, x10, x12, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x11, x10, x12, ss2
ccr_decl x10
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 65536
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 21
l2_load_w_conf x16, x16, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x19, x0, 8
lui x17, 0
addi x17, x17, 0
add x17, x19, x17
lui x18, 262144
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 224
ss_pack_stride x11, x21, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x11, x21, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x12, x10, x10, 0, l2
ss_pack_shape x10, x11, x21, x21, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x11, x21, x21, ss5
lui x22, 37
addi x22, x22, 3072
mfu_act1_conf_dest x22, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x11
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65921
addi x24, x24, 128
mfu_act1_compute x24, x14, x0, x18
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 42
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
addi x28, x0, 15
l2_load_w x26, x25, x28
addi x29, x0, 112
l2_load_w_conf x29, x29, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x2, x0, 8
addi x30, x0, 58
add x30, x2, x30
lui x31, 196608
addi x31, x31, 0
l2_load_w x31, x30, x20
ss_pack_stride x11, x21, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x3, x0, 4
ss_pack_shape x10, x11, x3, x21, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x4, x0, 288
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x7, x0, 8
addi x5, x0, 282
add x5, x7, x5
lui x6, 131072
addi x6, x6, 0
l2_load_w x6, x5, x8
addi x9, x0, 144
dm_load_w_conf 0, 0, 2, 3, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 2, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x11, x1, ss7
ccr_decl x8
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x6, x26, ss7, pu
addi x13, x0, 24
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x11, x0
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x15, x0, 31
pu_fetchif_conf_deq 0, 0, x15, x0, u8
addi x16, x0, 222
ss_pack_stride x1, x11, x16, ss1
pu_of_conf1 0, 0, x1, x0, ss1
ss_pack_shape x10, x1, x11, x16, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65921
addi x17, x17, 576
dm_load_l1 0, 0, x17, x0, ss5, if_
l2_load_w_conf x9, x9, i8, i8, 0
ccr_decl x10
ccr_set 6, 1
lw x22, x0, 8
addi x19, x0, 570
add x19, x22, x19
lui x12, 131073
addi x12, x12, 2304
l2_load_w x12, x19, x8
addi x23, x0, 72
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 6
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
ccr_decl x10
ccr_clr 4
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_stride x1, x16, x16, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x10, x1, x11, x16, ss2
dm_store_of 0, 0, x14, ss2, pu
ss_pack_shape x10, x1, x11, x16, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65921
addi x18, x18, 800
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65921
addi x25, x25, 1248
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65536
addi x27, x27, 1332
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65921
addi x28, x28, 1472
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65921
addi x29, x29, 1920
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65537
addi x30, x30, 2664
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65922
addi x2, x2, 2144
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65922
addi x20, x20, 2592
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65537
addi x24, x24, 3996
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65922
addi x4, x4, 2816
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65922
addi x5, x5, 3264
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65537
addi x7, x7, 1232
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65922
addi x15, x15, 3488
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65922
addi x17, x17, 3936
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65538
addi x19, x19, 2564
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65922
addi x22, x22, 64
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65922
addi x8, x8, 512
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65538
addi x14, x14, 3896
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65922
addi x18, x18, 736
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65922
addi x25, x25, 1184
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65538
addi x27, x27, 1132
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65922
addi x28, x28, 1408
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65922
addi x29, x29, 1856
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65539
addi x30, x30, 2464
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65923
addi x2, x2, 2080
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65923
addi x20, x20, 2528
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65539
addi x24, x24, 3796
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65923
addi x4, x4, 2752
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65923
addi x5, x5, 3200
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65539
addi x7, x7, 1032
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65923
addi x15, x15, 3424
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65923
addi x17, x17, 3872
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65540
addi x19, x19, 2364
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65923
addi x22, x22, 0
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65923
addi x8, x8, 448
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65540
addi x14, x14, 3696
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65923
addi x18, x18, 672
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65923
addi x25, x25, 1120
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65540
addi x27, x27, 932
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65923
addi x28, x28, 1344
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65923
addi x29, x29, 1792
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65541
addi x30, x30, 2264
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65923
addi x2, x2, 2016
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65924
addi x20, x20, 2464
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65541
addi x24, x24, 3596
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65924
addi x4, x4, 2688
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65924
addi x5, x5, 3136
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65541
addi x7, x7, 832
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65924
addi x15, x15, 3360
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65924
addi x17, x17, 3808
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65542
addi x19, x19, 2164
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65924
addi x22, x22, 4032
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65924
addi x8, x8, 384
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65542
addi x14, x14, 3496
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65924
addi x18, x18, 608
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65924
addi x25, x25, 1056
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65542
addi x27, x27, 732
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65924
addi x28, x28, 1280
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65924
addi x29, x29, 1728
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65543
addi x30, x30, 2064
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65924
addi x2, x2, 1952
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65925
addi x20, x20, 2400
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65543
addi x24, x24, 3396
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65925
addi x4, x4, 2624
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65925
addi x5, x5, 3072
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65543
addi x7, x7, 632
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65925
addi x15, x15, 3296
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65925
addi x17, x17, 3744
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65543
addi x19, x19, 1964
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65925
addi x22, x22, 3968
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65925
addi x8, x8, 320
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65544
addi x14, x14, 3296
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65925
addi x18, x18, 544
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65925
addi x25, x25, 992
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65544
addi x27, x27, 532
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65925
addi x28, x28, 1216
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65925
addi x29, x29, 1664
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65544
addi x30, x30, 1864
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65925
addi x2, x2, 1888
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65926
addi x20, x20, 2336
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65545
addi x24, x24, 3196
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65926
addi x4, x4, 2560
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65926
addi x5, x5, 3008
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65545
addi x7, x7, 432
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65926
addi x15, x15, 3232
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65926
addi x17, x17, 3680
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65545
addi x19, x19, 1764
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65926
addi x22, x22, 3904
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65926
addi x8, x8, 256
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65546
addi x14, x14, 3096
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65926
addi x18, x18, 480
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65926
addi x25, x25, 928
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65546
addi x27, x27, 332
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65926
addi x28, x28, 1152
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65926
addi x29, x29, 1600
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65546
addi x30, x30, 1664
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65926
addi x2, x2, 1824
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65927
addi x20, x20, 2272
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65547
addi x24, x24, 2996
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65927
addi x4, x4, 2496
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65927
addi x5, x5, 2944
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65547
addi x7, x7, 232
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65927
addi x15, x15, 3168
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65927
addi x17, x17, 3616
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65547
addi x19, x19, 1564
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65927
addi x22, x22, 3840
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65927
addi x8, x8, 192
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65548
addi x14, x14, 2896
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65927
addi x18, x18, 416
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65927
addi x25, x25, 864
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65548
addi x27, x27, 132
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65927
addi x28, x28, 1088
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65927
addi x29, x29, 1536
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65548
addi x30, x30, 1464
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65927
addi x2, x2, 1760
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65928
addi x20, x20, 2208
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65549
addi x24, x24, 2796
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65928
addi x4, x4, 2432
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65928
addi x5, x5, 2880
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65549
addi x7, x7, 32
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65928
addi x15, x15, 3104
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65928
addi x17, x17, 3552
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65549
addi x19, x19, 1364
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65928
addi x22, x22, 3776
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65928
addi x8, x8, 128
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65550
addi x14, x14, 2696
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65928
addi x18, x18, 352
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65928
addi x25, x25, 800
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65550
addi x27, x27, 4028
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65928
addi x28, x28, 1024
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65928
addi x29, x29, 1472
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65550
addi x30, x30, 1264
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65928
addi x2, x2, 1696
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65929
addi x20, x20, 2144
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65551
addi x24, x24, 2596
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65929
addi x4, x4, 2368
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65929
addi x5, x5, 2816
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65551
addi x7, x7, 3928
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65929
addi x15, x15, 3040
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65929
addi x17, x17, 3488
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65551
addi x19, x19, 1164
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65929
addi x22, x22, 3712
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65929
addi x8, x8, 64
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65552
addi x14, x14, 2496
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65929
addi x18, x18, 288
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65929
addi x25, x25, 736
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65552
addi x27, x27, 3828
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65929
addi x28, x28, 960
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65929
addi x29, x29, 1408
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65552
addi x30, x30, 1064
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65929
addi x2, x2, 1632
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65930
addi x20, x20, 2080
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65553
addi x24, x24, 2396
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65930
addi x4, x4, 2304
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65930
addi x5, x5, 2752
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65553
addi x7, x7, 3728
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65930
addi x15, x15, 2976
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65930
addi x17, x17, 3424
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65553
addi x19, x19, 964
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65930
addi x22, x22, 3648
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65930
addi x8, x8, 0
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65554
addi x14, x14, 2296
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65930
addi x18, x18, 224
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65930
addi x25, x25, 672
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65554
addi x27, x27, 3628
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65930
addi x28, x28, 896
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65930
addi x29, x29, 1344
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65554
addi x30, x30, 864
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65930
addi x2, x2, 1568
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65930
addi x20, x20, 2016
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65555
addi x24, x24, 2196
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65931
addi x4, x4, 2240
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65931
addi x5, x5, 2688
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65555
addi x7, x7, 3528
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65931
addi x15, x15, 2912
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65931
addi x17, x17, 3360
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65555
addi x19, x19, 764
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65931
addi x22, x22, 3584
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65931
addi x8, x8, 4032
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65556
addi x14, x14, 2096
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65931
addi x18, x18, 160
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65931
addi x25, x25, 608
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65556
addi x27, x27, 3428
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65931
addi x28, x28, 832
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65931
addi x29, x29, 1280
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65556
addi x30, x30, 664
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65931
addi x2, x2, 1504
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65931
addi x20, x20, 1952
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65556
addi x24, x24, 1996
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65932
addi x4, x4, 2176
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65932
addi x5, x5, 2624
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65557
addi x7, x7, 3328
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65932
addi x15, x15, 2848
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65932
addi x17, x17, 3296
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65557
addi x19, x19, 564
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65932
addi x22, x22, 3520
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65932
addi x8, x8, 3968
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65557
addi x14, x14, 1896
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65932
addi x18, x18, 96
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x25, 65932
addi x25, x25, 544
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x27, 65558
addi x27, x27, 3228
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x28, 65932
addi x28, x28, 768
dm_load_l1 0, 0, x28, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x29, 65932
addi x29, x29, 1216
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x30, 65558
addi x30, x30, 464
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x2, 65932
addi x2, x2, 1440
dm_load_l1 0, 0, x2, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65932
addi x20, x20, 1888
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x24, 65558
addi x24, x24, 1796
dm_store_of 0, 0, x24, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x4, 65933
addi x4, x4, 2112
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x5, 65933
addi x5, x5, 2560
dm_load_l1 0, 0, x5, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x7, 65559
addi x7, x7, 3128
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x15, 65933
addi x15, x15, 2784
dm_load_l1 0, 0, x15, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x17, 65933
addi x17, x17, 3232
dm_load_l1 0, 0, x17, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x19, 65559
addi x19, x19, 364
dm_store_of 0, 0, x19, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x22, 65933
addi x22, x22, 3456
dm_load_l1 0, 0, x22, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65933
addi x8, x8, 3904
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
lui x14, 65559
addi x14, x14, 1696
dm_store_of 0, 0, x14, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65933
addi x18, x18, 32
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x9
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x3, x21, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
ccr_decl x10
ccr_clr 2
lui x25, 65933
addi x25, x25, 480
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x23
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x12, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x10, x11, x11, x21, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
dm_load_act0 0, 0, x31, x21, pu, 1
ss_pack_shape x10, x1, x11, x16, ss2
ccr_decl x10
ccr_set 0, 1
lui x27, 65560
addi x27, x27, 3028
dm_store_of 0, 0, x27, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x28, 12
addi x28, x28, 132
ss_pack_stride x1, x10, x28, ss1
ss_pack_stride x1, x10, x28, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x10, x1, x10, x28, ss0
ccr_decl x10
ccr_clr 0
lw x2, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x2, x30
lui x29, 65536
addi x29, x29, 0
l2_store x30, x29, ss0
end x0
# case: test_reshape[3-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 21
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2197
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2199
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2201
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 4
addi x10, x10, 896
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 60
addi x21, x0, 72
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65544
addi x23, x23, 1792
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x31, x0, 14
ss_pack_shape x9, x19, x31, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x1, x0, 108
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x5, x0, 8
addi x2, x0, 101
add x2, x5, x2
lui x3, 131072
addi x3, x3, 0
l2_load_w x3, x2, x24
addi x7, x0, 216
dm_load_w_conf 0, 0, 3, 3, x7
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x3, x26, ss7, pu
addi x8, x0, 24
ss_pack_stride x8, x31, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x31, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x11, x0, 31
pu_fetchif_conf_deq 0, 0, x11, x0, u8
ccr_decl x9
ccr_clr 4
addi x13, x0, 42
dm_load_act0 0, 0, x29, x13, pu, 1
addi x14, x0, 58
addi x15, x0, 70
ss_pack_stride x24, x14, x15, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x17, x0, 12
ss_pack_shape x9, x24, x17, x15, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x24, x17, x15, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x17, x15, ss5
pu_of_conf1 0, 0, x24, x0, ss5
ss_pack_shape x9, x24, x17, x15, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x10, 65545
addi x10, x10, 2656
dm_load_l1 0, 0, x10, x0, ss6, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x13, pu, 1
ss_pack_shape x9, x24, x17, x15, ss2
lui x22, 65536
addi x22, x22, 1680
dm_store_of 0, 0, x22, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x16, 65545
addi x16, x16, 3520
dm_load_l1 0, 0, x16, x0, ss6, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x13, pu, 1
ss_pack_shape x9, x24, x17, x15, ss2
lui x25, 65537
addi x25, x25, 3360
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x31, x21, ss6
lui x27, 65545
addi x27, x27, 288
dm_load_l1 0, 0, x27, x0, ss6, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
dm_load_act0 0, 0, x29, x13, pu, 1
ss_pack_shape x9, x24, x17, x15, ss2
lui x4, 65537
addi x4, x4, 944
dm_store_of 0, 0, x4, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
ss_pack_shape x9, x19, x17, x21, ss3
ccr_decl x9
ccr_clr 2
lui x28, 65545
addi x28, x28, 1152
dm_load_l1 0, 0, x28, x0, ss3, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x3, x26, ss7, pu
ss_pack_stride x8, x17, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x17, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x13, pu, 1
addi x30, x0, 10
ss_pack_shape x9, x24, x30, x15, ss4
ccr_decl x9
ccr_set 0, 1
lui x18, 65538
addi x18, x18, 2624
dm_store_of 0, 0, x18, ss4, pu
ss_pack_shape x9, x24, x30, x15, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x30, x15, ss1
pu_of_conf1 0, 0, x24, x0, ss1
ss_pack_shape x9, x24, x30, x15, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x20, 3
addi x20, x20, 3988
ss_pack_stride x9, x9, x20, ss5
ss_pack_stride x9, x9, x20, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x20, ss6
ccr_decl x9
ccr_clr 0
lw x1, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x1, x23
l2_store x23, x12, ss6
end x0
# case: test_reshape[3-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 21
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2469
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2471
mmu_conf x7, x6, 4
lui x8, 5
addi x8, x8, 2473
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 3
lui x11, 12
addi x11, x11, 1024
ss_pack_stride x10, x9, x11, ss0
ss_pack_stride x10, x9, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x10, x9, x11, ss2
ccr_decl x9
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 224
ss_pack_stride x10, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x10, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x9, x9, 0, l2
ss_pack_shape x9, x10, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x10, x19, x19, ss5
lui x20, 37
addi x20, x20, 3072
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65610
addi x22, x22, 2048
mfu_act1_compute x22, x13, x0, x16
l2_load_w_conf x10, x10, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 45
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x10, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x29, x0, 4
ss_pack_shape x9, x10, x29, x19, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
addi x30, x0, 54
l2_load_w_conf x30, x30, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 87
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x6
addi x3, x0, 144
dm_load_w_conf 0, 0, 2, 3, x3
dm_load_w_conf2 0, 0, x9, x10
pu_w_conf 0, 0, 2, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x10, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x24, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x29, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
addi x8, x0, 222
ss_pack_stride x10, x10, x8, ss1
pu_of_conf1 0, 0, x10, x0, ss1
ss_pack_shape x9, x10, x10, x8, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x12, 65610
addi x12, x12, 2496
dm_load_l1 0, 0, x12, x0, ss5, if_
addi x14, x0, 27
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x9
ccr_set 6, 1
lw x11, x0, 8
addi x15, x0, 141
add x15, x11, x15
lui x17, 131072
addi x17, x17, 432
l2_load_w x17, x15, x6
addi x20, x0, 72
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 6
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ccr_decl x9
ccr_clr 4
addi x21, x0, 42
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_stride x10, x8, x8, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x9, x10, x10, x8, ss2
dm_store_of 0, 0, x13, ss2, pu
ss_pack_shape x9, x10, x10, x8, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65610
addi x16, x16, 2720
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65610
addi x23, x23, 3168
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65536
addi x25, x25, 1332
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65610
addi x4, x4, 3392
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65610
addi x26, x26, 3840
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65537
addi x28, x28, 2664
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65610
addi x18, x18, 4064
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65610
addi x22, x22, 416
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65537
addi x30, x30, 3996
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65610
addi x31, x31, 640
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65610
addi x2, x2, 1088
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65537
addi x7, x7, 1232
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65610
addi x12, x12, 1312
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65610
addi x14, x14, 1760
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65538
addi x15, x15, 2564
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65610
addi x11, x11, 1984
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65611
addi x6, x6, 2432
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65538
addi x13, x13, 3896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65611
addi x16, x16, 2656
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65611
addi x23, x23, 3104
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65538
addi x25, x25, 1132
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65611
addi x4, x4, 3328
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65611
addi x26, x26, 3776
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65539
addi x28, x28, 2464
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65611
addi x18, x18, 4000
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65611
addi x22, x22, 352
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65539
addi x30, x30, 3796
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65611
addi x31, x31, 576
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65611
addi x2, x2, 1024
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65539
addi x7, x7, 1032
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65611
addi x12, x12, 1248
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65611
addi x14, x14, 1696
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65540
addi x15, x15, 2364
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65611
addi x11, x11, 1920
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65612
addi x6, x6, 2368
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65540
addi x13, x13, 3696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65612
addi x16, x16, 2592
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65612
addi x23, x23, 3040
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65540
addi x25, x25, 932
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65612
addi x4, x4, 3264
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65612
addi x26, x26, 3712
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65541
addi x28, x28, 2264
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65612
addi x18, x18, 3936
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65612
addi x22, x22, 288
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65541
addi x30, x30, 3596
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65612
addi x31, x31, 512
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65612
addi x2, x2, 960
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65541
addi x7, x7, 832
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65612
addi x12, x12, 1184
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65612
addi x14, x14, 1632
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65542
addi x15, x15, 2164
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65612
addi x11, x11, 1856
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65613
addi x6, x6, 2304
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65542
addi x13, x13, 3496
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65613
addi x16, x16, 2528
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65613
addi x23, x23, 2976
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65542
addi x25, x25, 732
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65613
addi x4, x4, 3200
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65613
addi x26, x26, 3648
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65543
addi x28, x28, 2064
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65613
addi x18, x18, 3872
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65613
addi x22, x22, 224
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65543
addi x30, x30, 3396
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65613
addi x31, x31, 448
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65613
addi x2, x2, 896
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65543
addi x7, x7, 632
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65613
addi x12, x12, 1120
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65613
addi x14, x14, 1568
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65543
addi x15, x15, 1964
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65613
addi x11, x11, 1792
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65614
addi x6, x6, 2240
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65544
addi x13, x13, 3296
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65614
addi x16, x16, 2464
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65614
addi x23, x23, 2912
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65544
addi x25, x25, 532
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65614
addi x4, x4, 3136
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65614
addi x26, x26, 3584
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65544
addi x28, x28, 1864
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65614
addi x18, x18, 3808
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65614
addi x22, x22, 160
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65545
addi x30, x30, 3196
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65614
addi x31, x31, 384
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65614
addi x2, x2, 832
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65545
addi x7, x7, 432
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65614
addi x12, x12, 1056
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65614
addi x14, x14, 1504
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65545
addi x15, x15, 1764
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65614
addi x11, x11, 1728
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65615
addi x6, x6, 2176
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65546
addi x13, x13, 3096
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65615
addi x16, x16, 2400
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65615
addi x23, x23, 2848
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65546
addi x25, x25, 332
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65615
addi x4, x4, 3072
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65615
addi x26, x26, 3520
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65546
addi x28, x28, 1664
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65615
addi x18, x18, 3744
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65615
addi x22, x22, 96
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65547
addi x30, x30, 2996
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65615
addi x31, x31, 320
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65615
addi x2, x2, 768
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65547
addi x7, x7, 232
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65615
addi x12, x12, 992
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65615
addi x14, x14, 1440
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65547
addi x15, x15, 1564
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65615
addi x11, x11, 1664
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65616
addi x6, x6, 2112
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65548
addi x13, x13, 2896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65616
addi x16, x16, 2336
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65616
addi x23, x23, 2784
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65548
addi x25, x25, 132
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65616
addi x4, x4, 3008
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65616
addi x26, x26, 3456
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65548
addi x28, x28, 1464
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65616
addi x18, x18, 3680
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65616
addi x22, x22, 32
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65549
addi x30, x30, 2796
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65616
addi x31, x31, 256
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65616
addi x2, x2, 704
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65549
addi x7, x7, 32
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65616
addi x12, x12, 928
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65616
addi x14, x14, 1376
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65549
addi x15, x15, 1364
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65616
addi x11, x11, 1600
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65617
addi x6, x6, 2048
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65550
addi x13, x13, 2696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65617
addi x16, x16, 2272
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65617
addi x23, x23, 2720
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65550
addi x25, x25, 4028
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65617
addi x4, x4, 2944
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65617
addi x26, x26, 3392
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65550
addi x28, x28, 1264
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65617
addi x18, x18, 3616
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65617
addi x22, x22, 4064
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65551
addi x30, x30, 2596
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65617
addi x31, x31, 192
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65617
addi x2, x2, 640
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65551
addi x7, x7, 3928
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65617
addi x12, x12, 864
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65617
addi x14, x14, 1312
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65551
addi x15, x15, 1164
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65617
addi x11, x11, 1536
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65617
addi x6, x6, 1984
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65552
addi x13, x13, 2496
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65618
addi x16, x16, 2208
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65618
addi x23, x23, 2656
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65552
addi x25, x25, 3828
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65618
addi x4, x4, 2880
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65618
addi x26, x26, 3328
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65552
addi x28, x28, 1064
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65618
addi x18, x18, 3552
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65618
addi x22, x22, 4000
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65553
addi x30, x30, 2396
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65618
addi x31, x31, 128
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65618
addi x2, x2, 576
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65553
addi x7, x7, 3728
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65618
addi x12, x12, 800
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65618
addi x14, x14, 1248
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65553
addi x15, x15, 964
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65618
addi x11, x11, 1472
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65618
addi x6, x6, 1920
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65554
addi x13, x13, 2296
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65619
addi x16, x16, 2144
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65619
addi x23, x23, 2592
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65554
addi x25, x25, 3628
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65619
addi x4, x4, 2816
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65619
addi x26, x26, 3264
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65554
addi x28, x28, 864
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65619
addi x18, x18, 3488
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65619
addi x22, x22, 3936
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65555
addi x30, x30, 2196
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65619
addi x31, x31, 64
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65619
addi x2, x2, 512
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65555
addi x7, x7, 3528
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65619
addi x12, x12, 736
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65619
addi x14, x14, 1184
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65555
addi x15, x15, 764
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65619
addi x11, x11, 1408
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65619
addi x6, x6, 1856
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65556
addi x13, x13, 2096
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65620
addi x16, x16, 2080
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65620
addi x23, x23, 2528
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65556
addi x25, x25, 3428
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65620
addi x4, x4, 2752
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65620
addi x26, x26, 3200
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65556
addi x28, x28, 664
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65620
addi x18, x18, 3424
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65620
addi x22, x22, 3872
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65556
addi x30, x30, 1996
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65620
addi x31, x31, 0
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65620
addi x2, x2, 448
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65557
addi x7, x7, 3328
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65620
addi x12, x12, 672
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65620
addi x14, x14, 1120
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65557
addi x15, x15, 564
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65620
addi x11, x11, 1344
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65620
addi x6, x6, 1792
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65557
addi x13, x13, 1896
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65620
addi x16, x16, 2016
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x23, 65621
addi x23, x23, 2464
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x25, 65558
addi x25, x25, 3228
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x4, 65621
addi x4, x4, 2688
dm_load_l1 0, 0, x4, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x26, 65621
addi x26, x26, 3136
dm_load_l1 0, 0, x26, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x28, 65558
addi x28, x28, 464
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x18, 65621
addi x18, x18, 3360
dm_load_l1 0, 0, x18, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x22, 65621
addi x22, x22, 3808
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x30, 65558
addi x30, x30, 1796
dm_store_of 0, 0, x30, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x31, 65621
addi x31, x31, 4032
dm_load_l1 0, 0, x31, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x2, 65621
addi x2, x2, 384
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x7, 65559
addi x7, x7, 3128
dm_store_of 0, 0, x7, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x12, 65621
addi x12, x12, 608
dm_load_l1 0, 0, x12, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x14, 65621
addi x14, x14, 1056
dm_load_l1 0, 0, x14, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x15, 65559
addi x15, x15, 364
dm_store_of 0, 0, x15, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x11, 65621
addi x11, x11, 1280
dm_load_l1 0, 0, x11, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
lui x6, 65621
addi x6, x6, 1728
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
lui x13, 65559
addi x13, x13, 1696
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x29, x19, ss6
lui x16, 65621
addi x16, x16, 1952
dm_load_l1 0, 0, x16, x0, ss6, if_
dm_load_w_conf 0, 0, 2, 3, x3
pu_w_conf 0, 0, 2, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x1, x24, ss7, pu
ss_pack_stride x5, x29, x19, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x29, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x19, ss5
ccr_decl x9
ccr_clr 2
lui x23, 65622
addi x23, x23, 2400
dm_load_l1 0, 0, x23, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 3, x20
pu_w_conf 0, 0, 1, 3
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x24, ss7, pu
ss_pack_stride x5, x10, x19, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
dm_load_act0 0, 0, x27, x21, pu, 1
ss_pack_shape x9, x10, x10, x8, ss2
ccr_decl x9
ccr_set 0, 1
lui x25, 65560
addi x25, x25, 3028
dm_store_of 0, 0, x25, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x4, 12
addi x4, x4, 132
ss_pack_stride x10, x9, x4, ss1
ss_pack_stride x10, x9, x4, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x10, x9, x4, ss0
ccr_decl x9
ccr_clr 0
lw x18, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x18, x28
lui x26, 65536
addi x26, x26, 0
l2_store x28, x26, ss0
end x0
# case: test_reshape[5-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 19
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2195
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2197
addi x8, x0, 1
mmu_conf x7, x8, 4
lui x9, 1
addi x9, x9, 2198
mmu_conf x9, x8, 5
lui x10, 4
addi x10, x10, 896
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 60
addi x21, x0, 72
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65544
addi x23, x23, 1792
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
addi x28, x0, 7
l2_load_w_conf x28, x28, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x31, x0, 8
addi x29, x0, 57
add x29, x31, x29
lui x30, 262144
addi x30, x30, 0
l2_load_w x30, x29, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x1, x0, 14
ss_pack_shape x8, x19, x1, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x2, x0, 80
l2_load_w_conf x2, x2, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x5, x0, 8
addi x3, x0, 71
add x3, x5, x3
lui x4, 131072
addi x4, x4, 0
l2_load_w x4, x3, x24
addi x6, x0, 480
dm_load_w_conf 0, 0, 5, 4, x6
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 5, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
addi x7, x0, 2
ccr_decl x7
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x4, x26, ss7, pu
addi x9, x0, 24
ss_pack_stride x9, x1, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
addi x11, x0, 71
ss_pack_shape x8, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x13, x0, 31
pu_fetchif_conf_deq 0, 0, x13, x0, u8
addi x14, x0, 10
addi x15, x0, 68
ss_pack_stride x8, x14, x15, ss2
pu_of_conf1 0, 0, x8, x0, ss2
ss_pack_shape x8, x8, x14, x15, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x17, x0, 20
l2_load_w_conf x17, x17, i8, i8, 0
ccr_decl x8
ccr_set 6, 1
lw x12, x0, 8
addi x10, x0, 151
add x10, x12, x10
lui x22, 131072
addi x22, x22, 480
l2_load_w x22, x10, x24
addi x16, x0, 120
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
ccr_decl x8
ccr_clr 6
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
ccr_decl x8
ccr_clr 4
dm_load_act0 0, 0, x30, x1, pu, 1
addi x25, x0, 56
ss_pack_stride x8, x25, x15, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x8, x14, x15, ss5
lui x27, 65536
addi x27, x27, 0
dm_store_of 0, 0, x27, ss5, pu
ss_pack_shape x8, x8, x14, x15, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x1, x21, ss0
lui x28, 65545
addi x28, x28, 2512
dm_load_l1 0, 0, x28, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x6
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x8, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
dm_load_act0 0, 0, x30, x1, pu, 1
ss_pack_shape x8, x8, x14, x15, ss5
lui x29, 65536
addi x29, x29, 1360
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x1, x21, ss0
lui x31, 65545
addi x31, x31, 3232
dm_load_l1 0, 0, x31, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x6
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x8, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
dm_load_act0 0, 0, x30, x1, pu, 1
ss_pack_shape x8, x8, x14, x15, ss5
lui x18, 65537
addi x18, x18, 2720
dm_store_of 0, 0, x18, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x1, x21, ss0
lui x20, 65545
addi x20, x20, 3952
dm_load_l1 0, 0, x20, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x6
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x8, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
dm_load_act0 0, 0, x30, x1, pu, 1
ss_pack_shape x8, x8, x14, x15, ss5
lui x23, 65537
addi x23, x23, 4080
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x1, x21, ss0
lui x2, 65545
addi x2, x2, 576
dm_load_l1 0, 0, x2, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x6
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x8, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
dm_load_act0 0, 0, x30, x1, pu, 1
ss_pack_shape x8, x8, x14, x15, ss5
lui x3, 65537
addi x3, x3, 1344
dm_store_of 0, 0, x3, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x14, x21, ss4
ccr_decl x8
ccr_clr 2
lui x5, 65545
addi x5, x5, 1296
dm_load_l1 0, 0, x5, x0, ss4, if_
dm_load_w_conf 0, 0, 5, 4, x6
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_stride x9, x14, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x19, x14, x11, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
addi x7, x0, 6
ss_pack_stride x8, x7, x15, ss0
pu_of_conf1 0, 0, x8, x0, ss0
ss_pack_shape x8, x8, x7, x15, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x16
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x8, x19, x14, x15, ss3
pu_fetchif_conf3 0, 0, x19, x8, ss3
dm_load_act0 0, 0, x30, x1, pu, 1
ss_pack_shape x8, x8, x7, x15, ss1
ccr_decl x8
ccr_set 0, 1
lui x13, 65538
addi x13, x13, 2704
dm_store_of 0, 0, x13, ss1, pu
ss_pack_shape x8, x8, x7, x15, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x17, 1
addi x17, x17, 3808
ss_pack_stride x8, x8, x17, ss5
ss_pack_stride x8, x8, x17, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x17, ss4
ccr_decl x8
ccr_clr 0
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x27, ss4
end x0
# case: test_reshape[5-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 19
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2467
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2469
addi x8, x0, 1
mmu_conf x7, x8, 4
lui x9, 5
addi x9, x9, 2470
mmu_conf x9, x8, 5
addi x10, x0, 3
lui x11, 12
addi x11, x11, 1024
ss_pack_stride x10, x8, x11, ss0
ss_pack_stride x10, x8, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x10, x8, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 224
ss_pack_stride x10, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x10, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
ss_pack_shape x8, x10, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x10, x20, x20, ss5
lui x21, 37
addi x21, x21, 3072
mfu_act1_conf_dest x21, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65610
addi x23, x23, 2048
mfu_act1_compute x23, x13, x0, x17
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 43
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x19
ss_pack_stride x10, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x31, x0, 4
ss_pack_shape x8, x10, x31, x20, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x1, x0, 24
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x4, x0, 8
addi x2, x0, 57
add x2, x4, x2
lui x3, 131072
addi x3, x3, 0
l2_load_w x3, x2, x6
addi x5, x0, 192
dm_load_w_conf 0, 0, 2, 4, x5
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 2, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 223
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
addi x12, x0, 220
ss_pack_stride x8, x10, x12, ss2
pu_of_conf1 0, 0, x8, x0, ss2
ss_pack_shape x8, x8, x10, x12, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x14, x0, 6
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x8
ccr_set 6, 1
lw x18, x0, 8
addi x15, x0, 81
add x15, x18, x15
lui x16, 131072
addi x16, x16, 192
l2_load_w x16, x15, x6
addi x11, x0, 48
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 6
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss3
pu_fetchif_conf3 0, 0, x31, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss6
lui x21, 65610
addi x21, x21, 2496
dm_load_l1 0, 0, x21, x0, ss6, if_
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x17, x0, 8
addi x22, x0, 87
add x22, x17, x22
lui x13, 131072
addi x13, x13, 240
l2_load_w x13, x22, x6
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 5
dm_load_w 0, 0, x13, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x8
ccr_set 6, 1
lw x27, x0, 8
addi x24, x0, 111
add x24, x27, x24
lui x26, 131072
addi x26, x26, 432
l2_load_w x26, x24, x6
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 6
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss3
pu_fetchif_conf3 0, 0, x31, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss0
lui x28, 65610
addi x28, x28, 2944
dm_load_l1 0, 0, x28, x0, ss0, if_
addi x29, x0, 12
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x23, x0, 8
addi x30, x0, 117
add x30, x23, x30
lui x19, 131072
addi x19, x19, 480
l2_load_w x19, x30, x6
addi x2, x0, 96
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 5
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x8, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x10, x10, i8, i8, 0
ccr_decl x8
ccr_set 6, 1
lw x9, x0, 8
addi x4, x0, 129
add x4, x9, x4
lui x3, 131072
addi x3, x3, 576
l2_load_w x3, x4, x6
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
ccr_decl x8
ccr_clr 6
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x31, x8, ss5
ccr_decl x8
ccr_clr 4
lui x15, 262144
addi x15, x15, 0
addi x18, x0, 14
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_stride x8, x12, x12, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65536
addi x16, x16, 0
dm_store_of 0, 0, x16, ss1, pu
ss_pack_shape x8, x8, x10, x12, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65610
addi x21, x21, 2720
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
lui x22, 131072
addi x22, x22, 0
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
lui x17, 131072
addi x17, x17, 192
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65610
addi x13, x13, 3168
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
lui x14, 131072
addi x14, x14, 240
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65610
addi x24, x24, 3616
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65536
addi x27, x27, 1320
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65610
addi x28, x28, 3392
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65610
addi x29, x29, 3840
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65610
addi x30, x30, 192
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65537
addi x23, x23, 2640
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65610
addi x4, x4, 4064
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65610
addi x9, x9, 416
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65610
addi x6, x6, 864
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65537
addi x16, x16, 3960
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65610
addi x21, x21, 640
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65610
addi x13, x13, 1088
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65610
addi x24, x24, 1536
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65537
addi x27, x27, 1184
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65610
addi x28, x28, 1312
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65610
addi x29, x29, 1760
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65611
addi x30, x30, 2208
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65538
addi x23, x23, 2504
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65610
addi x4, x4, 1984
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65611
addi x9, x9, 2432
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65611
addi x6, x6, 2880
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65538
addi x16, x16, 3824
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65611
addi x21, x21, 2656
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65611
addi x13, x13, 3104
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65611
addi x24, x24, 3552
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65538
addi x27, x27, 1048
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65611
addi x28, x28, 3328
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65611
addi x29, x29, 3776
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65611
addi x30, x30, 128
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65539
addi x23, x23, 2368
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65611
addi x4, x4, 4000
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65611
addi x9, x9, 352
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65611
addi x6, x6, 800
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65539
addi x16, x16, 3688
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65611
addi x21, x21, 576
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65611
addi x13, x13, 1024
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65611
addi x24, x24, 1472
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65539
addi x27, x27, 912
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65611
addi x28, x28, 1248
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65611
addi x29, x29, 1696
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65612
addi x30, x30, 2144
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65540
addi x23, x23, 2232
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65611
addi x4, x4, 1920
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65612
addi x9, x9, 2368
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65612
addi x6, x6, 2816
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65540
addi x16, x16, 3552
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65612
addi x21, x21, 2592
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65612
addi x13, x13, 3040
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65612
addi x24, x24, 3488
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65540
addi x27, x27, 776
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65612
addi x28, x28, 3264
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65612
addi x29, x29, 3712
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65612
addi x30, x30, 64
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65541
addi x23, x23, 2096
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65612
addi x4, x4, 3936
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65612
addi x9, x9, 288
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65612
addi x6, x6, 736
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65541
addi x16, x16, 3416
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65612
addi x21, x21, 512
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65612
addi x13, x13, 960
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65612
addi x24, x24, 1408
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65541
addi x27, x27, 640
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65612
addi x28, x28, 1184
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65612
addi x29, x29, 1632
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65613
addi x30, x30, 2080
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65541
addi x23, x23, 1960
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65612
addi x4, x4, 1856
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65613
addi x9, x9, 2304
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65613
addi x6, x6, 2752
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65542
addi x16, x16, 3280
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65613
addi x21, x21, 2528
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65613
addi x13, x13, 2976
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65613
addi x24, x24, 3424
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65542
addi x27, x27, 504
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65613
addi x28, x28, 3200
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65613
addi x29, x29, 3648
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65613
addi x30, x30, 0
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65542
addi x23, x23, 1824
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65613
addi x4, x4, 3872
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65613
addi x9, x9, 224
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65613
addi x6, x6, 672
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65543
addi x16, x16, 3144
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65613
addi x21, x21, 448
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65613
addi x13, x13, 896
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65613
addi x24, x24, 1344
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65543
addi x27, x27, 368
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65613
addi x28, x28, 1120
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65613
addi x29, x29, 1568
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65613
addi x30, x30, 2016
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65543
addi x23, x23, 1688
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65613
addi x4, x4, 1792
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65614
addi x9, x9, 2240
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65614
addi x6, x6, 2688
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65544
addi x16, x16, 3008
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65614
addi x21, x21, 2464
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65614
addi x13, x13, 2912
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65614
addi x24, x24, 3360
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65544
addi x27, x27, 232
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65614
addi x28, x28, 3136
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65614
addi x29, x29, 3584
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65614
addi x30, x30, 4032
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65544
addi x23, x23, 1552
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65614
addi x4, x4, 3808
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65614
addi x9, x9, 160
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65614
addi x6, x6, 608
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65545
addi x16, x16, 2872
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65614
addi x21, x21, 384
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65614
addi x13, x13, 832
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65614
addi x24, x24, 1280
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65545
addi x27, x27, 96
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65614
addi x28, x28, 1056
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65614
addi x29, x29, 1504
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65614
addi x30, x30, 1952
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65545
addi x23, x23, 1416
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65614
addi x4, x4, 1728
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65615
addi x9, x9, 2176
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65615
addi x6, x6, 2624
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65546
addi x16, x16, 2736
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65615
addi x21, x21, 2400
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65615
addi x13, x13, 2848
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65615
addi x24, x24, 3296
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65546
addi x27, x27, 4056
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65615
addi x28, x28, 3072
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65615
addi x29, x29, 3520
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65615
addi x30, x30, 3968
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65546
addi x23, x23, 1280
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65615
addi x4, x4, 3744
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65615
addi x9, x9, 96
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65615
addi x6, x6, 544
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65547
addi x16, x16, 2600
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65615
addi x21, x21, 320
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65615
addi x13, x13, 768
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65615
addi x24, x24, 1216
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65547
addi x27, x27, 3920
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65615
addi x28, x28, 992
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65615
addi x29, x29, 1440
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65615
addi x30, x30, 1888
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65547
addi x23, x23, 1144
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65615
addi x4, x4, 1664
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65616
addi x9, x9, 2112
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65616
addi x6, x6, 2560
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65548
addi x16, x16, 2464
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65616
addi x21, x21, 2336
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65616
addi x13, x13, 2784
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65616
addi x24, x24, 3232
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65548
addi x27, x27, 3784
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65616
addi x28, x28, 3008
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65616
addi x29, x29, 3456
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65616
addi x30, x30, 3904
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65548
addi x23, x23, 1008
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65616
addi x4, x4, 3680
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65616
addi x9, x9, 32
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65616
addi x6, x6, 480
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65549
addi x16, x16, 2328
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65616
addi x21, x21, 256
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65616
addi x13, x13, 704
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65616
addi x24, x24, 1152
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65549
addi x27, x27, 3648
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65616
addi x28, x28, 928
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65616
addi x29, x29, 1376
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65616
addi x30, x30, 1824
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65549
addi x23, x23, 872
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65616
addi x4, x4, 1600
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65617
addi x9, x9, 2048
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65617
addi x6, x6, 2496
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65550
addi x16, x16, 2192
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65617
addi x21, x21, 2272
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65617
addi x13, x13, 2720
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65617
addi x24, x24, 3168
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65550
addi x27, x27, 3512
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65617
addi x28, x28, 2944
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65617
addi x29, x29, 3392
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65617
addi x30, x30, 3840
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65550
addi x23, x23, 736
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65617
addi x4, x4, 3616
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65617
addi x9, x9, 4064
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65617
addi x6, x6, 416
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65551
addi x16, x16, 2056
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65617
addi x21, x21, 192
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65617
addi x13, x13, 640
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65617
addi x24, x24, 1088
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65551
addi x27, x27, 3376
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65617
addi x28, x28, 864
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65617
addi x29, x29, 1312
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65617
addi x30, x30, 1760
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65551
addi x23, x23, 600
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65617
addi x4, x4, 1536
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65617
addi x9, x9, 1984
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65618
addi x6, x6, 2432
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65551
addi x16, x16, 1920
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65618
addi x21, x21, 2208
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65618
addi x13, x13, 2656
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65618
addi x24, x24, 3104
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65552
addi x27, x27, 3240
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65618
addi x28, x28, 2880
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65618
addi x29, x29, 3328
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65618
addi x30, x30, 3776
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65552
addi x23, x23, 464
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65618
addi x4, x4, 3552
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65618
addi x9, x9, 4000
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65618
addi x6, x6, 352
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65552
addi x16, x16, 1784
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65618
addi x21, x21, 128
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65618
addi x13, x13, 576
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65618
addi x24, x24, 1024
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65553
addi x27, x27, 3104
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65618
addi x28, x28, 800
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65618
addi x29, x29, 1248
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65618
addi x30, x30, 1696
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65553
addi x23, x23, 328
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65618
addi x4, x4, 1472
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65618
addi x9, x9, 1920
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65619
addi x6, x6, 2368
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65553
addi x16, x16, 1648
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65619
addi x21, x21, 2144
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65619
addi x13, x13, 2592
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65619
addi x24, x24, 3040
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65554
addi x27, x27, 2968
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65619
addi x28, x28, 2816
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65619
addi x29, x29, 3264
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65619
addi x30, x30, 3712
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65554
addi x23, x23, 192
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65619
addi x4, x4, 3488
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65619
addi x9, x9, 3936
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65619
addi x6, x6, 288
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65554
addi x16, x16, 1512
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65619
addi x21, x21, 64
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65619
addi x13, x13, 512
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65619
addi x24, x24, 960
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65555
addi x27, x27, 2832
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65619
addi x28, x28, 736
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65619
addi x29, x29, 1184
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65619
addi x30, x30, 1632
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65555
addi x23, x23, 56
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65619
addi x4, x4, 1408
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65619
addi x9, x9, 1856
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65620
addi x6, x6, 2304
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65555
addi x16, x16, 1376
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x21, 65620
addi x21, x21, 2080
dm_load_l1 0, 0, x21, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x13, 65620
addi x13, x13, 2528
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x24, 65620
addi x24, x24, 2976
dm_load_l1 0, 0, x24, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x27, 65556
addi x27, x27, 2696
dm_store_of 0, 0, x27, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x28, 65620
addi x28, x28, 2752
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x29, 65620
addi x29, x29, 3200
dm_load_l1 0, 0, x29, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x30, 65620
addi x30, x30, 3648
dm_load_l1 0, 0, x30, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x23, 65556
addi x23, x23, 4016
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x4, 65620
addi x4, x4, 3424
dm_load_l1 0, 0, x4, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x9, 65620
addi x9, x9, 3872
dm_load_l1 0, 0, x9, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x6, 65620
addi x6, x6, 224
dm_load_l1 0, 0, x6, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x16, 65556
addi x16, x16, 1240
dm_store_of 0, 0, x16, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x21, 65620
addi x21, x21, 0
dm_load_l1 0, 0, x21, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x13, 65620
addi x13, x13, 448
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x24, 65620
addi x24, x24, 896
dm_load_l1 0, 0, x24, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x27, 65557
addi x27, x27, 2560
dm_store_of 0, 0, x27, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x28, 65620
addi x28, x28, 672
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x29, 65620
addi x29, x29, 1120
dm_load_l1 0, 0, x29, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x30, 65620
addi x30, x30, 1568
dm_load_l1 0, 0, x30, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x23, 65557
addi x23, x23, 3880
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x4, 65620
addi x4, x4, 1344
dm_load_l1 0, 0, x4, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x9, 65620
addi x9, x9, 1792
dm_load_l1 0, 0, x9, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x6, 65621
addi x6, x6, 2240
dm_load_l1 0, 0, x6, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x16, 65557
addi x16, x16, 1104
dm_store_of 0, 0, x16, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x21, 65620
addi x21, x21, 2016
dm_load_l1 0, 0, x21, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x13, 65621
addi x13, x13, 2464
dm_load_l1 0, 0, x13, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x24, 65621
addi x24, x24, 2912
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x27, 65558
addi x27, x27, 2424
dm_store_of 0, 0, x27, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x28, 65621
addi x28, x28, 2688
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x29, 65621
addi x29, x29, 3136
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x30, 65621
addi x30, x30, 3584
dm_load_l1 0, 0, x30, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x23, 65558
addi x23, x23, 3744
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x4, 65621
addi x4, x4, 3360
dm_load_l1 0, 0, x4, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss3
lui x9, 65621
addi x9, x9, 3808
dm_load_l1 0, 0, x9, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss5
lui x6, 65621
addi x6, x6, 160
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss3
lui x16, 65558
addi x16, x16, 968
dm_store_of 0, 0, x16, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x21, 65621
addi x21, x21, 4032
dm_load_l1 0, 0, x21, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss4
lui x13, 65621
addi x13, x13, 384
dm_load_l1 0, 0, x13, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss1
lui x24, 65621
addi x24, x24, 832
dm_load_l1 0, 0, x24, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss4
lui x27, 65559
addi x27, x27, 2288
dm_store_of 0, 0, x27, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x28, 65621
addi x28, x28, 608
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss5
lui x29, 65621
addi x29, x29, 1056
dm_load_l1 0, 0, x29, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss1
pu_fetchif_conf3 0, 0, x0, x8, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss3
lui x30, 65621
addi x30, x30, 1504
dm_load_l1 0, 0, x30, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x31, x8, ss2
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss5
lui x23, 65559
addi x23, x23, 3608
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x4, 65621
addi x4, x4, 1280
dm_load_l1 0, 0, x4, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x31, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x31, x20, ss1
lui x9, 65621
addi x9, x9, 1728
dm_load_l1 0, 0, x9, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x31, x7, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x31, x12, ss0
pu_fetchif_conf3 0, 0, x31, x8, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x10, x20, ss4
lui x6, 65622
addi x6, x6, 2176
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x8, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x10, x12, ss1
lui x16, 65559
addi x16, x16, 832
dm_store_of 0, 0, x16, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x21, x0, 2
ss_pack_shape x8, x10, x21, x20, ss3
lui x13, 65621
addi x13, x13, 1952
dm_load_l1 0, 0, x13, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x22, x25, ss7, pu
ss_pack_stride x1, x21, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x21, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
ss_pack_stride x8, x8, x12, ss2
pu_of_conf1 0, 0, x8, x0, ss2
ss_pack_shape x8, x8, x8, x12, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x8, x10, x21, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x21, x20, ss3
lui x24, 65622
addi x24, x24, 2400
dm_load_l1 0, 0, x24, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x5
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x14, x25, ss7, pu
ss_pack_shape x8, x10, x21, x7, ss4
pu_fetchif_conf3 0, 0, x0, x8, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x11
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x8, x10, x21, x12, ss6
pu_fetchif_conf3 0, 0, x31, x8, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x10, x8, x20, ss1
ccr_decl x8
ccr_clr 2
lui x27, 65622
addi x27, x27, 2848
dm_load_l1 0, 0, x27, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x2
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x19, x25, ss7, pu
ss_pack_stride x1, x8, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x10, x8, x7, ss2
pu_fetchif_conf3 0, 0, x0, x8, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x1
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x8, ss7
dm_load_w 0, 0, x3, x25, ss7, pu
ss_pack_shape x8, x10, x8, x12, ss5
pu_fetchif_conf3 0, 0, x31, x8, ss5
dm_load_act0 0, 0, x15, x18, pu, 1
ss_pack_shape x8, x8, x8, x12, ss3
ccr_decl x8
ccr_set 0, 1
lui x28, 65560
addi x28, x28, 2152
dm_store_of 0, 0, x28, ss3, pu
ss_pack_shape x8, x8, x8, x12, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x29, 12
addi x29, x29, 3344
ss_pack_stride x8, x8, x29, ss4
ss_pack_stride x8, x8, x29, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_clr 0
lw x4, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x4, x23
lui x30, 65536
addi x30, x30, 0
l2_store x23, x30, ss6
end x0
# case: test_reshape[5-16-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 3520
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 3536
addi x4, x0, 300
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 3836
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 2
addi x7, x7, 3843
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 2
addi x9, x9, 3845
addi x10, x0, 1
mmu_conf x9, x10, 5
lui x11, 4
addi x11, x11, 896
ss_pack_stride x10, x10, x11, ss0
ss_pack_stride x10, x10, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x10, x10, x11, ss2
ccr_decl x10
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 28
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 262144
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 4
addi x21, x0, 60
addi x22, x0, 72
ss_pack_stride x20, x21, x22, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x21, x22, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x10, x10, 0, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x20, x21, x22, ss5
mfu_act1_conf_dest x11, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x25, x0, 3
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65566
addi x24, x24, 3072
mfu_act1_compute x24, x13, x0, x17
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 56
add x26, x28, x26
lui x27, 327680
addi x27, x27, 0
addi x29, x0, 15
l2_load_w x27, x26, x29
addi x30, x0, 112
l2_load_w_conf x30, x30, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x3, x0, 8
addi x31, x0, 72
add x31, x3, x31
lui x2, 196608
addi x2, x2, 0
l2_load_w x2, x31, x19
ss_pack_stride x20, x21, x22, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x4, x0, 14
ss_pack_shape x10, x20, x4, x22, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x5, x0, 1280
l2_load_w_conf x5, x5, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x8, x0, 8
addi x6, x0, 296
add x6, x8, x6
lui x7, 131072
addi x7, x7, 0
l2_load_w x7, x6, x25
addi x9, x0, 480
dm_load_w_conf 0, 0, 5, 4, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 5, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x20, x1, ss7
addi x12, x0, 2
ccr_decl x12
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x7, x27, ss7, pu
addi x14, x0, 24
ss_pack_stride x14, x4, x22, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x20, x0
addi x15, x0, 71
ss_pack_shape x10, x20, x4, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x16, x0, 31
pu_fetchif_conf_deq 0, 0, x16, x0, u8
addi x18, x0, 10
addi x11, x0, 68
ss_pack_stride x1, x18, x11, ss2
pu_of_conf1 0, 0, x1, x0, ss2
ss_pack_shape x10, x1, x18, x11, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x23, x0, 320
l2_load_w_conf x23, x23, i8, i8, 0
ccr_decl x10
ccr_set 6, 1
lw x26, x0, 8
addi x13, x0, 1576
add x13, x26, x13
lui x17, 131074
addi x17, x17, 3584
l2_load_w x17, x13, x25
addi x28, x0, 120
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
ccr_decl x10
ccr_clr 6
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x4, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
ccr_decl x10
ccr_clr 4
addi x29, x0, 224
dm_load_act0 0, 0, x2, x29, pu, 1
addi x30, x0, 56
ss_pack_stride x1, x30, x11, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x10, x1, x18, x11, ss5
lui x31, 65536
addi x31, x31, 0
dm_store_of 0, 0, x31, ss5, pu
ss_pack_shape x10, x1, x18, x11, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss0
lui x3, 65566
addi x3, x3, 3792
dm_load_l1 0, 0, x3, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x9
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_shape x10, x20, x4, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x4, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
dm_load_act0 0, 0, x2, x29, pu, 1
ss_pack_shape x10, x1, x18, x11, ss5
lui x19, 65536
addi x19, x19, 1360
dm_store_of 0, 0, x19, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss0
lui x21, 65566
addi x21, x21, 416
dm_load_l1 0, 0, x21, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x9
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_shape x10, x20, x4, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x4, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
dm_load_act0 0, 0, x2, x29, pu, 1
ss_pack_shape x10, x1, x18, x11, ss5
lui x24, 65537
addi x24, x24, 2720
dm_store_of 0, 0, x24, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss0
lui x5, 65566
addi x5, x5, 1136
dm_load_l1 0, 0, x5, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x9
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_shape x10, x20, x4, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x4, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
dm_load_act0 0, 0, x2, x29, pu, 1
ss_pack_shape x10, x1, x18, x11, ss5
lui x6, 65537
addi x6, x6, 4080
dm_store_of 0, 0, x6, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x4, x22, ss0
lui x8, 65566
addi x8, x8, 1856
dm_load_l1 0, 0, x8, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x9
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
ss_pack_shape x10, x20, x4, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x4, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
dm_load_act0 0, 0, x2, x29, pu, 1
ss_pack_shape x10, x1, x18, x11, ss5
lui x12, 65537
addi x12, x12, 1344
dm_store_of 0, 0, x12, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x20, x18, x22, ss4
ccr_decl x10
ccr_clr 2
lui x14, 65567
addi x14, x14, 2576
dm_load_l1 0, 0, x14, x0, ss4, if_
dm_load_w_conf 0, 0, 5, 4, x9
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x7, x27, ss7, pu
addi x16, x0, 24
ss_pack_stride x16, x18, x22, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x20, x18, x15, ss6
pu_fetchif_conf3 0, 0, x0, x10, ss6
addi x23, x0, 6
ss_pack_stride x1, x23, x11, ss0
pu_of_conf1 0, 0, x1, x0, ss0
ss_pack_shape x10, x1, x23, x11, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x28
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x20, x1, ss7
dm_load_w 0, 0, x17, x27, ss7, pu
ss_pack_shape x10, x20, x18, x11, ss3
pu_fetchif_conf3 0, 0, x20, x10, ss3
dm_load_act0 0, 0, x2, x29, pu, 1
ss_pack_shape x10, x1, x23, x11, ss1
ccr_decl x10
ccr_set 0, 1
lui x13, 65538
addi x13, x13, 2704
dm_store_of 0, 0, x13, ss1, pu
ss_pack_shape x10, x1, x23, x11, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x26, 15
addi x26, x26, 3584
ss_pack_stride x10, x10, x26, ss5
ss_pack_stride x10, x10, x26, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x10, x10, x10, x26, ss4
ccr_decl x10
ccr_clr 0
lw x30, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x30, x25
l2_store x25, x31, ss4
end x0
# case: test_reshape[5-16-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 24
addi x2, x2, 2592
mmu_conf x1, x2, 1
lui x3, 24
addi x3, x3, 2608
addi x4, x0, 300
mmu_conf x3, x4, 2
lui x5, 24
addi x5, x5, 2908
addi x6, x0, 7
mmu_conf x5, x6, 3
lui x7, 24
addi x7, x7, 2915
addi x8, x0, 2
mmu_conf x7, x8, 4
lui x9, 24
addi x9, x9, 2917
addi x10, x0, 1
mmu_conf x9, x10, 5
addi x11, x0, 3
lui x12, 12
addi x12, x12, 1024
ss_pack_stride x11, x10, x12, ss0
ss_pack_stride x11, x10, x12, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x10, x11, x10, x12, ss2
ccr_decl x10
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 65536
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 21
l2_load_w_conf x16, x16, fp16, fp16, 0
ccr_decl x10
ccr_set 1, 1
lw x19, x0, 8
lui x17, 0
addi x17, x17, 0
add x17, x19, x17
lui x18, 262144
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
addi x21, x0, 224
ss_pack_stride x11, x21, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x11, x21, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x12, x10, x10, 0, l2
ss_pack_shape x10, x11, x21, x21, ss5
mfu_act1_conf_src2 x10, ss5, 0, l2
mfu_act1_conf_src1 x10, x10, x10, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x10, ss4, 1, l2
ss_pack_shape x10, x11, x21, x21, ss5
lui x22, 37
addi x22, x22, 3072
mfu_act1_conf_dest x22, ss5
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x11
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x24, 65914
addi x24, x24, 512
mfu_act1_compute x24, x14, x0, x18
l2_load_w_conf x1, x1, i8, i8, 0
ccr_decl x10
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 42
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
addi x28, x0, 15
l2_load_w x26, x25, x28
addi x29, x0, 112
l2_load_w_conf x29, x29, fp16, fp16, 0
ccr_decl x10
ccr_set 4, 1
lw x2, x0, 8
addi x30, x0, 58
add x30, x2, x30
lui x31, 196608
addi x31, x31, 0
l2_load_w x31, x30, x20
ss_pack_stride x11, x21, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x3, x0, 4
ss_pack_shape x10, x11, x3, x21, ss6
ccr_decl x10
ccr_clr 2
dm_load_l1 0, 0, x24, x0, ss6, if_
addi x4, x0, 384
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x7, x0, 8
addi x5, x0, 282
add x5, x7, x5
lui x6, 131072
addi x6, x6, 0
l2_load_w x6, x5, x8
addi x9, x0, 192
dm_load_w_conf 0, 0, 2, 4, x9
dm_load_w_conf2 0, 0, x10, x1
pu_w_conf 0, 0, 2, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x11, x1, ss7
ccr_decl x8
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x6, x26, ss7, pu
addi x13, x0, 24
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x11, x0
addi x15, x0, 223
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x16, x0, 31
pu_fetchif_conf_deq 0, 0, x16, x0, u8
addi x17, x0, 220
ss_pack_stride x1, x11, x17, ss2
pu_of_conf1 0, 0, x1, x0, ss2
ss_pack_shape x10, x1, x11, x17, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x19, x0, 96
l2_load_w_conf x19, x19, i8, i8, 0
ccr_decl x10
ccr_set 6, 1
lw x23, x0, 8
addi x12, x0, 666
add x12, x23, x12
lui x22, 131073
addi x22, x22, 3072
l2_load_w x22, x12, x8
addi x14, x0, 48
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 6
dm_load_w 0, 0, x22, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss3
pu_fetchif_conf3 0, 0, x3, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss6
lui x18, 65914
addi x18, x18, 960
dm_load_l1 0, 0, x18, x0, ss6, if_
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x28, x0, 8
addi x25, x0, 762
add x25, x28, x25
lui x27, 131073
addi x27, x27, 3840
l2_load_w x27, x25, x8
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 5
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x19, x19, i8, i8, 0
ccr_decl x10
ccr_set 6, 1
lw x31, x0, 8
addi x29, x0, 1146
add x29, x31, x29
lui x30, 131074
addi x30, x30, 2816
l2_load_w x30, x29, x8
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 6
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss3
pu_fetchif_conf3 0, 0, x3, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss0
lui x2, 65914
addi x2, x2, 1408
dm_load_l1 0, 0, x2, x0, ss0, if_
l2_load_w_conf x9, x9, i8, i8, 0
ccr_decl x10
ccr_set 5, 1
lw x5, x0, 8
addi x20, x0, 1242
add x20, x5, x20
lui x24, 131074
addi x24, x24, 3584
l2_load_w x24, x20, x8
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 5
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x10, x11, x11, x15, ss2
pu_fetchif_conf3 0, 0, x0, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x10
ccr_set 6, 1
lw x16, x0, 8
addi x7, x0, 1434
add x7, x16, x7
lui x6, 131074
addi x6, x6, 1024
l2_load_w x6, x7, x8
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
ccr_decl x10
ccr_clr 6
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss5
pu_fetchif_conf3 0, 0, x3, x10, ss5
ccr_decl x10
ccr_clr 4
lui x12, 196608
addi x12, x12, 0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_stride x1, x17, x17, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65536
addi x23, x23, 0
dm_store_of 0, 0, x23, ss1, pu
ss_pack_shape x10, x1, x11, x17, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65914
addi x22, x22, 1184
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
lui x18, 131072
addi x18, x18, 0
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
lui x4, 131073
addi x4, x4, 3072
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65914
addi x25, x25, 1632
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65915
addi x28, x28, 2080
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65536
addi x29, x29, 1320
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65914
addi x31, x31, 1856
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65915
addi x2, x2, 2304
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65915
addi x20, x20, 2752
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65537
addi x5, x5, 2640
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65915
addi x7, x7, 2528
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65915
addi x16, x16, 2976
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65915
addi x8, x8, 3424
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65537
addi x23, x23, 3960
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65915
addi x22, x22, 3200
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65915
addi x25, x25, 3648
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65915
addi x28, x28, 0
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65537
addi x29, x29, 1184
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65915
addi x31, x31, 3872
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65915
addi x2, x2, 224
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65915
addi x20, x20, 672
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65538
addi x5, x5, 2504
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65915
addi x7, x7, 448
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65915
addi x16, x16, 896
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65915
addi x8, x8, 1344
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65538
addi x23, x23, 3824
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65915
addi x22, x22, 1120
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65915
addi x25, x25, 1568
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65915
addi x28, x28, 2016
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65538
addi x29, x29, 1048
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65915
addi x31, x31, 1792
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65916
addi x2, x2, 2240
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65916
addi x20, x20, 2688
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65539
addi x5, x5, 2368
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65916
addi x7, x7, 2464
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65916
addi x16, x16, 2912
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65916
addi x8, x8, 3360
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65539
addi x23, x23, 3688
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65916
addi x22, x22, 3136
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65916
addi x25, x25, 3584
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65916
addi x28, x28, 4032
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65539
addi x29, x29, 912
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65916
addi x31, x31, 3808
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65916
addi x2, x2, 160
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65916
addi x20, x20, 608
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65540
addi x5, x5, 2232
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65916
addi x7, x7, 384
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65916
addi x16, x16, 832
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65916
addi x8, x8, 1280
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65540
addi x23, x23, 3552
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65916
addi x22, x22, 1056
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65916
addi x25, x25, 1504
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65916
addi x28, x28, 1952
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65540
addi x29, x29, 776
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65916
addi x31, x31, 1728
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65917
addi x2, x2, 2176
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65917
addi x20, x20, 2624
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65541
addi x5, x5, 2096
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65917
addi x7, x7, 2400
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65917
addi x16, x16, 2848
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65917
addi x8, x8, 3296
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65541
addi x23, x23, 3416
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65917
addi x22, x22, 3072
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65917
addi x25, x25, 3520
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65917
addi x28, x28, 3968
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65541
addi x29, x29, 640
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65917
addi x31, x31, 3744
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65917
addi x2, x2, 96
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65917
addi x20, x20, 544
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65541
addi x5, x5, 1960
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65917
addi x7, x7, 320
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65917
addi x16, x16, 768
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65917
addi x8, x8, 1216
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65542
addi x23, x23, 3280
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65917
addi x22, x22, 992
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65917
addi x25, x25, 1440
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65917
addi x28, x28, 1888
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65542
addi x29, x29, 504
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65917
addi x31, x31, 1664
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65918
addi x2, x2, 2112
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65918
addi x20, x20, 2560
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65542
addi x5, x5, 1824
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65918
addi x7, x7, 2336
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65918
addi x16, x16, 2784
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65918
addi x8, x8, 3232
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65543
addi x23, x23, 3144
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65918
addi x22, x22, 3008
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65918
addi x25, x25, 3456
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65918
addi x28, x28, 3904
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65543
addi x29, x29, 368
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65918
addi x31, x31, 3680
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65918
addi x2, x2, 32
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65918
addi x20, x20, 480
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65543
addi x5, x5, 1688
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65918
addi x7, x7, 256
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65918
addi x16, x16, 704
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65918
addi x8, x8, 1152
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65544
addi x23, x23, 3008
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65918
addi x22, x22, 928
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65918
addi x25, x25, 1376
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65918
addi x28, x28, 1824
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65544
addi x29, x29, 232
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65918
addi x31, x31, 1600
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65919
addi x2, x2, 2048
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65919
addi x20, x20, 2496
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65544
addi x5, x5, 1552
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65919
addi x7, x7, 2272
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65919
addi x16, x16, 2720
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65919
addi x8, x8, 3168
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65545
addi x23, x23, 2872
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65919
addi x22, x22, 2944
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65919
addi x25, x25, 3392
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65919
addi x28, x28, 3840
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65545
addi x29, x29, 96
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65919
addi x31, x31, 3616
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65919
addi x2, x2, 4064
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65919
addi x20, x20, 416
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65545
addi x5, x5, 1416
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65919
addi x7, x7, 192
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65919
addi x16, x16, 640
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65919
addi x8, x8, 1088
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65546
addi x23, x23, 2736
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65919
addi x22, x22, 864
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65919
addi x25, x25, 1312
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65919
addi x28, x28, 1760
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65546
addi x29, x29, 4056
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65919
addi x31, x31, 1536
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65919
addi x2, x2, 1984
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65920
addi x20, x20, 2432
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65546
addi x5, x5, 1280
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65920
addi x7, x7, 2208
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65920
addi x16, x16, 2656
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65920
addi x8, x8, 3104
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65547
addi x23, x23, 2600
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65920
addi x22, x22, 2880
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65920
addi x25, x25, 3328
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65920
addi x28, x28, 3776
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65547
addi x29, x29, 3920
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65920
addi x31, x31, 3552
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65920
addi x2, x2, 4000
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65920
addi x20, x20, 352
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65547
addi x5, x5, 1144
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65920
addi x7, x7, 128
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65920
addi x16, x16, 576
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65920
addi x8, x8, 1024
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65548
addi x23, x23, 2464
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65920
addi x22, x22, 800
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65920
addi x25, x25, 1248
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65920
addi x28, x28, 1696
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65548
addi x29, x29, 3784
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65920
addi x31, x31, 1472
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65920
addi x2, x2, 1920
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65921
addi x20, x20, 2368
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65548
addi x5, x5, 1008
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65921
addi x7, x7, 2144
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65921
addi x16, x16, 2592
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65921
addi x8, x8, 3040
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65549
addi x23, x23, 2328
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65921
addi x22, x22, 2816
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65921
addi x25, x25, 3264
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65921
addi x28, x28, 3712
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65549
addi x29, x29, 3648
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65921
addi x31, x31, 3488
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65921
addi x2, x2, 3936
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65921
addi x20, x20, 288
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65549
addi x5, x5, 872
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65921
addi x7, x7, 64
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65921
addi x16, x16, 512
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65921
addi x8, x8, 960
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65550
addi x23, x23, 2192
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65921
addi x22, x22, 736
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65921
addi x25, x25, 1184
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65921
addi x28, x28, 1632
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65550
addi x29, x29, 3512
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65921
addi x31, x31, 1408
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65921
addi x2, x2, 1856
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65922
addi x20, x20, 2304
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65550
addi x5, x5, 736
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65922
addi x7, x7, 2080
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65922
addi x16, x16, 2528
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65922
addi x8, x8, 2976
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65551
addi x23, x23, 2056
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65922
addi x22, x22, 2752
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65922
addi x25, x25, 3200
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65922
addi x28, x28, 3648
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65551
addi x29, x29, 3376
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65922
addi x31, x31, 3424
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65922
addi x2, x2, 3872
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65922
addi x20, x20, 224
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65551
addi x5, x5, 600
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65922
addi x7, x7, 0
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65922
addi x16, x16, 448
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65922
addi x8, x8, 896
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65551
addi x23, x23, 1920
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65922
addi x22, x22, 672
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65922
addi x25, x25, 1120
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65922
addi x28, x28, 1568
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65552
addi x29, x29, 3240
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65922
addi x31, x31, 1344
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65922
addi x2, x2, 1792
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65923
addi x20, x20, 2240
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65552
addi x5, x5, 464
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65922
addi x7, x7, 2016
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65923
addi x16, x16, 2464
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65923
addi x8, x8, 2912
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65552
addi x23, x23, 1784
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65923
addi x22, x22, 2688
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65923
addi x25, x25, 3136
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65923
addi x28, x28, 3584
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65553
addi x29, x29, 3104
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65923
addi x31, x31, 3360
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65923
addi x2, x2, 3808
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65923
addi x20, x20, 160
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65553
addi x5, x5, 328
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65923
addi x7, x7, 4032
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65923
addi x16, x16, 384
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65923
addi x8, x8, 832
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65553
addi x23, x23, 1648
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65923
addi x22, x22, 608
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65923
addi x25, x25, 1056
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65923
addi x28, x28, 1504
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65554
addi x29, x29, 2968
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65923
addi x31, x31, 1280
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65923
addi x2, x2, 1728
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65924
addi x20, x20, 2176
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65554
addi x5, x5, 192
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65923
addi x7, x7, 1952
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65924
addi x16, x16, 2400
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65924
addi x8, x8, 2848
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65554
addi x23, x23, 1512
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65924
addi x22, x22, 2624
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65924
addi x25, x25, 3072
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65924
addi x28, x28, 3520
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65555
addi x29, x29, 2832
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65924
addi x31, x31, 3296
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65924
addi x2, x2, 3744
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65924
addi x20, x20, 96
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65555
addi x5, x5, 56
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65924
addi x7, x7, 3968
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65924
addi x16, x16, 320
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65924
addi x8, x8, 768
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65555
addi x23, x23, 1376
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x22, 65924
addi x22, x22, 544
dm_load_l1 0, 0, x22, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x25, 65924
addi x25, x25, 992
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x28, 65924
addi x28, x28, 1440
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x29, 65556
addi x29, x29, 2696
dm_store_of 0, 0, x29, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x31, 65924
addi x31, x31, 1216
dm_load_l1 0, 0, x31, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x2, 65924
addi x2, x2, 1664
dm_load_l1 0, 0, x2, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x20, 65925
addi x20, x20, 2112
dm_load_l1 0, 0, x20, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x5, 65556
addi x5, x5, 4016
dm_store_of 0, 0, x5, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x7, 65924
addi x7, x7, 1888
dm_load_l1 0, 0, x7, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x16, 65925
addi x16, x16, 2336
dm_load_l1 0, 0, x16, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x8, 65925
addi x8, x8, 2784
dm_load_l1 0, 0, x8, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x23, 65556
addi x23, x23, 1240
dm_store_of 0, 0, x23, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x22, 65925
addi x22, x22, 2560
dm_load_l1 0, 0, x22, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x25, 65925
addi x25, x25, 3008
dm_load_l1 0, 0, x25, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x28, 65925
addi x28, x28, 3456
dm_load_l1 0, 0, x28, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x29, 65557
addi x29, x29, 2560
dm_store_of 0, 0, x29, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x31, 65925
addi x31, x31, 3232
dm_load_l1 0, 0, x31, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x2, 65925
addi x2, x2, 3680
dm_load_l1 0, 0, x2, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x20, 65925
addi x20, x20, 32
dm_load_l1 0, 0, x20, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x5, 65557
addi x5, x5, 3880
dm_store_of 0, 0, x5, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x7, 65925
addi x7, x7, 3904
dm_load_l1 0, 0, x7, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x16, 65925
addi x16, x16, 256
dm_load_l1 0, 0, x16, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x8, 65925
addi x8, x8, 704
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x23, 65557
addi x23, x23, 1104
dm_store_of 0, 0, x23, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x22, 65925
addi x22, x22, 480
dm_load_l1 0, 0, x22, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x25, 65925
addi x25, x25, 928
dm_load_l1 0, 0, x25, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x28, 65925
addi x28, x28, 1376
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x29, 65558
addi x29, x29, 2424
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x31, 65925
addi x31, x31, 1152
dm_load_l1 0, 0, x31, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x2, 65925
addi x2, x2, 1600
dm_load_l1 0, 0, x2, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x20, 65926
addi x20, x20, 2048
dm_load_l1 0, 0, x20, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x5, 65558
addi x5, x5, 3744
dm_store_of 0, 0, x5, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x7, 65925
addi x7, x7, 1824
dm_load_l1 0, 0, x7, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss3
lui x16, 65926
addi x16, x16, 2272
dm_load_l1 0, 0, x16, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss5
lui x8, 65926
addi x8, x8, 2720
dm_load_l1 0, 0, x8, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss3
lui x23, 65558
addi x23, x23, 968
dm_store_of 0, 0, x23, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x22, 65926
addi x22, x22, 2496
dm_load_l1 0, 0, x22, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss4
lui x25, 65926
addi x25, x25, 2944
dm_load_l1 0, 0, x25, x0, ss4, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss1
lui x28, 65926
addi x28, x28, 3392
dm_load_l1 0, 0, x28, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x11, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss4
lui x29, 65559
addi x29, x29, 2288
dm_store_of 0, 0, x29, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x31, 65926
addi x31, x31, 3168
dm_load_l1 0, 0, x31, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss5
lui x2, 65926
addi x2, x2, 3616
dm_load_l1 0, 0, x2, x0, ss5, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss1
pu_fetchif_conf3 0, 0, x0, x10, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss3
lui x20, 65926
addi x20, x20, 4064
dm_load_l1 0, 0, x20, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x11, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss2
pu_fetchif_conf3 0, 0, x3, x10, ss2
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss5
lui x5, 65559
addi x5, x5, 3608
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x7, 65926
addi x7, x7, 3840
dm_load_l1 0, 0, x7, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x3, x21, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x3, x21, ss1
lui x16, 65926
addi x16, x16, 192
dm_load_l1 0, 0, x16, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x3, x15, ss3
pu_fetchif_conf3 0, 0, x0, x10, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x3, x17, ss0
pu_fetchif_conf3 0, 0, x3, x10, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x11, x21, ss4
lui x8, 65926
addi x8, x8, 640
dm_load_l1 0, 0, x8, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x11, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x10, x11, x11, x15, ss5
pu_fetchif_conf3 0, 0, x0, x10, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x11, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x11, x17, ss1
lui x23, 65559
addi x23, x23, 832
dm_store_of 0, 0, x23, ss1, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x22, x0, 2
ss_pack_shape x10, x11, x22, x21, ss3
lui x25, 65926
addi x25, x25, 416
dm_load_l1 0, 0, x25, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x18, x26, ss7, pu
ss_pack_stride x13, x22, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x22, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
ss_pack_stride x1, x10, x17, ss2
pu_of_conf1 0, 0, x1, x0, ss2
ss_pack_shape x10, x1, x10, x17, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x10, x11, x22, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x22, x21, ss3
lui x28, 65926
addi x28, x28, 864
dm_load_l1 0, 0, x28, x0, ss3, if_
dm_load_w_conf 0, 0, 2, 4, x9
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x27, x26, ss7, pu
ss_pack_shape x10, x11, x22, x15, ss4
pu_fetchif_conf3 0, 0, x0, x10, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x14
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x30, x26, ss7, pu
ss_pack_shape x10, x11, x22, x17, ss6
pu_fetchif_conf3 0, 0, x3, x10, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x10, x11, x10, x21, ss1
ccr_decl x10
ccr_clr 2
lui x29, 65926
addi x29, x29, 1312
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 1, 4, x19
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x24, x26, ss7, pu
ss_pack_stride x13, x10, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x10, x11, x10, x15, ss2
pu_fetchif_conf3 0, 0, x0, x10, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x13
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x11, x1, ss7
dm_load_w 0, 0, x6, x26, ss7, pu
ss_pack_shape x10, x11, x10, x17, ss5
pu_fetchif_conf3 0, 0, x3, x10, ss5
dm_load_act0 0, 0, x12, x21, pu, 1
ss_pack_shape x10, x1, x10, x17, ss3
ccr_decl x10
ccr_set 0, 1
lui x31, 65560
addi x31, x31, 2152
dm_store_of 0, 0, x31, ss3, pu
ss_pack_shape x10, x1, x10, x17, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x2, 12
addi x2, x2, 3344
ss_pack_stride x1, x10, x2, ss4
ss_pack_stride x1, x10, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x10, x1, x10, x2, ss6
ccr_decl x10
ccr_clr 0
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x20, 65536
addi x20, x20, 0
l2_store x5, x20, ss6
end x0
# case: test_reshape[5-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2160
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2176
addi x4, x0, 57
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 2233
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 2235
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2237
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 4
addi x10, x10, 896
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 60
addi x21, x0, 72
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65544
addi x23, x23, 1792
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
addi x28, x0, 21
l2_load_w_conf x28, x28, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x31, x0, 8
addi x29, x0, 59
add x29, x31, x29
lui x30, 196608
addi x30, x30, 0
l2_load_w x30, x29, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x1, x0, 14
ss_pack_shape x9, x19, x1, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x2, x0, 240
l2_load_w_conf x2, x2, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x5, x0, 8
addi x3, x0, 101
add x3, x5, x3
lui x4, 131072
addi x4, x4, 0
l2_load_w x4, x3, x24
addi x7, x0, 480
dm_load_w_conf 0, 0, 5, 4, x7
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 5, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x4, x26, ss7, pu
addi x8, x0, 24
ss_pack_stride x8, x1, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
addi x11, x0, 71
ss_pack_shape x9, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x13, x0, 31
pu_fetchif_conf_deq 0, 0, x13, x0, u8
addi x14, x0, 10
addi x15, x0, 68
ss_pack_stride x24, x14, x15, ss2
pu_of_conf1 0, 0, x24, x0, ss2
ss_pack_shape x9, x24, x14, x15, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x20, x20, i8, i8, 0
ccr_decl x9
ccr_set 6, 1
lw x22, x0, 8
addi x17, x0, 341
add x17, x22, x17
lui x10, 131072
addi x10, x10, 1440
l2_load_w x10, x17, x24
addi x12, x0, 120
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
ccr_decl x9
ccr_clr 6
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
ccr_decl x9
ccr_clr 4
addi x16, x0, 42
dm_load_act0 0, 0, x30, x16, pu, 1
addi x25, x0, 56
ss_pack_stride x24, x25, x15, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x9, x24, x14, x15, ss5
lui x27, 65536
addi x27, x27, 0
dm_store_of 0, 0, x27, ss5, pu
ss_pack_shape x9, x24, x14, x15, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x1, x21, ss0
lui x28, 65545
addi x28, x28, 2512
dm_load_l1 0, 0, x28, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x7
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x9, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
dm_load_act0 0, 0, x30, x16, pu, 1
ss_pack_shape x9, x24, x14, x15, ss5
lui x29, 65536
addi x29, x29, 1360
dm_store_of 0, 0, x29, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x1, x21, ss0
lui x31, 65545
addi x31, x31, 3232
dm_load_l1 0, 0, x31, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x7
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x9, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
dm_load_act0 0, 0, x30, x16, pu, 1
ss_pack_shape x9, x24, x14, x15, ss5
lui x18, 65537
addi x18, x18, 2720
dm_store_of 0, 0, x18, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x1, x21, ss0
lui x23, 65545
addi x23, x23, 3952
dm_load_l1 0, 0, x23, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x7
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x9, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
dm_load_act0 0, 0, x30, x16, pu, 1
ss_pack_shape x9, x24, x14, x15, ss5
lui x2, 65537
addi x2, x2, 4080
dm_store_of 0, 0, x2, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x1, x21, ss0
lui x3, 65545
addi x3, x3, 576
dm_load_l1 0, 0, x3, x0, ss0, if_
dm_load_w_conf 0, 0, 5, 4, x7
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_shape x9, x19, x1, x11, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x1, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
dm_load_act0 0, 0, x30, x16, pu, 1
ss_pack_shape x9, x24, x14, x15, ss5
lui x5, 65537
addi x5, x5, 1344
dm_store_of 0, 0, x5, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x14, x21, ss4
ccr_decl x9
ccr_clr 2
lui x6, 65545
addi x6, x6, 1296
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 5, 4, x7
pu_w_conf 0, 0, 5, 4
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x4, x26, ss7, pu
ss_pack_stride x8, x14, x21, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x19, x14, x11, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
addi x13, x0, 6
ss_pack_stride x24, x13, x15, ss0
pu_of_conf1 0, 0, x24, x0, ss0
ss_pack_shape x9, x24, x13, x15, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 5, 1, x12
pu_w_conf 0, 0, 5, 1
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x10, x26, ss7, pu
ss_pack_shape x9, x19, x14, x15, ss3
pu_fetchif_conf3 0, 0, x19, x9, ss3
dm_load_act0 0, 0, x30, x16, pu, 1
ss_pack_shape x9, x24, x13, x15, ss1
ccr_decl x9
ccr_set 0, 1
lui x20, 65538
addi x20, x20, 2704
dm_store_of 0, 0, x20, ss1, pu
ss_pack_shape x9, x24, x13, x15, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x17, 3
addi x17, x17, 3232
ss_pack_stride x9, x9, x17, ss5
ss_pack_stride x9, x9, x17, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x17, ss4
ccr_decl x9
ccr_clr 0
lw x25, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x25, x22
l2_store x22, x27, ss4
end x0
# case: test_reshape[5-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 57
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2505
addi x6, x0, 2
mmu_conf x5, x6, 3
lui x7, 5
addi x7, x7, 2507
mmu_conf x7, x6, 4
lui x8, 5
addi x8, x8, 2509
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 3
lui x11, 12
addi x11, x11, 1024
ss_pack_stride x10, x9, x11, ss0
ss_pack_stride x10, x9, x11, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x10, x9, x11, ss2
ccr_decl x9
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x18, x0, 8
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 262144
addi x17, x17, 0
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 224
ss_pack_stride x10, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x10, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x9, x9, 0, l2
ss_pack_shape x9, x10, x20, x20, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x10, x20, x20, ss5
lui x21, 37
addi x21, x21, 3072
mfu_act1_conf_dest x21, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65610
addi x23, x23, 2048
mfu_act1_compute x23, x13, x0, x17
l2_load_w_conf x10, x10, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x29, x0, 8
addi x27, x0, 45
add x27, x29, x27
lui x28, 196608
addi x28, x28, 0
l2_load_w x28, x27, x19
ss_pack_stride x10, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
addi x30, x0, 4
ss_pack_shape x9, x10, x30, x20, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 72
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 87
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x6
addi x4, x0, 192
dm_load_w_conf 0, 0, 2, 4, x4
dm_load_w_conf2 0, 0, x9, x10
pu_w_conf 0, 0, 2, 4
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x10, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x10, x0
addi x7, x0, 223
ss_pack_shape x9, x10, x30, x7, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
addi x12, x0, 220
ss_pack_stride x10, x10, x12, ss2
pu_of_conf1 0, 0, x10, x0, ss2
ss_pack_shape x9, x10, x10, x12, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x14, x0, 18
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x9
ccr_set 6, 1
lw x11, x0, 8
addi x16, x0, 159
add x16, x11, x16
lui x18, 131072
addi x18, x18, 576
l2_load_w x18, x16, x6
addi x21, x0, 48
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 6
dm_load_w 0, 0, x18, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss6
lui x22, 65610
addi x22, x22, 2496
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x24, x0, 8
addi x13, x0, 177
add x13, x24, x13
lui x17, 131072
addi x17, x17, 720
l2_load_w x17, x13, x6
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 5
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss1
pu_fetchif_conf3 0, 0, x0, x9, ss1
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
l2_load_w_conf x14, x14, i8, i8, 0
ccr_decl x9
ccr_set 6, 1
lw x27, x0, 8
addi x26, x0, 249
add x26, x27, x26
lui x15, 131072
addi x15, x15, 1296
l2_load_w x15, x26, x6
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 6
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x28, 65610
addi x28, x28, 2944
dm_load_l1 0, 0, x28, x0, ss0, if_
addi x29, x0, 36
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x1, x0, 8
addi x19, x0, 267
add x19, x1, x19
lui x23, 131072
addi x23, x23, 1440
l2_load_w x23, x19, x6
addi x3, x0, 96
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 5
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
addi x2, x0, 9
l2_load_w_conf x2, x2, i8, i8, 0
ccr_decl x9
ccr_set 6, 1
lw x11, x0, 8
addi x8, x0, 303
add x8, x11, x8
lui x16, 131072
addi x16, x16, 1728
l2_load_w x16, x8, x6
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
ccr_decl x9
ccr_clr 6
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
ccr_decl x9
ccr_clr 4
lui x18, 196608
addi x18, x18, 0
addi x22, x0, 42
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_stride x10, x12, x12, ss6
dm_store_of_conf 0, 0, ss6, fp16
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65536
addi x31, x31, 0
dm_store_of 0, 0, x31, ss5, pu
ss_pack_shape x9, x10, x10, x12, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65610
addi x13, x13, 2720
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
lui x24, 131072
addi x24, x24, 0
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
lui x17, 131072
addi x17, x17, 576
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65610
addi x14, x14, 3168
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
lui x26, 131072
addi x26, x26, 720
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65610
addi x27, x27, 3616
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65536
addi x28, x28, 1320
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65610
addi x29, x29, 3392
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65610
addi x19, x19, 3840
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65610
addi x1, x1, 192
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65537
addi x2, x2, 2640
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65610
addi x8, x8, 4064
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65610
addi x11, x11, 416
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65610
addi x6, x6, 864
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65537
addi x31, x31, 3960
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65610
addi x13, x13, 640
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65610
addi x14, x14, 1088
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65610
addi x27, x27, 1536
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65537
addi x28, x28, 1184
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65610
addi x29, x29, 1312
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65610
addi x19, x19, 1760
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65611
addi x1, x1, 2208
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65538
addi x2, x2, 2504
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65610
addi x8, x8, 1984
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65611
addi x11, x11, 2432
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65611
addi x6, x6, 2880
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65538
addi x31, x31, 3824
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65611
addi x13, x13, 2656
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65611
addi x14, x14, 3104
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65611
addi x27, x27, 3552
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65538
addi x28, x28, 1048
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65611
addi x29, x29, 3328
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65611
addi x19, x19, 3776
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65611
addi x1, x1, 128
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65539
addi x2, x2, 2368
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65611
addi x8, x8, 4000
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65611
addi x11, x11, 352
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65611
addi x6, x6, 800
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65539
addi x31, x31, 3688
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65611
addi x13, x13, 576
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65611
addi x14, x14, 1024
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65611
addi x27, x27, 1472
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65539
addi x28, x28, 912
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65611
addi x29, x29, 1248
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65611
addi x19, x19, 1696
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65612
addi x1, x1, 2144
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65540
addi x2, x2, 2232
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65611
addi x8, x8, 1920
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65612
addi x11, x11, 2368
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65612
addi x6, x6, 2816
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65540
addi x31, x31, 3552
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65612
addi x13, x13, 2592
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65612
addi x14, x14, 3040
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65612
addi x27, x27, 3488
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65540
addi x28, x28, 776
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65612
addi x29, x29, 3264
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65612
addi x19, x19, 3712
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65612
addi x1, x1, 64
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65541
addi x2, x2, 2096
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65612
addi x8, x8, 3936
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65612
addi x11, x11, 288
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65612
addi x6, x6, 736
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65541
addi x31, x31, 3416
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65612
addi x13, x13, 512
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65612
addi x14, x14, 960
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65612
addi x27, x27, 1408
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65541
addi x28, x28, 640
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65612
addi x29, x29, 1184
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65612
addi x19, x19, 1632
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65613
addi x1, x1, 2080
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65541
addi x2, x2, 1960
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65612
addi x8, x8, 1856
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65613
addi x11, x11, 2304
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65613
addi x6, x6, 2752
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65542
addi x31, x31, 3280
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65613
addi x13, x13, 2528
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65613
addi x14, x14, 2976
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65613
addi x27, x27, 3424
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65542
addi x28, x28, 504
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65613
addi x29, x29, 3200
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65613
addi x19, x19, 3648
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65613
addi x1, x1, 0
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65542
addi x2, x2, 1824
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65613
addi x8, x8, 3872
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65613
addi x11, x11, 224
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65613
addi x6, x6, 672
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65543
addi x31, x31, 3144
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65613
addi x13, x13, 448
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65613
addi x14, x14, 896
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65613
addi x27, x27, 1344
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65543
addi x28, x28, 368
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65613
addi x29, x29, 1120
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65613
addi x19, x19, 1568
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65613
addi x1, x1, 2016
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65543
addi x2, x2, 1688
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65613
addi x8, x8, 1792
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65614
addi x11, x11, 2240
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65614
addi x6, x6, 2688
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65544
addi x31, x31, 3008
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65614
addi x13, x13, 2464
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65614
addi x14, x14, 2912
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65614
addi x27, x27, 3360
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65544
addi x28, x28, 232
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65614
addi x29, x29, 3136
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65614
addi x19, x19, 3584
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65614
addi x1, x1, 4032
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65544
addi x2, x2, 1552
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65614
addi x8, x8, 3808
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65614
addi x11, x11, 160
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65614
addi x6, x6, 608
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65545
addi x31, x31, 2872
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65614
addi x13, x13, 384
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65614
addi x14, x14, 832
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65614
addi x27, x27, 1280
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65545
addi x28, x28, 96
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65614
addi x29, x29, 1056
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65614
addi x19, x19, 1504
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65614
addi x1, x1, 1952
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65545
addi x2, x2, 1416
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65614
addi x8, x8, 1728
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65615
addi x11, x11, 2176
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65615
addi x6, x6, 2624
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65546
addi x31, x31, 2736
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65615
addi x13, x13, 2400
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65615
addi x14, x14, 2848
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65615
addi x27, x27, 3296
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65546
addi x28, x28, 4056
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65615
addi x29, x29, 3072
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65615
addi x19, x19, 3520
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65615
addi x1, x1, 3968
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65546
addi x2, x2, 1280
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65615
addi x8, x8, 3744
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65615
addi x11, x11, 96
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65615
addi x6, x6, 544
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65547
addi x31, x31, 2600
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65615
addi x13, x13, 320
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65615
addi x14, x14, 768
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65615
addi x27, x27, 1216
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65547
addi x28, x28, 3920
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65615
addi x29, x29, 992
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65615
addi x19, x19, 1440
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65615
addi x1, x1, 1888
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65547
addi x2, x2, 1144
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65615
addi x8, x8, 1664
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65616
addi x11, x11, 2112
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65616
addi x6, x6, 2560
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65548
addi x31, x31, 2464
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65616
addi x13, x13, 2336
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65616
addi x14, x14, 2784
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65616
addi x27, x27, 3232
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65548
addi x28, x28, 3784
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65616
addi x29, x29, 3008
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65616
addi x19, x19, 3456
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65616
addi x1, x1, 3904
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65548
addi x2, x2, 1008
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65616
addi x8, x8, 3680
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65616
addi x11, x11, 32
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65616
addi x6, x6, 480
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65549
addi x31, x31, 2328
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65616
addi x13, x13, 256
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65616
addi x14, x14, 704
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65616
addi x27, x27, 1152
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65549
addi x28, x28, 3648
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65616
addi x29, x29, 928
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65616
addi x19, x19, 1376
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65616
addi x1, x1, 1824
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65549
addi x2, x2, 872
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65616
addi x8, x8, 1600
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65617
addi x11, x11, 2048
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65617
addi x6, x6, 2496
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65550
addi x31, x31, 2192
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65617
addi x13, x13, 2272
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65617
addi x14, x14, 2720
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65617
addi x27, x27, 3168
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65550
addi x28, x28, 3512
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65617
addi x29, x29, 2944
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65617
addi x19, x19, 3392
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65617
addi x1, x1, 3840
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65550
addi x2, x2, 736
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65617
addi x8, x8, 3616
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65617
addi x11, x11, 4064
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65617
addi x6, x6, 416
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65551
addi x31, x31, 2056
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65617
addi x13, x13, 192
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65617
addi x14, x14, 640
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65617
addi x27, x27, 1088
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65551
addi x28, x28, 3376
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65617
addi x29, x29, 864
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65617
addi x19, x19, 1312
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65617
addi x1, x1, 1760
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65551
addi x2, x2, 600
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65617
addi x8, x8, 1536
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65617
addi x11, x11, 1984
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65618
addi x6, x6, 2432
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65551
addi x31, x31, 1920
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65618
addi x13, x13, 2208
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65618
addi x14, x14, 2656
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65618
addi x27, x27, 3104
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65552
addi x28, x28, 3240
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65618
addi x29, x29, 2880
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65618
addi x19, x19, 3328
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65618
addi x1, x1, 3776
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65552
addi x2, x2, 464
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65618
addi x8, x8, 3552
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65618
addi x11, x11, 4000
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65618
addi x6, x6, 352
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65552
addi x31, x31, 1784
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65618
addi x13, x13, 128
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65618
addi x14, x14, 576
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65618
addi x27, x27, 1024
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65553
addi x28, x28, 3104
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65618
addi x29, x29, 800
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65618
addi x19, x19, 1248
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65618
addi x1, x1, 1696
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65553
addi x2, x2, 328
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65618
addi x8, x8, 1472
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65618
addi x11, x11, 1920
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65619
addi x6, x6, 2368
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65553
addi x31, x31, 1648
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65619
addi x13, x13, 2144
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65619
addi x14, x14, 2592
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65619
addi x27, x27, 3040
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65554
addi x28, x28, 2968
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65619
addi x29, x29, 2816
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65619
addi x19, x19, 3264
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65619
addi x1, x1, 3712
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65554
addi x2, x2, 192
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65619
addi x8, x8, 3488
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65619
addi x11, x11, 3936
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65619
addi x6, x6, 288
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65554
addi x31, x31, 1512
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65619
addi x13, x13, 64
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65619
addi x14, x14, 512
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65619
addi x27, x27, 960
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65555
addi x28, x28, 2832
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65619
addi x29, x29, 736
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65619
addi x19, x19, 1184
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65619
addi x1, x1, 1632
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65555
addi x2, x2, 56
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65619
addi x8, x8, 1408
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65619
addi x11, x11, 1856
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65620
addi x6, x6, 2304
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65555
addi x31, x31, 1376
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65620
addi x13, x13, 2080
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65620
addi x14, x14, 2528
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65620
addi x27, x27, 2976
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65556
addi x28, x28, 2696
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65620
addi x29, x29, 2752
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65620
addi x19, x19, 3200
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65620
addi x1, x1, 3648
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65556
addi x2, x2, 4016
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65620
addi x8, x8, 3424
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65620
addi x11, x11, 3872
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65620
addi x6, x6, 224
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65556
addi x31, x31, 1240
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65620
addi x13, x13, 0
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65620
addi x14, x14, 448
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65620
addi x27, x27, 896
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65557
addi x28, x28, 2560
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65620
addi x29, x29, 672
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65620
addi x19, x19, 1120
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65620
addi x1, x1, 1568
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65557
addi x2, x2, 3880
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65620
addi x8, x8, 1344
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65620
addi x11, x11, 1792
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65621
addi x6, x6, 2240
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65557
addi x31, x31, 1104
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65620
addi x13, x13, 2016
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65621
addi x14, x14, 2464
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss2
lui x27, 65621
addi x27, x27, 2912
dm_load_l1 0, 0, x27, x0, ss2, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x10, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss3
lui x28, 65558
addi x28, x28, 2424
dm_store_of 0, 0, x28, ss3, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65621
addi x29, x29, 2688
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65621
addi x19, x19, 3136
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss6
lui x1, 65621
addi x1, x1, 3584
dm_load_l1 0, 0, x1, x0, ss6, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x10, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss0
lui x2, 65558
addi x2, x2, 3744
dm_store_of 0, 0, x2, ss0, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65621
addi x8, x8, 3360
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65621
addi x11, x11, 3808
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss5
lui x6, 65621
addi x6, x6, 160
dm_load_l1 0, 0, x6, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x10, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss4
pu_fetchif_conf3 0, 0, x30, x9, ss4
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss4
lui x31, 65558
addi x31, x31, 968
dm_store_of 0, 0, x31, ss4, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x13, 65621
addi x13, x13, 4032
dm_load_l1 0, 0, x13, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x14, 65621
addi x14, x14, 384
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss3
lui x27, 65621
addi x27, x27, 832
dm_load_l1 0, 0, x27, x0, ss3, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x10, x10, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss2
lui x28, 65559
addi x28, x28, 2288
dm_store_of 0, 0, x28, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x29, 65621
addi x29, x29, 608
dm_load_l1 0, 0, x29, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x19, 65621
addi x19, x19, 1056
dm_load_l1 0, 0, x19, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss3
pu_fetchif_conf3 0, 0, x30, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss0
lui x1, 65621
addi x1, x1, 1504
dm_load_l1 0, 0, x1, x0, ss0, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss4
pu_fetchif_conf1 0, 0, 1, 1, ss4
ss_pack_shape x9, x10, x10, x7, ss2
pu_fetchif_conf3 0, 0, x0, x9, ss2
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss6
lui x2, 65559
addi x2, x2, 3608
dm_store_of 0, 0, x2, ss6, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x8, 65621
addi x8, x8, 1280
dm_load_l1 0, 0, x8, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x30, x20, ss5
pu_fetchif_conf1 0, 0, 1, 1, ss5
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x30, x20, ss1
lui x11, 65621
addi x11, x11, 1728
dm_load_l1 0, 0, x11, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x30, x7, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x30, x12, ss0
pu_fetchif_conf3 0, 0, x30, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x10, x20, ss4
lui x6, 65622
addi x6, x6, 2176
dm_load_l1 0, 0, x6, x0, ss4, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x10, x20, ss2
pu_fetchif_conf1 0, 0, 1, 1, ss2
ss_pack_shape x9, x10, x10, x7, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x10, x12, ss5
pu_fetchif_conf3 0, 0, x30, x9, ss5
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x10, x12, ss5
lui x31, 65559
addi x31, x31, 832
dm_store_of 0, 0, x31, ss5, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x13, x0, 2
ss_pack_shape x9, x10, x13, x20, ss1
lui x14, 65621
addi x14, x14, 1952
dm_load_l1 0, 0, x14, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x24, x25, ss7, pu
ss_pack_stride x5, x13, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x13, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
ss_pack_stride x10, x9, x12, ss4
pu_of_conf1 0, 0, x10, x0, ss4
ss_pack_shape x9, x10, x9, x12, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x17, x25, ss7, pu
ss_pack_shape x9, x10, x13, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x13, x20, ss1
lui x27, 65622
addi x27, x27, 2400
dm_load_l1 0, 0, x27, x0, ss1, if_
dm_load_w_conf 0, 0, 2, 4, x4
pu_w_conf 0, 0, 2, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x26, x25, ss7, pu
ss_pack_shape x9, x10, x13, x7, ss0
pu_fetchif_conf3 0, 0, x0, x9, ss0
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 2, 1, x21
pu_w_conf 0, 0, 2, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x15, x25, ss7, pu
ss_pack_shape x9, x10, x13, x12, ss6
pu_fetchif_conf3 0, 0, x30, x9, ss6
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x10, x9, x20, ss5
ccr_decl x9
ccr_clr 2
lui x28, 65622
addi x28, x28, 2848
dm_load_l1 0, 0, x28, x0, ss5, if_
dm_load_w_conf 0, 0, 1, 4, x3
pu_w_conf 0, 0, 1, 4
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x23, x25, ss7, pu
ss_pack_stride x5, x9, x20, ss3
pu_fetchif_conf1 0, 0, 1, 1, ss3
ss_pack_shape x9, x10, x9, x7, ss4
pu_fetchif_conf3 0, 0, x0, x9, ss4
pu_compute_conf 0, 0, 1, 0, psum, 0, pu_mode_normal
pu_compute 0, none
dm_load_w_conf 0, 0, 1, 1, x5
pu_w_conf 0, 0, 1, 1
ss_pack_stride x0, x10, x10, ss7
dm_load_w 0, 0, x16, x25, ss7, pu
ss_pack_shape x9, x10, x9, x12, ss2
pu_fetchif_conf3 0, 0, x30, x9, ss2
dm_load_act0 0, 0, x18, x22, pu, 1
ss_pack_shape x9, x10, x9, x12, ss2
ccr_decl x9
ccr_set 0, 1
lui x29, 65560
addi x29, x29, 2152
dm_store_of 0, 0, x29, ss2, pu
ss_pack_shape x9, x10, x9, x12, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
lui x19, 12
addi x19, x19, 3344
ss_pack_stride x10, x9, x19, ss1
ss_pack_stride x10, x9, x19, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x10, x9, x19, ss0
ccr_decl x9
ccr_clr 0
lw x8, x0, 4
lui x2, 0
addi x2, x2, 0
add x2, x8, x2
lui x1, 65536
addi x1, x1, 0
l2_store x2, x1, ss0
end x0
