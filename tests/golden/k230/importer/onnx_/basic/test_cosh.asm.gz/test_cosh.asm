# case: test_cosh[in_shape0]
