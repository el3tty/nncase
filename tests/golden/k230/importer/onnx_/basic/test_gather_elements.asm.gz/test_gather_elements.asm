# case: test_gather_elements[in_shape0-indices0-1]
# case: test_gather_elements[in_shape1-indices1-0]
