# case: test_slice_to_conv2d[in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 5
addi x2, x2, 2432
mmu_conf x1, x2, 1
lui x3, 5
addi x3, x3, 2448
addi x4, x0, 1
mmu_conf x3, x4, 2
lui x5, 5
addi x5, x5, 2449
mmu_conf x5, x4, 3
lui x6, 12
addi x6, x6, 1024
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x7, x0, 3
ss_pack_shape x7, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 112
addi x12, x0, 2
addi x13, x0, 224
ss_pack_stride x11, x12, x13, ss3
ss_pack_stride x7, x11, x13, ss4
mfu_transpose_conf ss4, ss3, fp16, HNCW
ss_pack_shape x7, x11, x12, x13, ss5
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x14, 65610
addi x14, x14, 2048
mfu_transpose x14, x9, ss5
lui x15, 6
addi x15, x15, 512
ss_pack_stride x7, x4, x15, ss6
ss_pack_stride x7, x4, x15, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x12, x7, x4, x15, ss7
ccr_decl x4
ccr_clr 1
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x14, ss7
end x0
# tile: k230/ptq TileTranspose_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 25
addi x2, x2, 2048
mmu_conf x1, x2, 1
lui x3, 25
addi x3, x3, 2064
lui x4, 6
addi x4, x4, 512
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x7, x0, 4
ss_pack_shape x7, x5, x5, x6, ss2
addi x11, x0, 1
ccr_decl x11
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x7, x5, x5, ss3
mfu_transpose_conf ss3, ss1, fp16, WNCH
ss_pack_shape x7, x5, x5, x6, ss2
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x12, 131072
addi x12, x12, 0
mfu_transpose x12, x9, ss2
lui x13, 3
addi x13, x13, 256
ss_pack_stride x7, x11, x13, ss4
addi x14, x0, 6
ss_pack_stride x14, x11, x13, ss5
l2_store_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x7, x11, x13, ss6
ccr_decl x11
ccr_clr 1
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x12, ss6
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x1, ss7
l2_load_conf ss7, ss0, fp16, fp32
ss_pack_shape x6, x5, x5, x6, ss1
ccr_decl x11
ccr_set 2, 1
lw x19, x0, 0
lui x17, 98
addi x17, x17, 0
add x17, x19, x17
lui x18, 65928
addi x18, x18, 0
l2_load x18, x17, ss1
ss_pack_shape x6, x5, x5, x6, ss1
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x20, 131170
addi x20, x20, 0
mfu_transpose x20, x18, ss1
ss_pack_stride x7, x11, x13, ss4
ss_pack_stride x14, x11, x13, ss5
l2_store_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x11, x13, ss3
ccr_decl x11
ccr_clr 3
lw x22, x0, 4
lui x21, 49
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss3
end x0
# case: test_slice_to_conv2d[in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 18
addi x2, x2, 1536
mmu_conf x1, x2, 1
lui x3, 18
addi x3, x3, 1552
addi x4, x0, 1
mmu_conf x3, x4, 2
lui x5, 18
addi x5, x5, 1553
mmu_conf x5, x4, 3
addi x6, x0, 56
addi x7, x0, 112
addi x8, x0, 2
ss_pack_stride x6, x7, x8, ss0
ss_pack_stride x6, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x9, x0, 6
ss_pack_shape x9, x6, x7, x8, ss2
ccr_decl x4
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x6, x7, x1, ss1
ss_pack_stride x9, x6, x7, ss3
mfu_transpose_conf ss3, ss1, fp16, WNCH
ss_pack_shape x9, x6, x7, x8, ss2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x13, 65830
addi x13, x13, 0
mfu_transpose x13, x11, ss2
lui x14, 9
addi x14, x14, 768
ss_pack_stride x4, x4, x14, ss4
ss_pack_stride x4, x4, x14, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x4, x4, x14, ss5
ccr_decl x4
ccr_clr 1
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x13, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 1216
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 1232
addi x4, x0, 1
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 1233
mmu_conf x5, x4, 3
lui x6, 6
addi x6, x6, 512
ss_pack_stride x4, x4, x6, ss0
ss_pack_stride x4, x4, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x7, x0, 3
ss_pack_shape x7, x4, x4, x6, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 56
addi x12, x0, 2
addi x13, x0, 224
ss_pack_stride x11, x12, x13, ss3
ss_pack_stride x7, x11, x13, ss4
mfu_transpose_conf ss4, ss3, fp16, HNCW
ss_pack_shape x7, x11, x12, x13, ss5
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x14, 65573
addi x14, x14, 3072
mfu_transpose x14, x9, ss5
lui x15, 9
addi x15, x15, 768
ss_pack_stride x4, x4, x15, ss6
ss_pack_stride x4, x4, x15, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x12, x4, x4, x15, ss7
ccr_decl x4
ccr_clr 1
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x14, ss7
end x0
