# case: test_quantizelinear[2-zero_point0-scale0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x19, 131072
addi x19, x19, 0
mfu_act1_compute x19, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x22, x0, 256
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_set 2, 1
lw x25, x0, 0
lui x23, 1
addi x23, x23, 2048
add x23, x25, x23
lui x24, 65536
addi x24, x24, 1024
l2_load x24, x23, ss7
mfu_act1_conf_src1 x22, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x22, ss3
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x26, 131072
addi x26, x26, 512
lui x27, 196608
addi x27, x27, 28
mfu_act1_compute x26, x24, x0, x27
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_clr 3
lw x29, x0, 4
addi x28, x0, 512
add x28, x29, x28
l2_store x28, x26, ss7
end x0
# case: test_quantizelinear[3-zero_point0-scale0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant i8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x19, 131072
addi x19, x19, 0
mfu_act1_compute x19, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x22, x0, 256
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_set 2, 1
lw x25, x0, 0
lui x23, 1
addi x23, x23, 2048
add x23, x25, x23
lui x24, 65536
addi x24, x24, 1024
l2_load x24, x23, ss7
mfu_act1_conf_src1 x22, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x22, ss3
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant i8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x26, 131072
addi x26, x26, 512
lui x27, 196608
addi x27, x27, 28
mfu_act1_compute x26, x24, x0, x27
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_clr 3
lw x29, x0, 4
addi x28, x0, 512
add x28, x29, x28
l2_store x28, x26, ss7
end x0
