# case: test_cast[13-in_shape0-10-1]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp16
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 144
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 288
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[13-in_shape1-1-10]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp16
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 288
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 144
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[13-in_shape2-1-2]
# case: test_cast[13-in_shape3-1-6]
# case: test_cast[6-in_shape0-10-1]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp16
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 144
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 288
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[6-in_shape1-1-10]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp16
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 288
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 144
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[6-in_shape2-1-2]
# case: test_cast[6-in_shape3-1-6]
# case: test_cast[9-in_shape0-10-1]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp16
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 144
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 288
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[9-in_shape1-1-10]
# tile: k230/ptq TileLoadStore_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 108
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x5, x0, 8
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_set 0, 1
lw x8, x0, 0
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
lui x7, 65536
addi x7, x7, 0
l2_load x7, x6, ss2
ss_pack_stride x3, x3, x2, ss1
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss1, fp16, fp16
ss_pack_shape x5, x3, x3, x2, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x7, ss2
ss_pack_stride x3, x3, x4, ss0
addi x11, x0, 36
ss_pack_stride x3, x3, x11, ss3
l2_load_conf ss3, ss0, fp16, fp32
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 0
addi x12, x0, 288
add x12, x14, x12
lui x13, 65536
addi x13, x13, 1152
l2_load x13, x12, ss4
ss_pack_stride x3, x3, x11, ss3
ss_pack_stride x3, x3, x4, ss0
l2_store_conf ss0, ss3, fp16, fp16
ss_pack_shape x5, x3, x3, x11, ss4
ccr_decl x3
ccr_clr 1
lw x16, x0, 4
addi x15, x0, 144
add x15, x16, x15
l2_store x15, x13, ss4
end x0
# case: test_cast[9-in_shape2-1-2]
# case: test_cast[9-in_shape3-1-6]
