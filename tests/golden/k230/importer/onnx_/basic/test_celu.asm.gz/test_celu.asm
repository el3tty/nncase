# case: test_celu[1.2-in_shape0]
# case: test_celu[None-in_shape0]
