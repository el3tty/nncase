# case: test_pool[False-padding0-1-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1740
mmu_conf x1, x2, 1
addi x3, x0, 1756
addi x4, x0, 1080
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 58
addi x14, x0, 80
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 1, 1, ss1, average, ss3
addi x15, x0, 70
addi x16, x0, 9
mfu_pdp1_conf2 x15, x13, x16, x16
ss_pack_shape x0, x0, x0, x0, ss4
lui x17, 0
addi x17, x17, 3584
mfu_pdp1_conf3 x5, x5, x17, ss4
lui x18, 4
addi x18, x18, 3072
mfu_pdp1_conf4 x5, x5, x18, 0, 0
lui x19, 2
addi x19, x19, 3076
mfu_pdp1_conf_deq x19, x0, u8
lui x20, 6
addi x20, x20, 3224
mfu_pdp1_conf_quant x20, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x22, x0, 2
ccr_decl x22
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_pdp1_compute x21, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x15, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x15, ss6
ccr_decl x9
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x21, ss6
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4071
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1740
mmu_conf x1, x2, 1
addi x3, x0, 1756
addi x4, x0, 1080
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 58
addi x14, x0, 80
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 1, 1, ss1, max, ss3
addi x15, x0, 70
addi x16, x0, 9
mfu_pdp1_conf2 x15, x13, x16, x16
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x17, 4
addi x17, x17, 3072
mfu_pdp1_conf4 x5, x5, x17, 0, 0
lui x18, 2
addi x18, x18, 3076
mfu_pdp1_conf_deq x18, x0, u8
lui x19, 6
addi x19, x19, 3064
mfu_pdp1_conf_quant x19, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x21, x0, 2
ccr_decl x21
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_pdp1_compute x20, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x15, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x15, ss6
ccr_decl x9
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x20, ss6
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[False-padding0-2-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1062
mmu_conf x1, x2, 1
addi x3, x0, 1078
addi x4, x0, 522
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 59
addi x9, x0, 96
ss_pack_stride x5, x8, x9, ss1
l2_load_conf ss1, ss0, i8, i8
addi x10, x0, 1
addi x11, x0, 71
ss_pack_shape x10, x5, x8, x11, ss2
ccr_decl x10
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
ss_pack_stride x5, x8, x9, ss1
addi x15, x0, 29
addi x16, x0, 48
ss_pack_stride x5, x15, x16, ss3
mfu_pdp1_conf1 2, 2, ss1, average, ss3
addi x17, x0, 35
addi x18, x0, 9
mfu_pdp1_conf2 x17, x15, x18, x18
ss_pack_shape x0, x0, x0, x0, ss4
lui x19, 0
addi x19, x19, 3584
mfu_pdp1_conf3 x5, x5, x19, ss4
lui x20, 4
addi x20, x20, 3072
mfu_pdp1_conf4 x5, x5, x20, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3201
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x10, x5, x8, x11, ss2
addi x24, x0, 2
ccr_decl x24
ccr_clr 0
ccr_set 1, 1
lui x23, 131072
addi x23, x23, 0
mfu_pdp1_compute x23, x13, ss2
ss_pack_stride x5, x15, x16, ss3
ss_pack_stride x5, x15, x17, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x10, x5, x15, x17, ss6
ccr_decl x10
ccr_clr 1
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x23, ss6
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4057
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1062
mmu_conf x1, x2, 1
addi x3, x0, 1078
addi x4, x0, 522
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 59
addi x9, x0, 96
ss_pack_stride x5, x8, x9, ss1
l2_load_conf ss1, ss0, i8, i8
addi x10, x0, 1
addi x11, x0, 71
ss_pack_shape x10, x5, x8, x11, ss2
ccr_decl x10
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
ss_pack_stride x5, x8, x9, ss1
addi x15, x0, 29
addi x16, x0, 48
ss_pack_stride x5, x15, x16, ss3
mfu_pdp1_conf1 2, 2, ss1, max, ss3
addi x17, x0, 35
addi x18, x0, 9
mfu_pdp1_conf2 x17, x15, x18, x18
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x19, 4
addi x19, x19, 3072
mfu_pdp1_conf4 x5, x5, x19, 0, 0
lui x20, 2
addi x20, x20, 3076
mfu_pdp1_conf_deq x20, x0, u8
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf_quant x21, x0, disable
ss_pack_shape x10, x5, x8, x11, ss2
addi x23, x0, 2
ccr_decl x23
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_pdp1_compute x22, x13, ss2
ss_pack_stride x5, x15, x16, ss3
ss_pack_stride x5, x15, x17, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x10, x5, x15, x17, ss6
ccr_decl x10
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x22, ss6
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[False-padding0-stride2-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1062
mmu_conf x1, x2, 1
addi x3, x0, 1078
addi x4, x0, 870
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 59
addi x9, x0, 96
ss_pack_stride x5, x8, x9, ss1
l2_load_conf ss1, ss0, i8, i8
addi x10, x0, 1
ss_pack_shape x10, x5, x8, x7, ss2
ccr_decl x10
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
ss_pack_stride x5, x8, x9, ss1
addi x14, x0, 29
addi x15, x0, 80
ss_pack_stride x5, x14, x15, ss3
mfu_pdp1_conf1 1, 2, ss1, average, ss3
addi x16, x0, 70
addi x17, x0, 9
mfu_pdp1_conf2 x16, x14, x17, x17
ss_pack_shape x0, x0, x0, x0, ss4
lui x18, 0
addi x18, x18, 3584
mfu_pdp1_conf3 x5, x5, x18, ss4
lui x19, 4
addi x19, x19, 3072
mfu_pdp1_conf4 x5, x5, x19, 0, 0
lui x20, 2
addi x20, x20, 3076
mfu_pdp1_conf_deq x20, x0, u8
lui x21, 6
addi x21, x21, 3238
mfu_pdp1_conf_quant x21, x0, disable
ss_pack_shape x10, x5, x8, x7, ss2
addi x23, x0, 2
ccr_decl x23
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_pdp1_compute x22, x12, ss2
ss_pack_stride x5, x14, x15, ss3
ss_pack_stride x5, x14, x16, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x10, x5, x14, x16, ss6
ccr_decl x10
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x22, ss6
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4061
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1062
mmu_conf x1, x2, 1
addi x3, x0, 1078
addi x4, x0, 870
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 59
addi x9, x0, 96
ss_pack_stride x5, x8, x9, ss1
l2_load_conf ss1, ss0, i8, i8
addi x10, x0, 1
ss_pack_shape x10, x5, x8, x7, ss2
ccr_decl x10
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
ss_pack_stride x5, x8, x9, ss1
addi x14, x0, 29
addi x15, x0, 80
ss_pack_stride x5, x14, x15, ss3
mfu_pdp1_conf1 1, 2, ss1, max, ss3
addi x16, x0, 70
addi x17, x0, 9
mfu_pdp1_conf2 x16, x14, x17, x17
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x18, 4
addi x18, x18, 3072
mfu_pdp1_conf4 x5, x5, x18, 0, 0
lui x19, 2
addi x19, x19, 3076
mfu_pdp1_conf_deq x19, x0, u8
lui x20, 6
addi x20, x20, 3064
mfu_pdp1_conf_quant x20, x0, disable
ss_pack_shape x10, x5, x8, x7, ss2
addi x22, x0, 2
ccr_decl x22
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_pdp1_compute x21, x12, ss2
ss_pack_stride x5, x14, x15, ss3
ss_pack_stride x5, x14, x16, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x10, x5, x14, x16, ss6
ccr_decl x10
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x21, ss6
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[False-padding1-1-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1800
mmu_conf x1, x2, 1
addi x3, x0, 1816
addi x4, x0, 1080
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 80
ss_pack_stride x5, x6, x13, ss3
mfu_pdp1_conf1 1, 1, ss1, average, ss3
addi x14, x0, 9
mfu_pdp1_conf2 x7, x6, x14, x14
ss_pack_shape x9, x9, x9, x9, ss4
lui x15, 0
addi x15, x15, 3584
mfu_pdp1_conf3 x5, x5, x15, ss4
lui x16, 4
addi x16, x16, 3072
mfu_pdp1_conf4 x5, x5, x16, 0, 0
lui x17, 2
addi x17, x17, 3076
mfu_pdp1_conf_deq x17, x0, u8
lui x18, 6
addi x18, x18, 3221
mfu_pdp1_conf_quant x18, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x20, x0, 2
ccr_decl x20
ccr_clr 0
ccr_set 1, 1
lui x19, 65536
addi x19, x19, 0
mfu_pdp1_compute x19, x11, ss2
ss_pack_stride x5, x6, x13, ss3
ss_pack_stride x5, x6, x7, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x19, ss2
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4053
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1800
mmu_conf x1, x2, 1
addi x3, x0, 1816
addi x4, x0, 1080
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 80
ss_pack_stride x5, x6, x13, ss3
mfu_pdp1_conf1 1, 1, ss1, max, ss3
addi x14, x0, 9
mfu_pdp1_conf2 x7, x6, x14, x14
ss_pack_shape x9, x9, x9, x9, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x15, 4
addi x15, x15, 3072
mfu_pdp1_conf4 x5, x5, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 3064
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x19, x0, 2
ccr_decl x19
ccr_clr 0
ccr_set 1, 1
lui x18, 65536
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss2
ss_pack_stride x5, x6, x13, ss3
ss_pack_stride x5, x6, x7, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_clr 1
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[False-padding1-2-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 30
addi x14, x0, 48
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 2, 2, ss1, average, ss3
addi x15, x0, 36
addi x16, x0, 9
mfu_pdp1_conf2 x15, x13, x16, x16
ss_pack_shape x9, x0, x9, x0, ss4
lui x17, 0
addi x17, x17, 3584
mfu_pdp1_conf3 x5, x5, x17, ss4
lui x18, 4
addi x18, x18, 3072
mfu_pdp1_conf4 x5, x5, x18, 0, 0
lui x19, 2
addi x19, x19, 3076
mfu_pdp1_conf_deq x19, x0, u8
lui x20, 6
addi x20, x20, 3210
mfu_pdp1_conf_quant x20, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x22, x0, 2
ccr_decl x22
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_pdp1_compute x21, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x15, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x15, ss6
ccr_decl x9
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x21, ss6
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4054
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 30
addi x14, x0, 48
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 2, 2, ss1, max, ss3
addi x15, x0, 36
addi x16, x0, 9
mfu_pdp1_conf2 x15, x13, x16, x16
ss_pack_shape x9, x0, x9, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x17, 4
addi x17, x17, 3072
mfu_pdp1_conf4 x5, x5, x17, 0, 0
lui x18, 2
addi x18, x18, 3076
mfu_pdp1_conf_deq x18, x0, u8
lui x19, 6
addi x19, x19, 3064
mfu_pdp1_conf_quant x19, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x21, x0, 2
ccr_decl x21
ccr_clr 0
ccr_set 1, 1
lui x20, 131072
addi x20, x20, 0
mfu_pdp1_compute x20, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x15, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x15, ss6
ccr_decl x9
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x20, ss6
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[False-padding1-stride2-kernel_size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 540
mmu_conf x3, x4, 2
addi x5, x0, 1636
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 3
addi x13, x13, 672
ss_pack_stride x12, x12, x13, ss0
lui x14, 2
addi x14, x14, 448
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x18, x19, ss5
mfu_act1_conf_dest x14, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
lui x24, 1
addi x24, x24, 224
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 8
addi x25, x25, 1792
add x25, x27, x25
lui x26, 65540
addi x26, x26, 896
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x18, x19, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131074
addi x28, x28, 448
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 2
addi x30, x30, 448
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TilePDP1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 900
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 30
addi x14, x0, 80
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 1, 2, ss1, average, ss3
addi x15, x0, 9
mfu_pdp1_conf2 x7, x13, x15, x15
ss_pack_shape x9, x0, x9, x9, ss4
lui x16, 0
addi x16, x16, 3584
mfu_pdp1_conf3 x5, x5, x16, ss4
lui x17, 4
addi x17, x17, 3072
mfu_pdp1_conf4 x5, x5, x17, 0, 0
lui x18, 2
addi x18, x18, 3076
mfu_pdp1_conf_deq x18, x0, u8
lui x19, 6
addi x19, x19, 3206
mfu_pdp1_conf_quant x19, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x21, x0, 2
ccr_decl x21
ccr_clr 0
ccr_set 1, 1
lui x20, 131072
addi x20, x20, 0
mfu_pdp1_compute x20, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x7, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x7, ss6
ccr_decl x9
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x20, ss6
end x0
# tile: k230/ptq TilePDP1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 1, 1, ss1, sum, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x14, 0
addi x14, x14, 3584
mfu_pdp1_conf3 x9, x9, x14, ss4
lui x15, 2
addi x15, x15, 1092
mfu_pdp1_conf4 x1, x1, x15, 0, 0
lui x16, 2
addi x16, x16, 3076
mfu_pdp1_conf_deq x16, x0, u8
lui x17, 6
addi x17, x17, 4060
mfu_pdp1_conf_quant x17, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x18, 131072
addi x18, x18, 0
mfu_pdp1_compute x18, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x19, 131072
addi x19, x19, 2
lui x20, 65536
addi x20, x20, 16
mfu_pdp1_compute x19, x20, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x21, 131072
addi x21, x21, 4
lui x22, 65536
addi x22, x22, 32
mfu_pdp1_compute x21, x22, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x23, 131072
addi x23, x23, 6
lui x24, 65536
addi x24, x24, 48
mfu_pdp1_compute x23, x24, ss5
addi x25, x0, 8
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x26, 131072
addi x26, x26, 8
lui x27, 65536
addi x27, x27, 64
mfu_pdp1_compute x26, x27, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x28, 131072
addi x28, x28, 32
lui x29, 65536
addi x29, x29, 1536
mfu_pdp1_compute x28, x29, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x30, 131072
addi x30, x30, 34
lui x31, 65536
addi x31, x31, 1552
mfu_pdp1_compute x30, x31, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x2, 131072
addi x2, x2, 36
lui x3, 65536
addi x3, x3, 1568
mfu_pdp1_compute x2, x3, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x4, 131072
addi x4, x4, 38
lui x7, 65536
addi x7, x7, 1584
mfu_pdp1_compute x4, x7, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x10, 131072
addi x10, x10, 40
lui x12, 65536
addi x12, x12, 1600
mfu_pdp1_compute x10, x12, ss6
mfu_pdp1_conf4 x1, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x6, 131072
addi x6, x6, 64
lui x8, 65537
addi x8, x8, 3072
mfu_pdp1_compute x6, x8, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x13, 131072
addi x13, x13, 66
lui x14, 65537
addi x14, x14, 3088
mfu_pdp1_compute x13, x14, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x16, 131072
addi x16, x16, 68
lui x17, 65537
addi x17, x17, 3104
mfu_pdp1_compute x16, x17, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x18, x11, ss5
mfu_pdp1_conf4 x25, x1, x15, 0, 0
ss_pack_shape x9, x5, x1, x25, ss6
lui x19, 131072
addi x19, x19, 72
lui x20, 65537
addi x20, x20, 3136
mfu_pdp1_compute x19, x20, ss6
addi x21, x0, 12
mfu_pdp1_conf2 x9, x9, x21, x21
mfu_pdp1_conf4 x1, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x1, ss7
lui x22, 131072
addi x22, x22, 96
lui x23, 65537
addi x23, x23, 512
mfu_pdp1_compute x22, x23, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x24, 131072
addi x24, x24, 98
lui x26, 65537
addi x26, x26, 528
mfu_pdp1_compute x24, x26, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x27, 131072
addi x27, x27, 100
lui x28, 65537
addi x28, x28, 544
mfu_pdp1_compute x27, x28, ss7
ss_pack_shape x9, x5, x21, x1, ss7
lui x29, 131072
addi x29, x29, 102
lui x30, 65537
addi x30, x30, 560
mfu_pdp1_compute x29, x30, ss7
mfu_pdp1_conf4 x25, x21, x15, 0, 0
ss_pack_shape x9, x5, x21, x25, ss0
lui x31, 131072
addi x31, x31, 104
lui x2, 65537
addi x2, x2, 576
mfu_pdp1_compute x31, x2, ss0
addi x3, x0, 4
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x3, x1, ss3
mfu_pdp1_conf1 1, 1, ss3, sum, ss3
ss_pack_shape x0, x0, x0, x0, ss4
lui x4, 0
addi x4, x4, 3584
mfu_pdp1_conf3 x5, x5, x4, ss4
addi x7, x0, 5
lui x10, 2
addi x10, x10, 796
mfu_pdp1_conf4 x7, x3, x10, 0, 0
lui x12, 2
addi x12, x12, 3076
mfu_pdp1_conf_deq x12, x0, disable
ss_pack_shape x9, x5, x3, x7, ss2
addi x8, x0, 2
ccr_decl x8
ccr_clr 0
ccr_set 1, 1
lui x6, 131072
addi x6, x6, 0
mfu_pdp1_compute x6, x6, ss2
ss_pack_stride x5, x3, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x6, ss5
end x0
# tile: k230/ptq TilePDP1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 900
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 30
addi x14, x0, 80
ss_pack_stride x5, x13, x14, ss3
mfu_pdp1_conf1 1, 2, ss1, max, ss3
addi x15, x0, 9
mfu_pdp1_conf2 x7, x13, x15, x15
ss_pack_shape x9, x0, x9, x9, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
lui x16, 4
addi x16, x16, 3072
mfu_pdp1_conf4 x5, x5, x16, 0, 0
lui x17, 2
addi x17, x17, 3076
mfu_pdp1_conf_deq x17, x0, u8
lui x18, 6
addi x18, x18, 3064
mfu_pdp1_conf_quant x18, x0, disable
ss_pack_shape x9, x5, x6, x7, ss2
addi x20, x0, 2
ccr_decl x20
ccr_clr 0
ccr_set 1, 1
lui x19, 131072
addi x19, x19, 0
mfu_pdp1_compute x19, x11, ss2
ss_pack_stride x5, x13, x14, ss3
ss_pack_stride x5, x13, x7, ss5
l2_store_conf ss5, ss3, fp16, fp32
ss_pack_shape x9, x5, x13, x7, ss6
ccr_decl x9
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x19, ss6
end x0
# tile: k230/ptq TilePDP1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1080
mmu_conf x1, x2, 1
addi x3, x0, 1096
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 3
addi x6, x0, 60
addi x7, x0, 72
ss_pack_stride x5, x6, x7, ss0
addi x8, x0, 96
ss_pack_stride x5, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
addi x9, x0, 1
ss_pack_shape x9, x5, x6, x7, ss2
ccr_decl x9
ccr_set 0, 2
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
ss_pack_stride x5, x6, x8, ss1
addi x13, x0, 4
ss_pack_stride x5, x13, x1, ss3
mfu_pdp1_conf1 8, 28, ss1, max, ss3
mfu_pdp1_conf2 x9, x9, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x9, x9, x0, ss4
lui x14, 2
addi x14, x14, 1092
mfu_pdp1_conf4 x1, x1, x14, 0, 0
lui x15, 2
addi x15, x15, 3076
mfu_pdp1_conf_deq x15, x0, u8
lui x16, 6
addi x16, x16, 3064
mfu_pdp1_conf_quant x16, x0, disable
ss_pack_shape x9, x5, x1, x1, ss5
ccr_decl x9
ccr_clr 0
lui x17, 131072
addi x17, x17, 0
mfu_pdp1_compute x17, x11, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x18, 131072
addi x18, x18, 2
lui x19, 65536
addi x19, x19, 16
mfu_pdp1_compute x18, x19, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x20, 131072
addi x20, x20, 4
lui x21, 65536
addi x21, x21, 32
mfu_pdp1_compute x20, x21, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x22, 131072
addi x22, x22, 6
lui x23, 65536
addi x23, x23, 48
mfu_pdp1_compute x22, x23, ss5
addi x24, x0, 8
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x25, 131072
addi x25, x25, 8
lui x26, 65536
addi x26, x26, 64
mfu_pdp1_compute x25, x26, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x27, 131072
addi x27, x27, 32
lui x28, 65536
addi x28, x28, 1536
mfu_pdp1_compute x27, x28, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x29, 131072
addi x29, x29, 34
lui x30, 65536
addi x30, x30, 1552
mfu_pdp1_compute x29, x30, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x31, 131072
addi x31, x31, 36
lui x2, 65536
addi x2, x2, 1568
mfu_pdp1_compute x31, x2, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x3, 131072
addi x3, x3, 38
lui x4, 65536
addi x4, x4, 1584
mfu_pdp1_compute x3, x4, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x7, 131072
addi x7, x7, 40
lui x10, 65536
addi x10, x10, 1600
mfu_pdp1_compute x7, x10, ss6
mfu_pdp1_conf4 x1, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x1, ss5
lui x12, 131072
addi x12, x12, 64
lui x6, 65537
addi x6, x6, 3072
mfu_pdp1_compute x12, x6, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x8, 131072
addi x8, x8, 66
lui x13, 65537
addi x13, x13, 3088
mfu_pdp1_compute x8, x13, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x15, 131072
addi x15, x15, 68
lui x16, 65537
addi x16, x16, 3104
mfu_pdp1_compute x15, x16, ss5
ss_pack_shape x9, x5, x1, x1, ss5
lui x17, 131072
addi x17, x17, 70
lui x11, 65537
addi x11, x11, 3120
mfu_pdp1_compute x17, x11, ss5
mfu_pdp1_conf4 x24, x1, x14, 0, 0
ss_pack_shape x9, x5, x1, x24, ss6
lui x18, 131072
addi x18, x18, 72
lui x19, 65537
addi x19, x19, 3136
mfu_pdp1_compute x18, x19, ss6
addi x20, x0, 12
mfu_pdp1_conf2 x9, x9, x20, x20
mfu_pdp1_conf4 x1, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x1, ss7
lui x21, 131072
addi x21, x21, 96
lui x22, 65537
addi x22, x22, 512
mfu_pdp1_compute x21, x22, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x23, 131072
addi x23, x23, 98
lui x25, 65537
addi x25, x25, 528
mfu_pdp1_compute x23, x25, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x26, 131072
addi x26, x26, 100
lui x27, 65537
addi x27, x27, 544
mfu_pdp1_compute x26, x27, ss7
ss_pack_shape x9, x5, x20, x1, ss7
lui x28, 131072
addi x28, x28, 102
lui x29, 65537
addi x29, x29, 560
mfu_pdp1_compute x28, x29, ss7
mfu_pdp1_conf4 x24, x20, x14, 0, 0
ss_pack_shape x9, x5, x20, x24, ss0
lui x30, 131072
addi x30, x30, 104
lui x31, 65537
addi x31, x31, 576
mfu_pdp1_compute x30, x31, ss0
addi x2, x0, 4
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x2, x1, ss3
mfu_pdp1_conf1 8, 28, ss3, max, ss3
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x5, x5, x0, ss4
addi x3, x0, 5
lui x4, 2
addi x4, x4, 796
mfu_pdp1_conf4 x3, x2, x4, 0, 0
lui x7, 2
addi x7, x7, 3076
mfu_pdp1_conf_deq x7, x0, disable
ss_pack_shape x9, x5, x2, x3, ss2
addi x12, x0, 2
ccr_decl x12
ccr_clr 0
ccr_set 1, 1
lui x10, 131072
addi x10, x10, 0
mfu_pdp1_compute x10, x10, ss2
ss_pack_stride x5, x2, x1, ss3
ss_pack_stride x5, x9, x9, ss1
l2_store_conf ss1, ss3, fp16, fp32
ss_pack_shape x9, x5, x9, x9, ss5
ccr_decl x9
ccr_clr 1
lw x8, x0, 4
lui x6, 0
addi x6, x6, 0
add x6, x8, x6
l2_store x6, x10, ss5
end x0
# case: test_pool[True-padding0-1-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1740
mmu_conf x1, x2, 1
addi x3, x0, 1756
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1758
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1759
mmu_conf x7, x6, 4
lui x8, 3
addi x8, x8, 672
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
addi x20, x0, 96
ss_pack_stride x17, x18, x20, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_dest x8, ss6
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65543
addi x22, x22, 3264
mfu_act1_compute x22, x10, x0, x14
ss_pack_stride x17, x18, x20, ss5
addi x23, x0, 58
addi x24, x0, 80
ss_pack_stride x17, x23, x24, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
addi x25, x0, 70
addi x26, x0, 9
mfu_pdp1_conf2 x25, x23, x26, x26
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x17, x17, x0, ss4
mfu_pdp1_conf4 x17, x17, x21, 0, 0
lui x27, 2
addi x27, x27, 3076
mfu_pdp1_conf_deq x27, x0, u8
lui x28, 6
addi x28, x28, 3240
mfu_pdp1_conf_quant x28, x0, disable
ss_pack_shape x6, x17, x18, x19, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x22, ss6
ss_pack_stride x17, x23, x24, ss7
ss_pack_stride x17, x23, x25, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x23, x25, ss1
ccr_decl x6
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss1
end x0
# case: test_pool[True-padding0-2-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1572
mmu_conf x1, x2, 1
addi x3, x0, 1588
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1590
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1591
mmu_conf x7, x6, 4
addi x8, x0, 3
addi x9, x0, 60
addi x10, x0, 72
ss_pack_stride x8, x9, x10, ss0
addi x11, x0, 59
addi x12, x0, 71
ss_pack_stride x8, x11, x12, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x8, x11, x12, ss2
ccr_decl x6
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 65536
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 21
l2_load_w_conf x16, x16, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 8
lui x17, 0
addi x17, x17, 0
add x17, x19, x17
lui x18, 131072
addi x18, x18, 0
addi x20, x0, 23
l2_load_w x18, x17, x20
ss_pack_stride x8, x11, x12, ss1
ss_pack_stride x0, x0, x0, ss3
addi x21, x0, 96
ss_pack_stride x8, x11, x21, ss4
mfu_act1_conf_stride ss1, ss3, ss4
lui x22, 3
addi x22, x22, 279
mfu_act1_conf_src1 x22, x6, x6, 0, l2
ss_pack_shape x6, x8, x11, x12, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x8, x11, x12, ss2
mfu_act1_conf_dest x22, ss2
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x8
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x24, 65542
addi x24, x24, 576
mfu_act1_compute x24, x14, x0, x18
ss_pack_stride x8, x11, x21, ss4
addi x25, x0, 29
addi x26, x0, 48
ss_pack_stride x8, x25, x26, ss5
mfu_pdp1_conf1 2, 2, ss4, average, ss5
addi x27, x0, 35
addi x28, x0, 9
mfu_pdp1_conf2 x27, x25, x28, x28
ss_pack_shape x0, x0, x0, x0, ss3
mfu_pdp1_conf3 x8, x8, x0, ss3
mfu_pdp1_conf4 x8, x8, x23, 0, 0
lui x29, 2
addi x29, x29, 3076
mfu_pdp1_conf_deq x29, x0, u8
lui x30, 6
addi x30, x30, 3276
mfu_pdp1_conf_quant x30, x0, disable
ss_pack_shape x6, x8, x11, x12, ss2
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x14, x24, ss2
ss_pack_stride x8, x25, x26, ss5
ss_pack_stride x8, x25, x27, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x8, x25, x27, ss7
ccr_decl x6
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x14, ss7
end x0
# case: test_pool[True-padding0-stride2-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1594
mmu_conf x1, x2, 1
addi x3, x0, 1610
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1612
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1613
mmu_conf x7, x6, 4
addi x8, x0, 3
lui x9, 1
addi x9, x9, 224
ss_pack_stride x8, x6, x9, ss0
lui x10, 1
addi x10, x10, 152
ss_pack_stride x8, x6, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x8, x6, x10, ss2
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 59
addi x20, x0, 72
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
addi x21, x0, 96
ss_pack_stride x8, x19, x21, ss5
mfu_act1_conf_stride ss3, ss4, ss5
lui x22, 3
addi x22, x22, 456
mfu_act1_conf_src1 x22, x6, x6, 0, l2
ss_pack_shape x6, x8, x19, x20, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x8, x19, x20, ss6
mfu_act1_conf_dest x22, ss6
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x8
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x24, 65542
addi x24, x24, 928
mfu_act1_compute x24, x12, x0, x16
ss_pack_stride x8, x19, x21, ss5
addi x25, x0, 29
addi x26, x0, 80
ss_pack_stride x8, x25, x26, ss7
mfu_pdp1_conf1 1, 2, ss5, average, ss7
addi x27, x0, 70
addi x28, x0, 9
mfu_pdp1_conf2 x27, x25, x28, x28
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x8, x8, x0, ss4
mfu_pdp1_conf4 x8, x8, x23, 0, 0
lui x29, 2
addi x29, x29, 3076
mfu_pdp1_conf_deq x29, x0, u8
lui x30, 6
addi x30, x30, 3235
mfu_pdp1_conf_quant x30, x0, disable
ss_pack_shape x6, x8, x19, x20, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x12, x24, ss6
ss_pack_stride x8, x25, x26, ss7
ss_pack_stride x8, x25, x27, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x8, x25, x27, ss1
ccr_decl x6
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss1
end x0
# case: test_pool[True-padding1-1-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1800
mmu_conf x1, x2, 1
addi x3, x0, 1816
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1818
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1819
mmu_conf x7, x6, 4
lui x8, 3
addi x8, x8, 672
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
addi x20, x0, 96
ss_pack_stride x17, x18, x20, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_dest x8, ss6
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65543
addi x22, x22, 128
mfu_act1_compute x22, x10, x0, x14
ss_pack_stride x17, x18, x20, ss5
addi x23, x0, 80
ss_pack_stride x17, x18, x23, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
addi x24, x0, 9
mfu_pdp1_conf2 x19, x18, x24, x24
ss_pack_shape x6, x6, x6, x6, ss0
mfu_pdp1_conf3 x17, x17, x0, ss0
mfu_pdp1_conf4 x17, x17, x21, 0, 0
lui x25, 2
addi x25, x25, 3076
mfu_pdp1_conf_deq x25, x0, u8
lui x26, 6
addi x26, x26, 3229
mfu_pdp1_conf_quant x26, x0, disable
ss_pack_shape x6, x17, x18, x19, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x22, ss6
ss_pack_stride x17, x18, x23, ss7
ss_pack_stride x17, x18, x19, ss3
l2_store_conf ss3, ss7, fp16, fp32
ss_pack_shape x6, x17, x18, x19, ss6
ccr_decl x6
ccr_clr 0
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x10, ss6
end x0
# case: test_pool[True-padding1-2-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1620
mmu_conf x1, x2, 1
addi x3, x0, 1636
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1638
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1639
mmu_conf x7, x6, 4
lui x8, 3
addi x8, x8, 672
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
addi x20, x0, 96
ss_pack_stride x17, x18, x20, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_dest x8, ss6
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65542
addi x22, x22, 1344
mfu_act1_compute x22, x10, x0, x14
ss_pack_stride x17, x18, x20, ss5
addi x23, x0, 30
addi x24, x0, 48
ss_pack_stride x17, x23, x24, ss7
mfu_pdp1_conf1 2, 2, ss5, average, ss7
addi x25, x0, 36
addi x26, x0, 9
mfu_pdp1_conf2 x25, x23, x26, x26
ss_pack_shape x6, x0, x6, x0, ss0
mfu_pdp1_conf3 x17, x17, x0, ss0
mfu_pdp1_conf4 x17, x17, x21, 0, 0
lui x27, 2
addi x27, x27, 3076
mfu_pdp1_conf_deq x27, x0, u8
lui x28, 6
addi x28, x28, 3217
mfu_pdp1_conf_quant x28, x0, disable
ss_pack_shape x6, x17, x18, x19, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x22, ss6
ss_pack_stride x17, x23, x24, ss7
ss_pack_stride x17, x23, x25, ss1
l2_store_conf ss1, ss7, fp16, fp32
ss_pack_shape x6, x17, x23, x25, ss2
ccr_decl x6
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss2
end x0
# case: test_pool[True-padding1-stride2-kernel_size0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1620
mmu_conf x1, x2, 1
addi x3, x0, 1636
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 1638
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 1639
mmu_conf x7, x6, 4
lui x8, 3
addi x8, x8, 672
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 60
addi x19, x0, 72
ss_pack_stride x17, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
addi x20, x0, 96
ss_pack_stride x17, x18, x20, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x19, ss6
mfu_act1_conf_dest x8, ss6
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65542
addi x22, x22, 1344
mfu_act1_compute x22, x10, x0, x14
ss_pack_stride x17, x18, x20, ss5
addi x23, x0, 30
addi x24, x0, 80
ss_pack_stride x17, x23, x24, ss7
mfu_pdp1_conf1 1, 2, ss5, average, ss7
addi x25, x0, 9
mfu_pdp1_conf2 x19, x23, x25, x25
ss_pack_shape x6, x0, x6, x6, ss0
mfu_pdp1_conf3 x17, x17, x0, ss0
mfu_pdp1_conf4 x17, x17, x21, 0, 0
lui x26, 2
addi x26, x26, 3076
mfu_pdp1_conf_deq x26, x0, u8
lui x27, 6
addi x27, x27, 3272
mfu_pdp1_conf_quant x27, x0, disable
ss_pack_shape x6, x17, x18, x19, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x22, ss6
ss_pack_stride x17, x23, x24, ss7
ss_pack_stride x17, x23, x19, ss1
l2_store_conf ss1, ss7, fp16, fp32
ss_pack_shape x6, x17, x23, x19, ss2
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss2
end x0
