# case: test_random_uniform_like[1.0-2.0-1.0-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 4
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x3, x0, 8
lui x2, 0
addi x2, x2, 0
add x2, x3, x2
l2_store x2, x21, ss2
end x0
# case: test_random_uniform_like[1.0-2.0-1.0-None-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 4
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x3, x0, 8
lui x2, 0
addi x2, x2, 0
add x2, x3, x2
l2_store x2, x21, ss2
end x0
# case: test_random_uniform_like[1.0-2.0-None-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x3, x0, 8
lui x2, 0
addi x2, x2, 0
add x2, x3, x2
l2_store x2, x21, ss2
end x0
# case: test_random_uniform_like[1.0-2.0-None-None-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x3, x0, 8
lui x2, 0
addi x2, x2, 0
add x2, x3, x2
l2_store x2, x21, ss2
end x0
# case: test_random_uniform_like[1.0-None-1.0-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
lui x23, 0
addi x23, x23, 0
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 42
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x2, x31
l2_store x31, x21, ss2
end x0
# case: test_random_uniform_like[1.0-None-1.0-None-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
lui x23, 0
addi x23, x23, 0
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 42
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x2, x31
l2_store x31, x21, ss2
end x0
# case: test_random_uniform_like[1.0-None-None-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3075
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x2, x31
l2_store x31, x21, ss2
end x0
# case: test_random_uniform_like[1.0-None-None-None-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 144
mmu_conf x1, x2, 1
addi x3, x0, 160
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 166
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 167
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65537
addi x21, x21, 3072
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 131072
addi x24, x24, 64
l2_load_w x24, x23, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3075
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x3, x0, 8
lui x2, 0
addi x2, x2, 0
add x2, x3, x2
l2_store x2, x21, ss2
end x0
