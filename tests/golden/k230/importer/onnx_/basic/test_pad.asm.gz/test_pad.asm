# case: test_pad[op_version_and_value_format0-constant-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-constant-0.0-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-0.0-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-constant-1.2-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1200
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1800
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2400
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2448
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 704
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_load x8, x12, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x20, x19
l2_load x18, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x18, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2402
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 600
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_load x8, x10, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x18, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x18, x17
l2_load x16, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x19, x0, 600
ss_pack_shape x6, x6, x6, x19, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 624
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1248
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1872
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2496
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2544
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 896
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1248
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1872
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2496
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2498
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 624
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-1.2-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x7, 65536
addi x7, x7, 0
lui x6, 4
addi x6, x6, 3277
mfu_memset x7, x6, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 24
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x9, x9, ss4
ccr_decl x5
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 54
l2_load x11, x10, ss4
addi x13, x0, 1352
ss_pack_stride x5, x5, x13, ss5
addi x14, x0, 2028
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x13, ss7
ccr_decl x5
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x17, 65537
addi x17, x17, 2720
mfu_memset x17, x6, ss0, ss1, fp16
fence
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x9, x9, ss4
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2774
l2_load x19, x18, ss4
ss_pack_stride x5, x5, x13, ss5
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 676
ss_pack_shape x5, x5, x5, x21, ss7
ccr_decl x5
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 1312
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-constant-None-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-constant-None-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format0-edge-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-edge-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format0-reflect-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-constant-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-constant-0.0-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-0.0-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-constant-1.2-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1200
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1800
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2400
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2448
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 704
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_load x8, x12, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x20, x19
l2_load x18, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x18, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2402
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 600
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_load x8, x10, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x18, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x18, x17
l2_load x16, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x19, x0, 600
ss_pack_shape x6, x6, x6, x19, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 624
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1248
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1872
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2496
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2544
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 896
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1248
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1872
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2496
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2498
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 624
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-1.2-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x7, 65536
addi x7, x7, 0
lui x6, 4
addi x6, x6, 3277
mfu_memset x7, x6, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 24
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x9, x9, ss4
ccr_decl x5
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 54
l2_load x11, x10, ss4
addi x13, x0, 1352
ss_pack_stride x5, x5, x13, ss5
addi x14, x0, 2028
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x13, ss7
ccr_decl x5
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x17, 65537
addi x17, x17, 2720
mfu_memset x17, x6, ss0, ss1, fp16
fence
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x9, x9, ss4
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2774
l2_load x19, x18, ss4
ss_pack_stride x5, x5, x13, ss5
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 676
ss_pack_shape x5, x5, x5, x21, ss7
ccr_decl x5
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 1312
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-constant-None-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-constant-None-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format1-edge-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-edge-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format1-reflect-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-constant-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-constant-0.0-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-0.0-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-constant-1.2-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1200
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1800
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2400
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2448
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 704
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_load x8, x12, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x20, x19
l2_load x18, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x18, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2402
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 600
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_load x8, x10, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x18, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x18, x17
l2_load x16, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x19, x0, 600
ss_pack_shape x6, x6, x6, x19, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 624
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1248
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1872
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2496
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2544
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 896
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1248
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1872
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2496
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2498
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 624
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-1.2-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x7, 65536
addi x7, x7, 0
lui x6, 4
addi x6, x6, 3277
mfu_memset x7, x6, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 24
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x9, x9, ss4
ccr_decl x5
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 54
l2_load x11, x10, ss4
addi x13, x0, 1352
ss_pack_stride x5, x5, x13, ss5
addi x14, x0, 2028
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x13, ss7
ccr_decl x5
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x17, 65537
addi x17, x17, 2720
mfu_memset x17, x6, ss0, ss1, fp16
fence
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x9, x9, ss4
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2774
l2_load x19, x18, ss4
ss_pack_stride x5, x5, x13, ss5
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 676
ss_pack_shape x5, x5, x5, x21, ss7
ccr_decl x5
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 1312
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-constant-None-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-constant-None-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format2-edge-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-edge-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format2-reflect-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-constant-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-constant-0.0-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-0.0-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-constant-1.2-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1200
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1800
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2400
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2448
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 704
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_load x8, x12, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x20, x19
l2_load x18, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x18, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2402
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 600
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_load x8, x10, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x18, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x18, x17
l2_load x16, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x19, x0, 600
ss_pack_shape x6, x6, x6, x19, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 624
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1248
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1872
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2496
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2544
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 896
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1248
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1872
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2496
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2498
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 624
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-1.2-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x7, 65536
addi x7, x7, 0
lui x6, 4
addi x6, x6, 3277
mfu_memset x7, x6, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 24
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x9, x9, ss4
ccr_decl x5
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 54
l2_load x11, x10, ss4
addi x13, x0, 1352
ss_pack_stride x5, x5, x13, ss5
addi x14, x0, 2028
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x13, ss7
ccr_decl x5
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x17, 65537
addi x17, x17, 2720
mfu_memset x17, x6, ss0, ss1, fp16
fence
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x9, x9, ss4
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2774
l2_load x19, x18, ss4
ss_pack_stride x5, x5, x13, ss5
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 676
ss_pack_shape x5, x5, x5, x21, ss7
ccr_decl x5
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 1312
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-constant-None-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-constant-None-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format3-edge-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-edge-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format3-reflect-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-constant-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-constant-0.0-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-0.0-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-constant-1.2-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1200
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1800
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2400
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2448
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 704
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 600
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x13, x12
l2_load x8, x12, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x20, x19
l2_load x18, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x18, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2402
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 600
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_load x8, x10, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x18, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x18, x17
l2_load x16, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x19, x0, 600
ss_pack_shape x6, x6, x6, x19, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
addi x10, x0, 576
ss_pack_stride x9, x6, x10, ss2
addi x11, x0, 624
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x10, ss4
ccr_decl x6
ccr_set 0, 1
lw x14, x0, 0
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 48
l2_load x13, x12, ss4
addi x15, x0, 1248
ss_pack_stride x6, x6, x15, ss5
addi x16, x0, 1872
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x15, ss7
ccr_decl x6
ccr_clr 0
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x19, 65537
addi x19, x19, 2496
mfu_memset x19, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x6, x10, ss2
ss_pack_stride x9, x6, x11, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss4
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 0
lui x20, 1
addi x20, x20, 512
add x20, x22, x20
lui x21, 65537
addi x21, x21, 2544
l2_load x21, x20, ss4
ss_pack_stride x6, x6, x15, ss5
ss_pack_stride x6, x6, x16, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 1
lw x24, x0, 4
lui x23, 1
addi x23, x23, 896
add x23, x24, x23
l2_store x23, x19, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x8, 65536
addi x8, x8, 0
lui x7, 4
addi x7, x7, 3277
mfu_memset x8, x7, ss0, ss1, fp16
fence
addi x9, x0, 3
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 2
l2_load x11, x10, ss4
addi x13, x0, 1248
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1872
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x8, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2496
mfu_memset x17, x7, ss0, ss1, fp16
fence
ss_pack_stride x9, x4, x4, ss2
ss_pack_stride x9, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2498
l2_load x19, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 624
ss_pack_shape x6, x6, x6, x21, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-1.2-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x7, 65536
addi x7, x7, 0
lui x6, 4
addi x6, x6, 3277
mfu_memset x7, x6, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 24
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x9, x9, ss4
ccr_decl x5
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 54
l2_load x11, x10, ss4
addi x13, x0, 1352
ss_pack_stride x5, x5, x13, ss5
addi x14, x0, 2028
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x13, ss7
ccr_decl x5
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x17, 65537
addi x17, x17, 2720
mfu_memset x17, x6, ss0, ss1, fp16
fence
ss_pack_stride x8, x9, x9, ss2
ss_pack_stride x8, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x9, x9, ss4
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x20, x18
lui x19, 65537
addi x19, x19, 2774
l2_load x19, x18, ss4
ss_pack_stride x5, x5, x13, ss5
ss_pack_stride x5, x5, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x21, x0, 676
ss_pack_shape x5, x5, x5, x21, ss7
ccr_decl x5
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 1312
add x22, x23, x22
l2_store x22, x17, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-constant-None-padding1-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1200
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1800
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2400
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2448
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 704
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding2-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 25
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 600
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_load x7, x11, ss4
addi x13, x0, 1200
ss_pack_stride x6, x6, x13, ss5
addi x14, x0, 1800
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x13, ss7
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
l2_store x15, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x17, 65537
addi x17, x17, 2400
mfu_memset x17, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x18, 1
addi x18, x18, 512
add x18, x19, x18
l2_load x17, x18, ss4
ss_pack_stride x6, x6, x13, ss5
ss_pack_stride x6, x6, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x21, x0, 4
lui x20, 1
addi x20, x20, 704
add x20, x21, x20
l2_store x20, x17, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding3-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1200
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1800
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2400
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2402
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 600
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 704
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding4-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 150
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 25
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_load x7, x9, ss4
addi x11, x0, 1200
ss_pack_stride x6, x6, x11, ss5
addi x12, x0, 1800
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x11, ss7
ccr_decl x6
ccr_clr 0
lw x14, x0, 4
lui x13, 0
addi x13, x13, 0
add x13, x14, x13
l2_store x13, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x15, 65537
addi x15, x15, 2400
mfu_memset x15, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x17, x0, 0
lui x16, 1
addi x16, x16, 512
add x16, x17, x16
l2_load x15, x16, ss4
ss_pack_stride x6, x6, x11, ss5
ss_pack_stride x6, x6, x12, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x18, x0, 600
ss_pack_shape x6, x6, x6, x18, ss7
ccr_decl x6
ccr_clr 1
lw x20, x0, 4
lui x19, 1
addi x19, x19, 704
add x19, x20, x19
l2_store x19, x15, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding5-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
addi x5, x0, 24
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
addi x9, x0, 576
ss_pack_stride x8, x6, x9, ss2
addi x10, x0, 624
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x6, x9, ss4
ccr_decl x6
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 48
l2_load x12, x11, ss4
addi x14, x0, 1248
ss_pack_stride x6, x6, x14, ss5
addi x15, x0, 1872
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x14, ss7
ccr_decl x6
ccr_clr 0
lw x17, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x17, x16
l2_store x16, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x18, 65537
addi x18, x18, 2496
mfu_memset x18, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x6, x9, ss2
ss_pack_stride x8, x6, x10, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss4
ccr_decl x6
ccr_set 1, 1
lw x21, x0, 0
lui x19, 1
addi x19, x19, 512
add x19, x21, x19
lui x20, 65537
addi x20, x20, 2544
l2_load x20, x19, ss4
ss_pack_stride x6, x6, x14, ss5
ss_pack_stride x6, x6, x15, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x10, ss7
ccr_decl x6
ccr_clr 1
lw x23, x0, 4
lui x22, 1
addi x22, x22, 896
add x22, x23, x22
l2_store x22, x18, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding6-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 156
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 24
addi x5, x0, 26
ss_pack_stride x3, x4, x5, ss0
addi x6, x0, 1
ss_pack_shape x6, x3, x4, x5, ss1
lui x7, 65536
addi x7, x7, 0
mfu_memset x7, x0, ss0, ss1, fp16
fence
addi x8, x0, 3
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x3, x4, x4, ss4
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 2
l2_load x10, x9, ss4
addi x12, x0, 1248
ss_pack_stride x6, x6, x12, ss5
addi x13, x0, 1872
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss7
ccr_decl x6
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x7, ss7
ss_pack_stride x6, x4, x5, ss0
ss_pack_shape x6, x6, x4, x5, ss1
lui x16, 65537
addi x16, x16, 2496
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x8, x4, x4, ss2
ss_pack_stride x8, x4, x5, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x6, x6, x4, x4, ss4
ccr_decl x6
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2498
l2_load x18, x17, ss4
ss_pack_stride x6, x6, x12, ss5
ss_pack_stride x6, x6, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 624
ss_pack_shape x6, x6, x6, x20, ss7
ccr_decl x6
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 896
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-constant-None-padding7-in_shape0]
# tile: k230/ptq TilePad_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 170
mmu_conf x1, x2, 1
addi x3, x0, 2
addi x4, x0, 26
ss_pack_stride x3, x4, x4, ss0
addi x5, x0, 1
ss_pack_shape x5, x3, x4, x4, ss1
lui x6, 65536
addi x6, x6, 0
mfu_memset x6, x0, ss0, ss1, fp16
fence
addi x7, x0, 3
addi x8, x0, 24
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x3, x8, x8, ss4
ccr_decl x5
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 54
l2_load x10, x9, ss4
addi x12, x0, 1352
ss_pack_stride x5, x5, x12, ss5
addi x13, x0, 2028
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x5, x5, x5, x12, ss7
ccr_decl x5
ccr_clr 0
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x6, ss7
ss_pack_stride x5, x4, x4, ss0
ss_pack_shape x5, x5, x4, x4, ss1
lui x16, 65537
addi x16, x16, 2720
mfu_memset x16, x0, ss0, ss1, fp16
fence
ss_pack_stride x7, x8, x8, ss2
ss_pack_stride x7, x4, x4, ss3
l2_load_conf ss3, ss2, fp16, fp32
ss_pack_shape x5, x5, x8, x8, ss4
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 0
lui x17, 1
addi x17, x17, 512
add x17, x19, x17
lui x18, 65537
addi x18, x18, 2774
l2_load x18, x17, ss4
ss_pack_stride x5, x5, x12, ss5
ss_pack_stride x5, x5, x13, ss6
l2_store_conf ss6, ss5, fp16, fp32
addi x20, x0, 676
ss_pack_shape x5, x5, x5, x20, ss7
ccr_decl x5
ccr_clr 1
lw x22, x0, 4
lui x21, 1
addi x21, x21, 1312
add x21, x22, x21
l2_store x21, x16, ss7
end x0
# case: test_pad[op_version_and_value_format4-edge-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-edge-None-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-0.0-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-1.2-padding7-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding0-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding1-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding2-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding3-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding4-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding5-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding6-in_shape0]
# case: test_pad[op_version_and_value_format4-reflect-None-padding7-in_shape0]
