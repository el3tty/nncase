# case: test_sign[in_shape0]
