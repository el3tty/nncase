# case: test_sinh[in_shape0]
