# case: test_selu[1.5-1.5-in_shape0]
# case: test_selu[1.5-None-in_shape0]
# case: test_selu[None-1.5-in_shape0]
# case: test_selu[None-None-in_shape0]
