# case: test_relu[in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x5, ss0
ss_pack_stride x5, x5, x5, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x5, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x5, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x5, ss2
mfu_act1_conf_dest x5, ss2
lui x21, 2
addi x21, x21, 2684
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x5, ss1
ss_pack_stride x5, x5, x5, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x5, ss2
ccr_decl x5
ccr_clr 0
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x8, ss2
end x0
# case: test_relu[in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 24
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 26
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 27
mmu_conf x7, x6, 4
addi x8, x0, 64
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x2, x2, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x2, x2, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x2, x2, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x2, x2, ss5
mfu_act1_conf_dest x8, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 128
mfu_act1_compute x18, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x6, x2, x2, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x2, x2, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x2, x2, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x2, x2, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x18, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss2
end x0
# case: test_relu[in_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 24
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 26
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 27
mmu_conf x7, x6, 4
addi x8, x0, 64
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 4
ss_pack_stride x6, x17, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 128
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 14
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x6, x17, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3074
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_relu[in_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 236
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 237
mmu_conf x7, x6, 4
addi x8, x0, 1728
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 24
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65537
addi x20, x20, 3456
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
