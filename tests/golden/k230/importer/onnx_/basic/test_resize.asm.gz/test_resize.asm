# case: test_resize[InterpolationMode.NEAREST-size0-in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 128
mmu_conf x1, x2, 1
addi x3, x0, 144
addi x4, x0, 64
mmu_conf x3, x4, 2
addi x5, x0, 208
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
addi x18, x0, 1024
mfu_act1_conf_src1 x18, x12, x12, 0, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x1, x1, ss5
mfu_act1_conf_dest x18, ss5
lui x19, 2
addi x19, x19, 3076
mfu_act1_conf_deq x19, x0, u8, 0
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x24, x0, 256
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 512
add x25, x27, x25
lui x26, 131072
addi x26, x26, 1024
l2_load x26, x25, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x1, x1, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 65537
addi x28, x28, 2048
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# tile: k230/ptq TileResize_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 48
mmu_conf x3, x4, 2
addi x5, x0, 1
lui x6, 1
addi x6, x6, 3072
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
lui x8, 65536
addi x8, x8, 0
extraw 0, x8, 0
lui x10, 65536
addi x10, x10, 1024
extraw 4, x10, 0
lui x11, 65537
addi x11, x11, 2048
extraw 8, x11, 0
lui x12, 65537
addi x12, x12, 3072
extraw 12, x12, 0
lui x13, 131072
addi x13, x13, 0
extraw 16, x13, 0
lui x14, 131072
addi x14, x14, 256
extraw 20, x14, 0
lui x15, 131072
addi x15, x15, 512
extraw 24, x15, 0
lui x16, 131072
addi x16, x16, 768
extraw 28, x16, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 256
addi x18, x18, 16
extrw 40, x18, 0
lui x18, 256
addi x18, x18, 16
extrw 44, x18, 0
lui x19, 282624
addi x19, x19, 0
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x19, 282624
addi x19, x19, 0
extrw 60, x19, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x20, 209152
addi x20, x20, 155
extrw 72, x20, 0
extrw 76, x0, 0
addi x21, x0, 256
extrw 80, x21, 0
lui x22, 3950
addi x22, x22, 292
extrw 84, x22, 0
lui x23, 3995
addi x23, x23, 256
extrw 88, x23, 0
lui x24, 126
addi x24, x24, 3947
extrw 92, x24, 0
lui x25, 3836
addi x25, x25, 0
extrw 96, x25, 0
lui x26, 16384
addi x26, x26, 0
extrw 100, x26, 0
lui x27, 520
addi x27, x27, 256
extrw 104, x27, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x28, 496
addi x28, x28, 31
extrw 120, x28, 0
lui x18, 256
addi x18, x18, 16
extrw 124, x18, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x29, 524288
addi x29, x29, 0
extrw 140, x29, 0
addi x30, x0, 2
ccr_decl x30
ccr_clr 0
ccr_set 1, 1
ai2d_compute
addi x31, x0, 768
ss_pack_stride x5, x5, x31, ss3
ss_pack_stride x5, x5, x31, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x5, x5, x5, x31, ss4
ccr_decl x5
ccr_clr 1
lw x2, x0, 4
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x13, ss4
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss5
l2_load_conf ss5, ss1, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 2, 1
lw x4, x0, 0
lui x3, 1
addi x3, x3, 3072
add x3, x4, x3
l2_load x12, x3, ss2
lui x12, 65537
addi x12, x12, 3072
extraw 0, x12, 0
lui x7, 65537
addi x7, x7, 0
extraw 4, x7, 0
lui x9, 65537
addi x9, x9, 1024
extraw 8, x9, 0
lui x8, 65538
addi x8, x8, 2048
extraw 12, x8, 0
lui x16, 131072
addi x16, x16, 768
extraw 16, x16, 0
lui x10, 131072
addi x10, x10, 1024
extraw 20, x10, 0
lui x11, 131072
addi x11, x11, 1280
extraw 24, x11, 0
lui x14, 131072
addi x14, x14, 1536
extraw 28, x14, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 256
addi x18, x18, 16
extrw 40, x18, 0
lui x18, 256
addi x18, x18, 16
extrw 44, x18, 0
lui x19, 282624
addi x19, x19, 0
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x19, 282624
addi x19, x19, 0
extrw 60, x19, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x20, 209152
addi x20, x20, 155
extrw 72, x20, 0
extrw 76, x0, 0
addi x21, x0, 256
extrw 80, x21, 0
lui x22, 3950
addi x22, x22, 292
extrw 84, x22, 0
lui x23, 3995
addi x23, x23, 256
extrw 88, x23, 0
lui x24, 126
addi x24, x24, 3947
extrw 92, x24, 0
lui x25, 3836
addi x25, x25, 0
extrw 96, x25, 0
lui x26, 16384
addi x26, x26, 0
extrw 100, x26, 0
lui x27, 520
addi x27, x27, 256
extrw 104, x27, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x28, 496
addi x28, x28, 31
extrw 120, x28, 0
lui x18, 256
addi x18, x18, 16
extrw 124, x18, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x29, 524288
addi x29, x29, 0
extrw 140, x29, 0
ccr_decl x30
ccr_clr 2
ccr_set 3, 1
ai2d_compute
ss_pack_stride x5, x5, x31, ss3
ss_pack_stride x5, x5, x31, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x5, x5, x5, x31, ss4
ccr_decl x5
ccr_clr 3
lw x13, x0, 4
addi x15, x0, 768
add x15, x13, x15
l2_store x15, x16, ss4
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 256
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 42
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 3072
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 2048
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 32
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x19, 1
addi x19, x19, 0
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x24, x0, 1024
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 2
addi x25, x25, 0
add x25, x27, x25
lui x26, 65538
addi x26, x26, 0
l2_load x26, x25, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131073
addi x28, x28, 0
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# case: test_resize[InterpolationMode.NEAREST-size1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3072
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3088
addi x4, x0, 4
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 3092
addi x6, x0, 1
mmu_conf x5, x6, 3
lui x7, 1
addi x7, x7, 3093
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x2, ss0
ss_pack_stride x6, x6, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
lui x8, 2
addi x8, x8, 2048
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 32
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
addi x19, x0, 2
ss_pack_shape x19, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x19, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65548
addi x21, x21, 0
mfu_act1_compute x21, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 131072
addi x23, x23, 0
l2_load_w x23, x22, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
addi x25, x0, 64
ss_pack_stride x17, x25, x25, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x18, x19, x19, 0, l2
ss_pack_shape x19, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x19, x17, x25, x25, ss7
lui x26, 6
addi x26, x26, 0
mfu_act1_conf_dest x26, ss7
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x23
lui x28, 3
addi x28, x28, 0
ss_pack_stride x6, x6, x28, ss0
ss_pack_stride x6, x6, x28, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x26, ss1
ccr_decl x6
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x10, ss1
end x0
# case: test_resize[InterpolationMode.NEAREST-size2-in_shape0]
# tile: k230/ptq TileResize_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 192
mmu_conf x1, x2, 1
addi x3, x0, 208
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 1
lui x6, 1
addi x6, x6, 3072
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
lui x8, 65536
addi x8, x8, 0
extraw 0, x8, 0
lui x10, 65536
addi x10, x10, 1024
extraw 4, x10, 0
lui x11, 65537
addi x11, x11, 2048
extraw 8, x11, 0
lui x12, 65537
addi x12, x12, 3072
extraw 12, x12, 0
lui x13, 131072
addi x13, x13, 0
extraw 16, x13, 0
lui x14, 131072
addi x14, x14, 121
extraw 20, x14, 0
lui x15, 131072
addi x15, x15, 242
extraw 24, x15, 0
lui x16, 131072
addi x16, x16, 363
extraw 28, x16, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 176
addi x18, x18, 11
extrw 40, x18, 0
lui x18, 176
addi x18, x18, 11
extrw 44, x18, 0
lui x19, 283555
addi x19, x19, 3724
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x19, 283555
addi x19, x19, 3724
extrw 60, x19, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x20, 209152
addi x20, x20, 155
extrw 72, x20, 0
extrw 76, x0, 0
addi x21, x0, 256
extrw 80, x21, 0
lui x22, 3950
addi x22, x22, 292
extrw 84, x22, 0
lui x23, 3995
addi x23, x23, 256
extrw 88, x23, 0
lui x24, 126
addi x24, x24, 3947
extrw 92, x24, 0
lui x25, 3836
addi x25, x25, 0
extrw 96, x25, 0
lui x26, 16384
addi x26, x26, 0
extrw 100, x26, 0
lui x27, 520
addi x27, x27, 256
extrw 104, x27, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x28, 496
addi x28, x28, 31
extrw 120, x28, 0
lui x18, 176
addi x18, x18, 11
extrw 124, x18, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x29, 524288
addi x29, x29, 0
extrw 140, x29, 0
addi x30, x0, 2
ccr_decl x30
ccr_clr 0
ccr_set 1, 1
ai2d_compute
addi x31, x0, 363
ss_pack_stride x5, x5, x31, ss3
ss_pack_stride x5, x5, x31, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x5, x5, x5, x31, ss4
ccr_decl x5
ccr_clr 1
lw x2, x0, 4
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x13, ss4
ss_pack_stride x5, x5, x6, ss1
ss_pack_stride x5, x5, x6, ss5
l2_load_conf ss5, ss1, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 2, 1
lw x4, x0, 0
lui x3, 1
addi x3, x3, 3072
add x3, x4, x3
l2_load x12, x3, ss2
lui x12, 65537
addi x12, x12, 3072
extraw 0, x12, 0
lui x7, 65537
addi x7, x7, 0
extraw 4, x7, 0
lui x9, 65537
addi x9, x9, 1024
extraw 8, x9, 0
lui x8, 65538
addi x8, x8, 2048
extraw 12, x8, 0
lui x10, 131072
addi x10, x10, 384
extraw 16, x10, 0
lui x11, 131072
addi x11, x11, 505
extraw 20, x11, 0
lui x14, 131072
addi x14, x14, 626
extraw 24, x14, 0
lui x15, 131072
addi x15, x15, 747
extraw 28, x15, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 176
addi x18, x18, 11
extrw 40, x18, 0
lui x18, 176
addi x18, x18, 11
extrw 44, x18, 0
lui x19, 283555
addi x19, x19, 3724
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x19, 283555
addi x19, x19, 3724
extrw 60, x19, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x20, 209152
addi x20, x20, 155
extrw 72, x20, 0
extrw 76, x0, 0
addi x21, x0, 256
extrw 80, x21, 0
lui x22, 3950
addi x22, x22, 292
extrw 84, x22, 0
lui x23, 3995
addi x23, x23, 256
extrw 88, x23, 0
lui x24, 126
addi x24, x24, 3947
extrw 92, x24, 0
lui x25, 3836
addi x25, x25, 0
extrw 96, x25, 0
lui x26, 16384
addi x26, x26, 0
extrw 100, x26, 0
lui x27, 520
addi x27, x27, 256
extrw 104, x27, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x28, 496
addi x28, x28, 31
extrw 120, x28, 0
lui x18, 176
addi x18, x18, 11
extrw 124, x18, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x29, 524288
addi x29, x29, 0
extrw 140, x29, 0
ccr_decl x30
ccr_clr 2
ccr_set 3, 1
ai2d_compute
ss_pack_stride x5, x5, x31, ss3
ss_pack_stride x5, x5, x31, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x5, x5, x5, x31, ss4
ccr_decl x5
ccr_clr 3
lw x13, x0, 4
addi x16, x0, 363
add x16, x13, x16
l2_store x16, x10, ss4
end x0
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 61
mmu_conf x1, x2, 1
addi x3, x0, 77
addi x4, x0, 31
mmu_conf x3, x4, 2
addi x5, x0, 108
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 363
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 242
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 11
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
addi x19, x0, 484
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 2
addi x20, x20, 3076
mfu_act1_conf_deq x20, x0, u8, 0
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 65536
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x25, x0, 121
ss_pack_shape x6, x12, x12, x25, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
addi x26, x0, 242
add x26, x28, x26
lui x27, 131072
addi x27, x27, 484
l2_load x27, x26, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 65536
addi x29, x29, 968
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x27, x0, x30
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x6, x12, x12, x25, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 968
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 256
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 42
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 3072
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 2048
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 32
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x19, 1
addi x19, x19, 0
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x24, x0, 1024
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 2
addi x25, x25, 0
add x25, x27, x25
lui x26, 65538
addi x26, x26, 0
l2_load x26, x25, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131073
addi x28, x28, 0
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# case: test_resize[InterpolationMode.NEAREST-size3-in_shape0]
# tile: k230/ptq TileResize_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 258
mmu_conf x1, x2, 1
addi x3, x0, 274
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 1
lui x6, 1
addi x6, x6, 3072
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 2
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
lui x8, 131072
addi x8, x8, 0
extraw 0, x8, 0
lui x10, 131072
addi x10, x10, 1024
extraw 4, x10, 0
lui x11, 131073
addi x11, x11, 2048
extraw 8, x11, 0
lui x12, 131073
addi x12, x12, 3072
extraw 12, x12, 0
lui x13, 65536
addi x13, x13, 0
extraw 16, x13, 0
lui x14, 65536
addi x14, x14, 1369
extraw 20, x14, 0
lui x15, 65537
addi x15, x15, 2738
extraw 24, x15, 0
lui x16, 65537
addi x16, x16, 11
extraw 28, x16, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 592
addi x18, x18, 37
extrw 40, x18, 0
lui x18, 592
addi x18, x18, 37
extrw 44, x18, 0
lui x19, 280022
addi x19, x19, 1993
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x19, 280022
addi x19, x19, 1993
extrw 60, x19, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x20, 209152
addi x20, x20, 155
extrw 72, x20, 0
extrw 76, x0, 0
addi x21, x0, 256
extrw 80, x21, 0
lui x22, 3950
addi x22, x22, 292
extrw 84, x22, 0
lui x23, 3995
addi x23, x23, 256
extrw 88, x23, 0
lui x24, 126
addi x24, x24, 3947
extrw 92, x24, 0
lui x25, 3836
addi x25, x25, 0
extrw 96, x25, 0
lui x26, 16384
addi x26, x26, 0
extrw 100, x26, 0
lui x27, 520
addi x27, x27, 256
extrw 104, x27, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x17, 512
addi x17, x17, 32
extrw 120, x17, 0
lui x28, 262720
addi x28, x28, 36
extrw 124, x28, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x29, 524288
addi x29, x29, 0
extrw 140, x29, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x30, 512
addi x30, x30, 1
extrw 120, x30, 0
lui x31, 262720
addi x31, x31, 1
extrw 124, x31, 0
lui x1, 274598
addi x1, x1, 256
extrw 128, x1, 0
extrw 132, x0, 0
addi x2, x0, 31
extrw 136, x2, 0
lui x3, 524288
addi x3, x3, 36
extrw 140, x3, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x4, 16
addi x4, x4, 32
extrw 120, x4, 0
lui x6, 262160
addi x6, x6, 36
extrw 124, x6, 0
extrw 128, x0, 0
lui x1, 274598
addi x1, x1, 256
extrw 132, x1, 0
lui x7, 496
addi x7, x7, 0
extrw 136, x7, 0
lui x9, 524864
addi x9, x9, 0
extrw 140, x9, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x5, 16
addi x5, x5, 1
extrw 120, x5, 0
lui x5, 16
addi x5, x5, 1
extrw 124, x5, 0
lui x1, 274598
addi x1, x1, 256
extrw 128, x1, 0
lui x1, 274598
addi x1, x1, 256
extrw 132, x1, 0
lui x8, 496
addi x8, x8, 31
extrw 136, x8, 0
lui x10, 524864
addi x10, x10, 36
extrw 140, x10, 0
addi x11, x0, 3
ccr_decl x11
ccr_clr 0
ccr_clr 0
ccr_set 1, 1
ai2d_compute
addi x12, x0, 1
lui x13, 1
addi x13, x13, 11
ss_pack_stride x12, x12, x13, ss3
ss_pack_stride x12, x12, x13, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x12, x12, x12, x13, ss4
ccr_decl x12
ccr_clr 1
lw x16, x0, 4
lui x15, 0
addi x15, x15, 0
add x15, x16, x15
lui x14, 65536
addi x14, x14, 0
l2_store x15, x14, ss4
lui x18, 1
addi x18, x18, 3072
ss_pack_stride x12, x12, x18, ss1
ss_pack_stride x12, x12, x18, ss5
l2_load_conf ss5, ss1, i8, i8
ss_pack_shape x12, x12, x12, x18, ss2
ccr_decl x12
ccr_set 2, 2
lw x21, x0, 0
lui x19, 1
addi x19, x19, 3072
add x19, x21, x19
lui x20, 131073
addi x20, x20, 3072
l2_load x20, x19, ss2
lui x20, 131073
addi x20, x20, 3072
extraw 0, x20, 0
lui x22, 131073
addi x22, x22, 0
extraw 4, x22, 0
lui x23, 131073
addi x23, x23, 1024
extraw 8, x23, 0
lui x24, 131074
addi x24, x24, 2048
extraw 12, x24, 0
lui x25, 65537
addi x25, x25, 32
extraw 16, x25, 0
lui x26, 65537
addi x26, x26, 1401
extraw 20, x26, 0
lui x27, 65538
addi x27, x27, 2770
extraw 24, x27, 0
lui x17, 65538
addi x17, x17, 43
extraw 28, x17, 0
lui x28, 512
addi x28, x28, 32
extrw 32, x28, 0
lui x28, 512
addi x28, x28, 32
extrw 36, x28, 0
lui x29, 592
addi x29, x29, 37
extrw 40, x29, 0
lui x29, 592
addi x29, x29, 37
extrw 44, x29, 0
lui x30, 280022
addi x30, x30, 1993
extrw 48, x30, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x30, 280022
addi x30, x30, 1993
extrw 60, x30, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x31, 209152
addi x31, x31, 155
extrw 72, x31, 0
extrw 76, x0, 0
addi x2, x0, 256
extrw 80, x2, 0
lui x3, 3950
addi x3, x3, 292
extrw 84, x3, 0
lui x4, 3995
addi x4, x4, 256
extrw 88, x4, 0
lui x6, 126
addi x6, x6, 3947
extrw 92, x6, 0
lui x7, 3836
addi x7, x7, 0
extrw 96, x7, 0
lui x9, 16384
addi x9, x9, 0
extrw 100, x9, 0
lui x5, 520
addi x5, x5, 256
extrw 104, x5, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x28, 512
addi x28, x28, 32
extrw 120, x28, 0
lui x1, 262720
addi x1, x1, 36
extrw 124, x1, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x8, 524288
addi x8, x8, 0
extrw 140, x8, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x10, 512
addi x10, x10, 1
extrw 120, x10, 0
lui x11, 262720
addi x11, x11, 1
extrw 124, x11, 0
lui x13, 274598
addi x13, x13, 256
extrw 128, x13, 0
extrw 132, x0, 0
addi x14, x0, 31
extrw 136, x14, 0
lui x15, 524288
addi x15, x15, 36
extrw 140, x15, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x16, 16
addi x16, x16, 32
extrw 120, x16, 0
lui x18, 262160
addi x18, x18, 36
extrw 124, x18, 0
extrw 128, x0, 0
lui x13, 274598
addi x13, x13, 256
extrw 132, x13, 0
lui x19, 496
addi x19, x19, 0
extrw 136, x19, 0
lui x21, 524864
addi x21, x21, 0
extrw 140, x21, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x12, 16
addi x12, x12, 1
extrw 120, x12, 0
lui x12, 16
addi x12, x12, 1
extrw 124, x12, 0
lui x13, 274598
addi x13, x13, 256
extrw 128, x13, 0
lui x13, 274598
addi x13, x13, 256
extrw 132, x13, 0
lui x20, 496
addi x20, x20, 31
extrw 136, x20, 0
lui x22, 524864
addi x22, x22, 36
extrw 140, x22, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 2
ccr_clr 2
ccr_set 3, 1
ai2d_compute
addi x24, x0, 1
lui x25, 1
addi x25, x25, 11
ss_pack_stride x24, x24, x25, ss3
ss_pack_stride x24, x24, x25, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x24, x24, x24, x25, ss4
ccr_decl x24
ccr_clr 3
lw x17, x0, 4
lui x27, 1
addi x27, x27, 11
add x27, x17, x27
lui x26, 65537
addi x26, x26, 32
l2_store x27, x26, ss4
end x0
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 685
mmu_conf x1, x2, 1
addi x3, x0, 701
addi x4, x0, 343
mmu_conf x3, x4, 2
addi x5, x0, 1044
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 11
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 2738
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 37
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x19, 1
addi x19, x19, 1380
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 2
addi x20, x20, 3076
mfu_act1_conf_deq x20, x0, u8, 0
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 65536
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x25, x0, 1369
ss_pack_shape x6, x12, x12, x25, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
lui x26, 1
addi x26, x26, 2738
add x26, x28, x26
lui x27, 131073
addi x27, x27, 1380
l2_load x27, x26, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, u8, 0
mfu_act1_conf_deq x21, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 65539
addi x29, x29, 2760
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x27, x0, x30
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x6, x12, x12, x25, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
lui x31, 3
addi x31, x31, 2760
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 256
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 42
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 3072
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 2048
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 32
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x19, 1
addi x19, x19, 0
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x24, x0, 1024
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 2
addi x25, x25, 0
add x25, x27, x25
lui x26, 65538
addi x26, x26, 0
l2_load x26, x25, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131073
addi x28, x28, 0
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
# case: test_resize[InterpolationMode.NEAREST-size4-in_shape0]
# tile: k230/ptq TileResize_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 286
mmu_conf x1, x2, 1
addi x3, x0, 302
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 1
lui x6, 1
addi x6, x6, 3072
ss_pack_stride x5, x5, x6, ss0
ss_pack_stride x5, x5, x6, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x6, ss2
ccr_decl x5
ccr_set 0, 2
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 131072
addi x8, x8, 0
l2_load x8, x7, ss2
lui x8, 131072
addi x8, x8, 0
extraw 0, x8, 0
lui x10, 131072
addi x10, x10, 1024
extraw 4, x10, 0
lui x11, 131073
addi x11, x11, 2048
extraw 8, x11, 0
lui x12, 131073
addi x12, x12, 3072
extraw 12, x12, 0
lui x13, 65536
addi x13, x13, 0
extraw 16, x13, 0
lui x14, 65536
addi x14, x14, 1517
extraw 20, x14, 0
lui x15, 65537
addi x15, x15, 3034
extraw 24, x15, 0
lui x16, 65537
addi x16, x16, 455
extraw 28, x16, 0
lui x17, 512
addi x17, x17, 32
extrw 32, x17, 0
lui x17, 512
addi x17, x17, 32
extrw 36, x17, 0
lui x18, 656
addi x18, x18, 41
extrw 40, x18, 0
lui x18, 656
addi x18, x18, 41
extrw 44, x18, 0
lui x19, 279677
addi x19, x19, 3596
extrw 48, x19, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x20, 280022
addi x20, x20, 1993
extrw 60, x20, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x21, 209152
addi x21, x21, 155
extrw 72, x21, 0
extrw 76, x0, 0
addi x22, x0, 256
extrw 80, x22, 0
lui x23, 3950
addi x23, x23, 292
extrw 84, x23, 0
lui x24, 3995
addi x24, x24, 256
extrw 88, x24, 0
lui x25, 126
addi x25, x25, 3947
extrw 92, x25, 0
lui x26, 3836
addi x26, x26, 0
extrw 96, x26, 0
lui x27, 16384
addi x27, x27, 0
extrw 100, x27, 0
lui x28, 520
addi x28, x28, 256
extrw 104, x28, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x17, 512
addi x17, x17, 32
extrw 120, x17, 0
lui x29, 262720
addi x29, x29, 40
extrw 124, x29, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x30, 524288
addi x30, x30, 0
extrw 140, x30, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x31, 512
addi x31, x31, 1
extrw 120, x31, 0
lui x1, 262720
addi x1, x1, 1
extrw 124, x1, 0
lui x2, 275980
addi x2, x2, 1920
extrw 128, x2, 0
extrw 132, x0, 0
addi x3, x0, 31
extrw 136, x3, 0
lui x4, 524288
addi x4, x4, 40
extrw 140, x4, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x6, 16
addi x6, x6, 32
extrw 120, x6, 0
lui x7, 262160
addi x7, x7, 40
extrw 124, x7, 0
extrw 128, x0, 0
lui x9, 274598
addi x9, x9, 256
extrw 132, x9, 0
lui x5, 496
addi x5, x5, 0
extrw 136, x5, 0
lui x8, 524864
addi x8, x8, 0
extrw 140, x8, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x10, 16
addi x10, x10, 1
extrw 120, x10, 0
lui x10, 16
addi x10, x10, 1
extrw 124, x10, 0
lui x2, 275980
addi x2, x2, 1920
extrw 128, x2, 0
lui x9, 274598
addi x9, x9, 256
extrw 132, x9, 0
lui x11, 496
addi x11, x11, 31
extrw 136, x11, 0
lui x12, 524864
addi x12, x12, 40
extrw 140, x12, 0
addi x13, x0, 3
ccr_decl x13
ccr_clr 0
ccr_clr 0
ccr_set 1, 1
ai2d_compute
addi x14, x0, 1
lui x15, 1
addi x15, x15, 455
ss_pack_stride x14, x14, x15, ss3
ss_pack_stride x14, x14, x15, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x14, x14, x14, x15, ss4
ccr_decl x14
ccr_clr 1
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
lui x16, 65536
addi x16, x16, 0
l2_store x18, x16, ss4
lui x20, 1
addi x20, x20, 3072
ss_pack_stride x14, x14, x20, ss1
ss_pack_stride x14, x14, x20, ss5
l2_load_conf ss5, ss1, i8, i8
ss_pack_shape x14, x14, x14, x20, ss2
ccr_decl x14
ccr_set 2, 2
lw x23, x0, 0
lui x21, 1
addi x21, x21, 3072
add x21, x23, x21
lui x22, 131073
addi x22, x22, 3072
l2_load x22, x21, ss2
lui x22, 131073
addi x22, x22, 3072
extraw 0, x22, 0
lui x24, 131073
addi x24, x24, 0
extraw 4, x24, 0
lui x25, 131073
addi x25, x25, 1024
extraw 8, x25, 0
lui x26, 131074
addi x26, x26, 2048
extraw 12, x26, 0
lui x27, 65537
addi x27, x27, 480
extraw 16, x27, 0
lui x28, 65537
addi x28, x28, 1997
extraw 20, x28, 0
lui x17, 65538
addi x17, x17, 3514
extraw 24, x17, 0
lui x29, 65538
addi x29, x29, 935
extraw 28, x29, 0
lui x30, 512
addi x30, x30, 32
extrw 32, x30, 0
lui x30, 512
addi x30, x30, 32
extrw 36, x30, 0
lui x31, 656
addi x31, x31, 41
extrw 40, x31, 0
lui x31, 656
addi x31, x31, 41
extrw 44, x31, 0
lui x1, 279677
addi x1, x1, 3596
extrw 48, x1, 0
extrw 52, x0, 0
extrw 56, x0, 0
lui x3, 280022
addi x3, x3, 1993
extrw 60, x3, 0
extrw 64, x0, 0
extrw 68, x0, 0
lui x4, 209152
addi x4, x4, 155
extrw 72, x4, 0
extrw 76, x0, 0
addi x6, x0, 256
extrw 80, x6, 0
lui x7, 3950
addi x7, x7, 292
extrw 84, x7, 0
lui x5, 3995
addi x5, x5, 256
extrw 88, x5, 0
lui x8, 126
addi x8, x8, 3947
extrw 92, x8, 0
lui x10, 3836
addi x10, x10, 0
extrw 96, x10, 0
lui x2, 16384
addi x2, x2, 0
extrw 100, x2, 0
lui x9, 520
addi x9, x9, 256
extrw 104, x9, 0
extrw 108, x0, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x30, 512
addi x30, x30, 32
extrw 120, x30, 0
lui x11, 262720
addi x11, x11, 40
extrw 124, x11, 0
extrw 128, x0, 0
extrw 132, x0, 0
extrw 136, x0, 0
lui x12, 524288
addi x12, x12, 0
extrw 140, x12, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x13, 512
addi x13, x13, 1
extrw 120, x13, 0
lui x15, 262720
addi x15, x15, 1
extrw 124, x15, 0
lui x16, 275980
addi x16, x16, 1920
extrw 128, x16, 0
extrw 132, x0, 0
addi x18, x0, 31
extrw 136, x18, 0
lui x19, 524288
addi x19, x19, 40
extrw 140, x19, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x20, 16
addi x20, x20, 32
extrw 120, x20, 0
lui x21, 262160
addi x21, x21, 40
extrw 124, x21, 0
extrw 128, x0, 0
lui x23, 274598
addi x23, x23, 256
extrw 132, x23, 0
lui x14, 496
addi x14, x14, 0
extrw 136, x14, 0
lui x22, 524864
addi x22, x22, 0
extrw 140, x22, 0
extrw 112, x0, 0
extrw 116, x0, 0
lui x24, 16
addi x24, x24, 1
extrw 120, x24, 0
lui x24, 16
addi x24, x24, 1
extrw 124, x24, 0
lui x16, 275980
addi x16, x16, 1920
extrw 128, x16, 0
lui x23, 274598
addi x23, x23, 256
extrw 132, x23, 0
lui x25, 496
addi x25, x25, 31
extrw 136, x25, 0
lui x26, 524864
addi x26, x26, 40
extrw 140, x26, 0
addi x27, x0, 3
ccr_decl x27
ccr_clr 2
ccr_clr 2
ccr_set 3, 1
ai2d_compute
addi x28, x0, 1
lui x17, 1
addi x17, x17, 455
ss_pack_stride x28, x28, x17, ss3
ss_pack_stride x28, x28, x17, ss3
l2_store_conf ss3, ss3, i8, i8
ss_pack_shape x28, x28, x28, x17, ss4
ccr_decl x28
ccr_clr 3
lw x1, x0, 4
lui x31, 1
addi x31, x31, 455
add x31, x1, x31
lui x29, 65537
addi x29, x29, 480
l2_store x31, x29, ss4
end x0
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 759
mmu_conf x1, x2, 1
addi x3, x0, 775
addi x4, x0, 380
mmu_conf x3, x4, 2
addi x5, x0, 1155
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 455
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 3034
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 37
addi x19, x0, 41
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 1972
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 2
addi x21, x21, 3076
mfu_act1_conf_deq x21, x0, u8, 0
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x23, 65536
addi x23, x23, 0
mfu_act1_compute x23, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x23, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x26, x0, 1517
ss_pack_shape x6, x12, x12, x26, ss7
ccr_decl x12
ccr_set 2, 1
lw x29, x0, 0
lui x27, 1
addi x27, x27, 3034
add x27, x29, x27
lui x28, 131073
addi x28, x28, 1972
l2_load x28, x27, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x19, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x30, 65539
addi x30, x30, 3944
lui x31, 196608
addi x31, x31, 28
mfu_act1_compute x30, x28, x0, x31
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x6, x12, x12, x26, ss7
ccr_decl x12
ccr_clr 3
lw x2, x0, 4
lui x1, 3
addi x1, x1, 3944
add x1, x2, x1
l2_store x1, x30, ss7
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 256
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 42
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
lui x13, 1
addi x13, x13, 3072
ss_pack_stride x12, x12, x13, ss0
lui x14, 1
addi x14, x14, 2048
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 32
ss_pack_stride x6, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x19, 1
addi x19, x19, 0
mfu_act1_conf_src1 x19, x12, x12, 0, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x6, x18, x18, ss5
mfu_act1_conf_dest x19, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x21, 131072
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x6, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x24, x0, 1024
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
lui x25, 2
addi x25, x25, 0
add x25, x27, x25
lui x26, 65538
addi x26, x26, 0
l2_load x26, x25, ss7
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x6, x12, x18, x18, ss3
mfu_act1_conf_dest x14, ss3
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x28, 131073
addi x28, x28, 0
lui x29, 196608
addi x29, x29, 28
mfu_act1_compute x28, x26, x0, x29
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x6, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x31, x0, 4
lui x30, 1
addi x30, x30, 2048
add x30, x31, x30
l2_store x30, x28, ss7
end x0
