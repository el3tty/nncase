# case: test_squeeze[0-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 558
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 559
mmu_conf x7, x6, 4
addi x8, x0, 560
mmu_conf x8, x6, 5
lui x9, 1
addi x9, x9, 224
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 28
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
addi x19, x0, 30
addi x20, x0, 36
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65538
addi x22, x22, 448
mfu_act1_compute x22, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x17
ss_pack_stride x18, x19, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x13, x20, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 196608
addi x1, x1, 0
l2_load_w x1, x31, x23
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss7
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x13, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x13, x20, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x6
ccr_clr 4
addi x7, x0, 14
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_stride x6, x19, x20, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x13, x20, ss2
dm_store_of 0, 0, x11, ss2, pu
ss_pack_shape x6, x6, x13, x20, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x13, x20, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x13, x20, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x18, x4, x20, ss3
ccr_decl x6
ccr_clr 2
lui x8, 65538
addi x8, x8, 1456
dm_load_l1 0, 0, x8, x0, ss3, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x4, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x6, x18, x4, x20, ss3
pu_fetchif_conf3 0, 0, x0, x6, ss3
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_shape x6, x6, x4, x20, ss6
ccr_decl x6
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 2016
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x6, x6, x4, x20, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x20, ss4
pu_of_conf1 0, 0, x6, x0, ss4
ss_pack_shape x6, x6, x4, x20, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x12, x0, 1080
ss_pack_stride x6, x6, x12, ss1
ss_pack_stride x6, x6, x12, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss5
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
l2_store x14, x11, ss5
end x0
# case: test_squeeze[0-1-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 234
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 235
mmu_conf x7, x6, 4
addi x8, x0, 236
mmu_conf x8, x6, 5
addi x9, x0, 1728
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_dest x9, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x0
addi x25, x0, 7
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x19, x19, ss5
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 57
add x29, x31, x29
lui x30, 196608
addi x30, x30, 0
l2_load_w x30, x29, x4
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x6, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x6
ccr_clr 4
addi x2, x0, 14
dm_load_act0 0, 0, x27, x2, pu, 1
ss_pack_stride x6, x19, x19, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x6, x6, x19, x19, ss1
ccr_decl x6
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x6, x6, x19, x19, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x19, x19, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x6, x6, x19, x19, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x3, x0, 576
ss_pack_stride x6, x6, x3, ss2
ss_pack_stride x6, x6, x3, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x3, ss3
ccr_decl x6
ccr_clr 0
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
l2_store x5, x11, ss3
end x0
# case: test_squeeze[0-1-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 559
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 561
mmu_conf x7, x6, 4
addi x8, x0, 563
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 12
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x4
addi x5, x0, 24
dm_load_w_conf 0, 0, 1, 1, x5
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x9
ccr_clr 4
addi x8, x0, 42
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_stride x4, x20, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x9, x4, x14, x21, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x4, x14, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x14, x21, ss5
pu_of_conf1 0, 0, x4, x0, ss5
ss_pack_shape x9, x4, x14, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x6, x21, ss3
ccr_decl x9
ccr_clr 2
lui x11, 65538
addi x11, x11, 1456
dm_load_l1 0, 0, x11, x0, ss3, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x6, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x6, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_shape x9, x4, x6, x21, ss6
ccr_decl x9
ccr_set 0, 1
lui x13, 65536
addi x13, x13, 2016
dm_store_of 0, 0, x13, ss6, pu
ss_pack_shape x9, x4, x6, x21, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x6, x21, ss4
pu_of_conf1 0, 0, x4, x0, ss4
ss_pack_shape x9, x4, x6, x21, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x15, 1
addi x15, x15, 3240
ss_pack_stride x9, x9, x15, ss1
ss_pack_stride x9, x9, x15, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss5
ccr_decl x9
ccr_clr 0
lw x10, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x10, x17
l2_store x17, x12, ss5
end x0
# case: test_squeeze[0-1-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 235
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 237
mmu_conf x7, x6, 4
addi x8, x0, 239
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 24
ss_pack_stride x4, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x4, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 9
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x4, x4, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x4, x0
ss_pack_shape x9, x4, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x2, x0, 42
dm_load_act0 0, 0, x26, x2, pu, 1
ss_pack_stride x4, x19, x19, ss3
dm_store_of_conf 0, 0, ss3, fp16
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss5, pu
ss_pack_shape x9, x4, x19, x19, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x19, x19, ss3
pu_of_conf1 0, 0, x4, x0, ss3
ss_pack_shape x9, x4, x19, x19, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x9, x9, x10, ss1
ss_pack_stride x9, x9, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
l2_store x3, x12, ss2
end x0
# case: test_squeeze[0-3-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 563
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 565
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 566
mmu_conf x9, x8, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x14, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x24
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x26, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 14
dm_load_act0 0, 0, x29, x9, pu, 1
addi x11, x0, 34
ss_pack_stride x8, x14, x11, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x13, x0, 26
ss_pack_shape x8, x8, x13, x11, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x8, x8, x13, x11, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x13, x11, ss5
pu_of_conf1 0, 0, x8, x0, ss5
ss_pack_shape x8, x8, x13, x11, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x19, x21, ss3
ccr_decl x8
ccr_clr 2
lui x15, 65538
addi x15, x15, 1384
dm_load_l1 0, 0, x15, x0, ss3, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x1, x26, ss7, pu
ss_pack_stride x5, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
dm_load_act0 0, 0, x29, x9, pu, 1
ss_pack_shape x8, x8, x6, x11, ss6
ccr_decl x8
ccr_set 0, 1
lui x17, 65536
addi x17, x17, 1768
dm_store_of 0, 0, x17, ss6, pu
ss_pack_shape x8, x8, x6, x11, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x6, x11, ss4
pu_of_conf1 0, 0, x8, x0, ss4
ss_pack_shape x8, x8, x6, x11, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x10, x0, 952
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss5
ccr_decl x8
ccr_clr 0
lw x16, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x16, x22
l2_store x22, x12, ss5
end x0
# case: test_squeeze[0-3-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 239
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 241
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 242
mmu_conf x9, x8, 5
addi x10, x0, 1728
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 24
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65537
addi x22, x22, 3456
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x19, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x20, x20, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss5, if_
addi x29, x0, 27
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x1, x0, 8
addi x30, x0, 57
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss6, pu
ss_pack_stride x20, x20, x20, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x20, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x8
ccr_clr 4
addi x5, x0, 14
dm_load_act0 0, 0, x27, x5, pu, 1
addi x7, x0, 22
ss_pack_stride x8, x7, x7, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x8, x7, x7, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x8, x7, x7, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x7, x7, ss0
pu_of_conf1 0, 0, x8, x0, ss0
ss_pack_shape x8, x8, x7, x7, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 484
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_squeeze[0-3-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 577
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 579
mmu_conf x7, x6, 4
addi x8, x0, 581
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 108
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x24
addi x5, x0, 216
dm_load_w_conf 0, 0, 3, 3, x5
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x26, ss7, pu
addi x7, x0, 24
ss_pack_stride x7, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
ccr_decl x9
ccr_clr 4
addi x11, x0, 42
dm_load_act0 0, 0, x29, x11, pu, 1
addi x13, x0, 34
ss_pack_stride x24, x14, x13, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x15, x0, 26
ss_pack_shape x9, x24, x15, x13, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x24, x15, x13, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x15, x13, ss5
pu_of_conf1 0, 0, x24, x0, ss5
ss_pack_shape x9, x24, x15, x13, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x19, x21, ss3
ccr_decl x9
ccr_clr 2
lui x17, 65538
addi x17, x17, 1384
dm_load_l1 0, 0, x17, x0, ss3, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x2, x26, ss7, pu
ss_pack_stride x7, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x24, x6, x13, ss6
ccr_decl x9
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 1768
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x9, x24, x6, x13, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x6, x13, ss4
pu_of_conf1 0, 0, x24, x0, ss4
ss_pack_shape x9, x24, x6, x13, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x22, 1
addi x22, x22, 2856
ss_pack_stride x9, x9, x22, ss1
ss_pack_stride x9, x9, x22, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x22, ss5
ccr_decl x9
ccr_clr 0
lw x25, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x25, x16
l2_store x16, x12, ss5
end x0
# case: test_squeeze[0-3-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 253
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 255
mmu_conf x7, x6, 4
addi x8, x0, 257
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x3, x0, 42
dm_load_act0 0, 0, x26, x3, pu, 1
addi x5, x0, 22
ss_pack_stride x18, x5, x5, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x9, x18, x5, x5, ss1
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x9, x18, x5, x5, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x5, x5, ss0
pu_of_conf1 0, 0, x18, x0, ss0
ss_pack_shape x9, x18, x5, x5, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x7, x0, 1452
ss_pack_stride x9, x9, x7, ss2
ss_pack_stride x9, x9, x7, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x9, x9, x9, x7, ss3
ccr_decl x9
ccr_clr 0
lw x11, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x11, x8
l2_store x8, x12, ss3
end x0
# case: test_squeeze[1-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 558
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 559
mmu_conf x7, x6, 4
addi x8, x0, 560
mmu_conf x8, x6, 5
lui x9, 1
addi x9, x9, 224
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 28
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
addi x19, x0, 30
addi x20, x0, 36
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65538
addi x22, x22, 448
mfu_act1_compute x22, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x17
ss_pack_stride x18, x19, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x13, x20, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 196608
addi x1, x1, 0
l2_load_w x1, x31, x23
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss7
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x13, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x13, x20, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x6
ccr_clr 4
addi x7, x0, 14
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_stride x6, x19, x20, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x13, x20, ss2
dm_store_of 0, 0, x11, ss2, pu
ss_pack_shape x6, x6, x13, x20, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x13, x20, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x13, x20, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x18, x4, x20, ss3
ccr_decl x6
ccr_clr 2
lui x8, 65538
addi x8, x8, 1456
dm_load_l1 0, 0, x8, x0, ss3, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x4, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x6, x18, x4, x20, ss3
pu_fetchif_conf3 0, 0, x0, x6, ss3
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_shape x6, x6, x4, x20, ss6
ccr_decl x6
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 2016
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x6, x6, x4, x20, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x20, ss4
pu_of_conf1 0, 0, x6, x0, ss4
ss_pack_shape x6, x6, x4, x20, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x12, x0, 1080
ss_pack_stride x6, x6, x12, ss1
ss_pack_stride x6, x6, x12, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss5
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
l2_store x14, x11, ss5
end x0
# case: test_squeeze[1-1-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 234
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 235
mmu_conf x7, x6, 4
addi x8, x0, 236
mmu_conf x8, x6, 5
addi x9, x0, 1728
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_dest x9, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x0
addi x25, x0, 7
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x19, x19, ss5
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 57
add x29, x31, x29
lui x30, 196608
addi x30, x30, 0
l2_load_w x30, x29, x4
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x6, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x6
ccr_clr 4
addi x2, x0, 14
dm_load_act0 0, 0, x27, x2, pu, 1
ss_pack_stride x6, x19, x19, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x6, x6, x19, x19, ss1
ccr_decl x6
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x6, x6, x19, x19, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x19, x19, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x6, x6, x19, x19, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x3, x0, 576
ss_pack_stride x6, x6, x3, ss2
ss_pack_stride x6, x6, x3, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x3, ss3
ccr_decl x6
ccr_clr 0
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
l2_store x5, x11, ss3
end x0
# case: test_squeeze[1-1-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 559
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 561
mmu_conf x7, x6, 4
addi x8, x0, 563
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 12
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x4
addi x5, x0, 24
dm_load_w_conf 0, 0, 1, 1, x5
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x9
ccr_clr 4
addi x8, x0, 42
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_stride x4, x20, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x9, x4, x14, x21, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x4, x14, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x14, x21, ss5
pu_of_conf1 0, 0, x4, x0, ss5
ss_pack_shape x9, x4, x14, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x6, x21, ss3
ccr_decl x9
ccr_clr 2
lui x11, 65538
addi x11, x11, 1456
dm_load_l1 0, 0, x11, x0, ss3, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x6, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x6, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_shape x9, x4, x6, x21, ss6
ccr_decl x9
ccr_set 0, 1
lui x13, 65536
addi x13, x13, 2016
dm_store_of 0, 0, x13, ss6, pu
ss_pack_shape x9, x4, x6, x21, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x6, x21, ss4
pu_of_conf1 0, 0, x4, x0, ss4
ss_pack_shape x9, x4, x6, x21, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x15, 1
addi x15, x15, 3240
ss_pack_stride x9, x9, x15, ss1
ss_pack_stride x9, x9, x15, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss5
ccr_decl x9
ccr_clr 0
lw x10, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x10, x17
l2_store x17, x12, ss5
end x0
# case: test_squeeze[1-1-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 235
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 237
mmu_conf x7, x6, 4
addi x8, x0, 239
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 24
ss_pack_stride x4, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x4, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 9
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x4, x4, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x4, x0
ss_pack_shape x9, x4, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x2, x0, 42
dm_load_act0 0, 0, x26, x2, pu, 1
ss_pack_stride x4, x19, x19, ss3
dm_store_of_conf 0, 0, ss3, fp16
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss5, pu
ss_pack_shape x9, x4, x19, x19, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x19, x19, ss3
pu_of_conf1 0, 0, x4, x0, ss3
ss_pack_shape x9, x4, x19, x19, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x9, x9, x10, ss1
ss_pack_stride x9, x9, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
l2_store x3, x12, ss2
end x0
# case: test_squeeze[1-3-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 563
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 565
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 566
mmu_conf x9, x8, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x14, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x24
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x26, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 14
dm_load_act0 0, 0, x29, x9, pu, 1
addi x11, x0, 34
ss_pack_stride x8, x14, x11, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x13, x0, 26
ss_pack_shape x8, x8, x13, x11, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x8, x8, x13, x11, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x13, x11, ss5
pu_of_conf1 0, 0, x8, x0, ss5
ss_pack_shape x8, x8, x13, x11, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x19, x21, ss3
ccr_decl x8
ccr_clr 2
lui x15, 65538
addi x15, x15, 1384
dm_load_l1 0, 0, x15, x0, ss3, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x1, x26, ss7, pu
ss_pack_stride x5, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
dm_load_act0 0, 0, x29, x9, pu, 1
ss_pack_shape x8, x8, x6, x11, ss6
ccr_decl x8
ccr_set 0, 1
lui x17, 65536
addi x17, x17, 1768
dm_store_of 0, 0, x17, ss6, pu
ss_pack_shape x8, x8, x6, x11, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x6, x11, ss4
pu_of_conf1 0, 0, x8, x0, ss4
ss_pack_shape x8, x8, x6, x11, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x10, x0, 952
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss5
ccr_decl x8
ccr_clr 0
lw x16, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x16, x22
l2_store x22, x12, ss5
end x0
# case: test_squeeze[1-3-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 239
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 241
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 242
mmu_conf x9, x8, 5
addi x10, x0, 1728
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 24
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65537
addi x22, x22, 3456
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x19, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x20, x20, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss5, if_
addi x29, x0, 27
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x1, x0, 8
addi x30, x0, 57
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss6, pu
ss_pack_stride x20, x20, x20, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x20, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x8
ccr_clr 4
addi x5, x0, 14
dm_load_act0 0, 0, x27, x5, pu, 1
addi x7, x0, 22
ss_pack_stride x8, x7, x7, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x8, x7, x7, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x8, x7, x7, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x7, x7, ss0
pu_of_conf1 0, 0, x8, x0, ss0
ss_pack_shape x8, x8, x7, x7, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 484
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_squeeze[1-3-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 577
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 579
mmu_conf x7, x6, 4
addi x8, x0, 581
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 108
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x24
addi x5, x0, 216
dm_load_w_conf 0, 0, 3, 3, x5
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x26, ss7, pu
addi x7, x0, 24
ss_pack_stride x7, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
ccr_decl x9
ccr_clr 4
addi x11, x0, 42
dm_load_act0 0, 0, x29, x11, pu, 1
addi x13, x0, 34
ss_pack_stride x24, x14, x13, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x15, x0, 26
ss_pack_shape x9, x24, x15, x13, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x24, x15, x13, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x15, x13, ss5
pu_of_conf1 0, 0, x24, x0, ss5
ss_pack_shape x9, x24, x15, x13, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x19, x21, ss3
ccr_decl x9
ccr_clr 2
lui x17, 65538
addi x17, x17, 1384
dm_load_l1 0, 0, x17, x0, ss3, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x2, x26, ss7, pu
ss_pack_stride x7, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x24, x6, x13, ss6
ccr_decl x9
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 1768
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x9, x24, x6, x13, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x6, x13, ss4
pu_of_conf1 0, 0, x24, x0, ss4
ss_pack_shape x9, x24, x6, x13, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x22, 1
addi x22, x22, 2856
ss_pack_stride x9, x9, x22, ss1
ss_pack_stride x9, x9, x22, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x22, ss5
ccr_decl x9
ccr_clr 0
lw x25, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x25, x16
l2_store x16, x12, ss5
end x0
# case: test_squeeze[1-3-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 253
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 255
mmu_conf x7, x6, 4
addi x8, x0, 257
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x3, x0, 42
dm_load_act0 0, 0, x26, x3, pu, 1
addi x5, x0, 22
ss_pack_stride x18, x5, x5, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x9, x18, x5, x5, ss1
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x9, x18, x5, x5, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x5, x5, ss0
pu_of_conf1 0, 0, x18, x0, ss0
ss_pack_shape x9, x18, x5, x5, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x7, x0, 1452
ss_pack_stride x9, x9, x7, ss2
ss_pack_stride x9, x9, x7, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x9, x9, x9, x7, ss3
ccr_decl x9
ccr_clr 0
lw x11, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x11, x8
l2_store x8, x12, ss3
end x0
# case: test_squeeze[2-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 558
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 559
mmu_conf x7, x6, 4
addi x8, x0, 560
mmu_conf x8, x6, 5
lui x9, 1
addi x9, x9, 224
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 28
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
addi x19, x0, 30
addi x20, x0, 36
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65538
addi x22, x22, 448
mfu_act1_compute x22, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x17
ss_pack_stride x18, x19, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x13, x20, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 196608
addi x1, x1, 0
l2_load_w x1, x31, x23
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss7
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x13, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x13, x20, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x6
ccr_clr 4
addi x7, x0, 14
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_stride x6, x19, x20, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x13, x20, ss2
dm_store_of 0, 0, x11, ss2, pu
ss_pack_shape x6, x6, x13, x20, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x13, x20, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x13, x20, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x18, x4, x20, ss3
ccr_decl x6
ccr_clr 2
lui x8, 65538
addi x8, x8, 1456
dm_load_l1 0, 0, x8, x0, ss3, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x4, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x6, x18, x4, x20, ss3
pu_fetchif_conf3 0, 0, x0, x6, ss3
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_shape x6, x6, x4, x20, ss6
ccr_decl x6
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 2016
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x6, x6, x4, x20, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x20, ss4
pu_of_conf1 0, 0, x6, x0, ss4
ss_pack_shape x6, x6, x4, x20, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x12, x0, 1080
ss_pack_stride x6, x6, x12, ss1
ss_pack_stride x6, x6, x12, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss5
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
l2_store x14, x11, ss5
end x0
# case: test_squeeze[2-1-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 234
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 235
mmu_conf x7, x6, 4
addi x8, x0, 236
mmu_conf x8, x6, 5
addi x9, x0, 1728
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_dest x9, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x0
addi x25, x0, 7
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x19, x19, ss5
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 57
add x29, x31, x29
lui x30, 196608
addi x30, x30, 0
l2_load_w x30, x29, x4
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x6, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x6
ccr_clr 4
addi x2, x0, 14
dm_load_act0 0, 0, x27, x2, pu, 1
ss_pack_stride x6, x19, x19, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x6, x6, x19, x19, ss1
ccr_decl x6
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x6, x6, x19, x19, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x19, x19, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x6, x6, x19, x19, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x3, x0, 576
ss_pack_stride x6, x6, x3, ss2
ss_pack_stride x6, x6, x3, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x3, ss3
ccr_decl x6
ccr_clr 0
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
l2_store x5, x11, ss3
end x0
# case: test_squeeze[2-1-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 559
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 561
mmu_conf x7, x6, 4
addi x8, x0, 563
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 12
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x4
addi x5, x0, 24
dm_load_w_conf 0, 0, 1, 1, x5
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x9
ccr_clr 4
addi x8, x0, 42
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_stride x4, x20, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x9, x4, x14, x21, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x4, x14, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x14, x21, ss5
pu_of_conf1 0, 0, x4, x0, ss5
ss_pack_shape x9, x4, x14, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x6, x21, ss3
ccr_decl x9
ccr_clr 2
lui x11, 65538
addi x11, x11, 1456
dm_load_l1 0, 0, x11, x0, ss3, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x6, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x6, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_shape x9, x4, x6, x21, ss6
ccr_decl x9
ccr_set 0, 1
lui x13, 65536
addi x13, x13, 2016
dm_store_of 0, 0, x13, ss6, pu
ss_pack_shape x9, x4, x6, x21, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x6, x21, ss4
pu_of_conf1 0, 0, x4, x0, ss4
ss_pack_shape x9, x4, x6, x21, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x15, 1
addi x15, x15, 3240
ss_pack_stride x9, x9, x15, ss1
ss_pack_stride x9, x9, x15, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss5
ccr_decl x9
ccr_clr 0
lw x10, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x10, x17
l2_store x17, x12, ss5
end x0
# case: test_squeeze[2-1-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 235
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 237
mmu_conf x7, x6, 4
addi x8, x0, 239
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 24
ss_pack_stride x4, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x4, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 9
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x4, x4, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x4, x0
ss_pack_shape x9, x4, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x2, x0, 42
dm_load_act0 0, 0, x26, x2, pu, 1
ss_pack_stride x4, x19, x19, ss3
dm_store_of_conf 0, 0, ss3, fp16
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss5, pu
ss_pack_shape x9, x4, x19, x19, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x19, x19, ss3
pu_of_conf1 0, 0, x4, x0, ss3
ss_pack_shape x9, x4, x19, x19, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x9, x9, x10, ss1
ss_pack_stride x9, x9, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
l2_store x3, x12, ss2
end x0
# case: test_squeeze[2-3-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 563
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 565
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 566
mmu_conf x9, x8, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x14, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x24
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x26, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 14
dm_load_act0 0, 0, x29, x9, pu, 1
addi x11, x0, 34
ss_pack_stride x8, x14, x11, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x13, x0, 26
ss_pack_shape x8, x8, x13, x11, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x8, x8, x13, x11, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x13, x11, ss5
pu_of_conf1 0, 0, x8, x0, ss5
ss_pack_shape x8, x8, x13, x11, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x19, x21, ss3
ccr_decl x8
ccr_clr 2
lui x15, 65538
addi x15, x15, 1384
dm_load_l1 0, 0, x15, x0, ss3, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x1, x26, ss7, pu
ss_pack_stride x5, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
dm_load_act0 0, 0, x29, x9, pu, 1
ss_pack_shape x8, x8, x6, x11, ss6
ccr_decl x8
ccr_set 0, 1
lui x17, 65536
addi x17, x17, 1768
dm_store_of 0, 0, x17, ss6, pu
ss_pack_shape x8, x8, x6, x11, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x6, x11, ss4
pu_of_conf1 0, 0, x8, x0, ss4
ss_pack_shape x8, x8, x6, x11, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x10, x0, 952
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss5
ccr_decl x8
ccr_clr 0
lw x16, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x16, x22
l2_store x22, x12, ss5
end x0
# case: test_squeeze[2-3-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 239
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 241
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 242
mmu_conf x9, x8, 5
addi x10, x0, 1728
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 24
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65537
addi x22, x22, 3456
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x19, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x20, x20, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss5, if_
addi x29, x0, 27
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x1, x0, 8
addi x30, x0, 57
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss6, pu
ss_pack_stride x20, x20, x20, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x20, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x8
ccr_clr 4
addi x5, x0, 14
dm_load_act0 0, 0, x27, x5, pu, 1
addi x7, x0, 22
ss_pack_stride x8, x7, x7, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x8, x7, x7, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x8, x7, x7, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x7, x7, ss0
pu_of_conf1 0, 0, x8, x0, ss0
ss_pack_shape x8, x8, x7, x7, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 484
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_squeeze[2-3-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 577
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 579
mmu_conf x7, x6, 4
addi x8, x0, 581
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 108
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x24
addi x5, x0, 216
dm_load_w_conf 0, 0, 3, 3, x5
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x26, ss7, pu
addi x7, x0, 24
ss_pack_stride x7, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
ccr_decl x9
ccr_clr 4
addi x11, x0, 42
dm_load_act0 0, 0, x29, x11, pu, 1
addi x13, x0, 34
ss_pack_stride x24, x14, x13, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x15, x0, 26
ss_pack_shape x9, x24, x15, x13, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x24, x15, x13, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x15, x13, ss5
pu_of_conf1 0, 0, x24, x0, ss5
ss_pack_shape x9, x24, x15, x13, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x19, x21, ss3
ccr_decl x9
ccr_clr 2
lui x17, 65538
addi x17, x17, 1384
dm_load_l1 0, 0, x17, x0, ss3, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x2, x26, ss7, pu
ss_pack_stride x7, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x24, x6, x13, ss6
ccr_decl x9
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 1768
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x9, x24, x6, x13, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x6, x13, ss4
pu_of_conf1 0, 0, x24, x0, ss4
ss_pack_shape x9, x24, x6, x13, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x22, 1
addi x22, x22, 2856
ss_pack_stride x9, x9, x22, ss1
ss_pack_stride x9, x9, x22, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x22, ss5
ccr_decl x9
ccr_clr 0
lw x25, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x25, x16
l2_store x16, x12, ss5
end x0
# case: test_squeeze[2-3-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 253
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 255
mmu_conf x7, x6, 4
addi x8, x0, 257
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x3, x0, 42
dm_load_act0 0, 0, x26, x3, pu, 1
addi x5, x0, 22
ss_pack_stride x18, x5, x5, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x9, x18, x5, x5, ss1
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x9, x18, x5, x5, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x5, x5, ss0
pu_of_conf1 0, 0, x18, x0, ss0
ss_pack_shape x9, x18, x5, x5, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x7, x0, 1452
ss_pack_stride x9, x9, x7, ss2
ss_pack_stride x9, x9, x7, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x9, x9, x9, x7, ss3
ccr_decl x9
ccr_clr 0
lw x11, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x11, x8
l2_store x8, x12, ss3
end x0
# case: test_squeeze[3-1-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 558
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 559
mmu_conf x7, x6, 4
addi x8, x0, 560
mmu_conf x8, x6, 5
lui x9, 1
addi x9, x9, 224
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 28
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
addi x19, x0, 30
addi x20, x0, 36
ss_pack_stride x18, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x20, ss5
mfu_act1_conf_dest x9, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x23, x0, 3
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x22, 65538
addi x22, x22, 448
mfu_act1_compute x22, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x0
addi x27, x0, 7
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x17
ss_pack_stride x18, x19, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x13, x20, ss6
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss6, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 196608
addi x1, x1, 0
l2_load_w x1, x31, x23
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss7
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x13, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x13, x20, ss6
pu_fetchif_conf3 0, 0, x0, x6, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
ccr_decl x6
ccr_clr 4
addi x7, x0, 14
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_stride x6, x19, x20, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x6, x6, x13, x20, ss2
dm_store_of 0, 0, x11, ss2, pu
ss_pack_shape x6, x6, x13, x20, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x13, x20, ss5
pu_of_conf1 0, 0, x6, x0, ss5
ss_pack_shape x6, x6, x13, x20, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x6, x18, x4, x20, ss3
ccr_decl x6
ccr_clr 2
lui x8, 65538
addi x8, x8, 1456
dm_load_l1 0, 0, x8, x0, ss3, if_
ss_pack_stride x0, x18, x6, ss7
dm_load_w 0, 0, x1, x25, ss7, pu
ss_pack_stride x3, x4, x20, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x6, x18, x4, x20, ss3
pu_fetchif_conf3 0, 0, x0, x6, ss3
dm_load_act0 0, 0, x29, x7, pu, 1
ss_pack_shape x6, x6, x4, x20, ss6
ccr_decl x6
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 2016
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x6, x6, x4, x20, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x4, x20, ss4
pu_of_conf1 0, 0, x6, x0, ss4
ss_pack_shape x6, x6, x4, x20, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x12, x0, 1080
ss_pack_stride x6, x6, x12, ss1
ss_pack_stride x6, x6, x12, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x12, ss5
ccr_decl x6
ccr_clr 0
lw x16, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
l2_store x14, x11, ss5
end x0
# case: test_squeeze[3-1-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 234
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 235
mmu_conf x7, x6, 4
addi x8, x0, 236
mmu_conf x8, x6, 5
addi x9, x0, 1728
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 131072
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x18, x19, x19, ss5
mfu_act1_conf_dest x9, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x11, x0, x15
l2_load_w_conf x6, x6, i8, i8, 0
ccr_decl x6
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x0
addi x25, x0, 7
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x6
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x6, x18, x19, x19, ss5
ccr_decl x6
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x6
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 57
add x29, x31, x29
lui x30, 196608
addi x30, x30, 0
l2_load_w x30, x29, x4
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x6, x6
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x6, ss6
ccr_decl x4
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x6, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x6, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x6
ccr_clr 4
addi x2, x0, 14
dm_load_act0 0, 0, x27, x2, pu, 1
ss_pack_stride x6, x19, x19, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x6, x6, x19, x19, ss1
ccr_decl x6
ccr_set 0, 1
dm_store_of 0, 0, x11, ss1, pu
ss_pack_shape x6, x6, x19, x19, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x6, x19, x19, ss0
pu_of_conf1 0, 0, x6, x0, ss0
ss_pack_shape x6, x6, x19, x19, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x3, x0, 576
ss_pack_stride x6, x6, x3, ss2
ss_pack_stride x6, x6, x3, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x3, ss3
ccr_decl x6
ccr_clr 0
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
l2_store x5, x11, ss3
end x0
# case: test_squeeze[3-1-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 559
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 561
mmu_conf x7, x6, 4
addi x8, x0, 563
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x26, x0, 8
addi x24, x0, 56
add x24, x26, x24
lui x25, 327680
addi x25, x25, 0
l2_load_w x25, x24, x6
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 12
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x4
addi x5, x0, 24
dm_load_w_conf 0, 0, 1, 1, x5
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x4, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x9
ccr_clr 4
addi x8, x0, 42
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_stride x4, x20, x21, ss1
dm_store_of_conf 0, 0, ss1, fp16
ss_pack_shape x9, x4, x14, x21, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x4, x14, x21, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x14, x21, ss5
pu_of_conf1 0, 0, x4, x0, ss5
ss_pack_shape x9, x4, x14, x21, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x6, x21, ss3
ccr_decl x9
ccr_clr 2
lui x11, 65538
addi x11, x11, 1456
dm_load_l1 0, 0, x11, x0, ss3, if_
ss_pack_stride x0, x19, x4, ss7
dm_load_w 0, 0, x2, x25, ss7, pu
ss_pack_stride x5, x6, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x6, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x8, pu, 1
ss_pack_shape x9, x4, x6, x21, ss6
ccr_decl x9
ccr_set 0, 1
lui x13, 65536
addi x13, x13, 2016
dm_store_of 0, 0, x13, ss6, pu
ss_pack_shape x9, x4, x6, x21, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x6, x21, ss4
pu_of_conf1 0, 0, x4, x0, ss4
ss_pack_shape x9, x4, x6, x21, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x15, 1
addi x15, x15, 3240
ss_pack_stride x9, x9, x15, ss1
ss_pack_stride x9, x9, x15, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss5
ccr_decl x9
ccr_clr 0
lw x10, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x10, x17
l2_store x17, x12, ss5
end x0
# case: test_squeeze[3-1-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 235
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 237
mmu_conf x7, x6, 4
addi x8, x0, 239
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 24
ss_pack_stride x4, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x4, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x16
l2_load_w_conf x4, x4, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x18
ss_pack_stride x4, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 9
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x9, x4
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x4, x4, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x4, x0
ss_pack_shape x9, x4, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x2, x0, 42
dm_load_act0 0, 0, x26, x2, pu, 1
ss_pack_stride x4, x19, x19, ss3
dm_store_of_conf 0, 0, ss3, fp16
ss_pack_shape x9, x4, x19, x19, ss5
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss5, pu
ss_pack_shape x9, x4, x19, x19, ss5
act0_src1_conf 0, 0, pu, ss5, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x4, x19, x19, ss3
pu_of_conf1 0, 0, x4, x0, ss3
ss_pack_shape x9, x4, x19, x19, ss5
pu_of_conf2 0, 0, x0, ss5
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x9, x9, x10, ss1
ss_pack_stride x9, x9, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_clr 0
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
l2_store x3, x12, ss2
end x0
# case: test_squeeze[3-3-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 563
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 565
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 566
mmu_conf x9, x8, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 57
add x28, x30, x28
lui x29, 262144
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x14, x21, ss6
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
l2_load_w_conf x21, x21, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x2, x0, 8
addi x31, x0, 71
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load_w x1, x31, x24
addi x3, x0, 216
dm_load_w_conf 0, 0, 3, 3, x3
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x1, x26, ss7, pu
addi x5, x0, 24
ss_pack_stride x5, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x8, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
ccr_decl x8
ccr_clr 4
addi x9, x0, 14
dm_load_act0 0, 0, x29, x9, pu, 1
addi x11, x0, 34
ss_pack_stride x8, x14, x11, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x13, x0, 26
ss_pack_shape x8, x8, x13, x11, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x8, x8, x13, x11, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x13, x11, ss5
pu_of_conf1 0, 0, x8, x0, ss5
ss_pack_shape x8, x8, x13, x11, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x8, x19, x19, x21, ss3
ccr_decl x8
ccr_clr 2
lui x15, 65538
addi x15, x15, 1384
dm_load_l1 0, 0, x15, x0, ss3, if_
ss_pack_stride x0, x19, x8, ss7
dm_load_w 0, 0, x1, x26, ss7, pu
ss_pack_stride x5, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x8, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x8, ss3
dm_load_act0 0, 0, x29, x9, pu, 1
ss_pack_shape x8, x8, x6, x11, ss6
ccr_decl x8
ccr_set 0, 1
lui x17, 65536
addi x17, x17, 1768
dm_store_of 0, 0, x17, ss6, pu
ss_pack_shape x8, x8, x6, x11, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x6, x11, ss4
pu_of_conf1 0, 0, x8, x0, ss4
ss_pack_shape x8, x8, x6, x11, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
addi x10, x0, 952
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss5
ccr_decl x8
ccr_clr 0
lw x16, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x16, x22
l2_store x22, x12, ss5
end x0
# case: test_squeeze[3-3-1-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 7
mmu_conf x3, x4, 2
addi x5, x0, 239
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 241
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 242
mmu_conf x9, x8, 5
addi x10, x0, 1728
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 24
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65537
addi x22, x22, 3456
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x8, x8, i8, i8, 0
ccr_decl x8
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 327680
addi x24, x24, 0
l2_load_w x24, x23, x0
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x8
ccr_set 4, 1
lw x28, x0, 8
addi x26, x0, 43
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x19, x20, x20, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x8, x19, x20, x20, ss5
ccr_decl x8
ccr_clr 2
dm_load_l1 0, 0, x22, x0, ss5, if_
addi x29, x0, 27
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x8
ccr_set 5, 1
lw x1, x0, 8
addi x30, x0, 57
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load_w x31, x30, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x8, x8
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x8, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x31, x24, ss6, pu
ss_pack_stride x20, x20, x20, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x8, x19, x20, x20, ss5
pu_fetchif_conf3 0, 0, x0, x8, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x8
ccr_clr 4
addi x5, x0, 14
dm_load_act0 0, 0, x27, x5, pu, 1
addi x7, x0, 22
ss_pack_stride x8, x7, x7, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x8, x8, x7, x7, ss1
ccr_decl x8
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x8, x8, x7, x7, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x8, x7, x7, ss0
pu_of_conf1 0, 0, x8, x0, ss0
ss_pack_shape x8, x8, x7, x7, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x9, x0, 484
ss_pack_stride x8, x8, x9, ss2
ss_pack_stride x8, x8, x9, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x9, ss3
ccr_decl x8
ccr_clr 0
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x12, ss3
end x0
# case: test_squeeze[3-3-3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 540
mmu_conf x1, x2, 1
addi x3, x0, 556
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 577
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 579
mmu_conf x7, x6, 4
addi x8, x0, 581
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 1
addi x10, x10, 224
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 28
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 262144
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 4
addi x20, x0, 30
addi x21, x0, 36
ss_pack_stride x19, x20, x21, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x21, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x19, x20, x21, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x24, x0, 3
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x23, 65538
addi x23, x23, 448
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x24, x24, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 56
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load_w x26, x25, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x30, x0, 8
addi x28, x0, 59
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x19, x20, x21, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x19, x14, x21, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x23, x0, ss6, if_
addi x31, x0, 108
l2_load_w_conf x31, x31, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x3, x0, 8
addi x1, x0, 101
add x1, x3, x1
lui x2, 131072
addi x2, x2, 0
l2_load_w x2, x1, x24
addi x5, x0, 216
dm_load_w_conf 0, 0, 3, 3, x5
dm_load_w_conf2 0, 0, x9, x24
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x24, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x2, x26, ss7, pu
addi x7, x0, 24
ss_pack_stride x7, x14, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x9, x19, x14, x21, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
ccr_decl x9
ccr_clr 4
addi x11, x0, 42
dm_load_act0 0, 0, x29, x11, pu, 1
addi x13, x0, 34
ss_pack_stride x24, x14, x13, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x15, x0, 26
ss_pack_shape x9, x24, x15, x13, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x24, x15, x13, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x15, x13, ss5
pu_of_conf1 0, 0, x24, x0, ss5
ss_pack_shape x9, x24, x15, x13, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x19, x19, x21, ss3
ccr_decl x9
ccr_clr 2
lui x17, 65538
addi x17, x17, 1384
dm_load_l1 0, 0, x17, x0, ss3, if_
ss_pack_stride x0, x19, x24, ss7
dm_load_w 0, 0, x2, x26, ss7, pu
ss_pack_stride x7, x19, x21, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x19, x19, x21, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x29, x11, pu, 1
ss_pack_shape x9, x24, x6, x13, ss6
ccr_decl x9
ccr_set 0, 1
lui x10, 65536
addi x10, x10, 1768
dm_store_of 0, 0, x10, ss6, pu
ss_pack_shape x9, x24, x6, x13, ss6
act0_src1_conf 0, 0, pu, ss6, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x24, x6, x13, ss4
pu_of_conf1 0, 0, x24, x0, ss4
ss_pack_shape x9, x24, x6, x13, ss6
pu_of_conf2 0, 0, x0, ss6
pu_compute 0, none
lui x22, 1
addi x22, x22, 2856
ss_pack_stride x9, x9, x22, ss1
ss_pack_stride x9, x9, x22, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x9, x9, x9, x22, ss5
ccr_decl x9
ccr_clr 0
lw x25, x0, 4
lui x16, 0
addi x16, x16, 0
add x16, x25, x16
l2_store x16, x12, ss5
end x0
# case: test_squeeze[3-3-3-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 216
mmu_conf x1, x2, 1
addi x3, x0, 232
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 253
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 255
mmu_conf x7, x6, 4
addi x8, x0, 257
addi x9, x0, 1
mmu_conf x8, x9, 5
addi x10, x0, 1728
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 24
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65537
addi x21, x21, 3456
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x19, x19, ss5
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss5, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
dm_load_w_conf 0, 0, 3, 3, x2
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss6
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss6, pu
ss_pack_stride x19, x19, x19, ss7
pu_fetchif_conf1 0, 0, 1, 1, ss7
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x19, x19, ss5
pu_fetchif_conf3 0, 0, x0, x9, ss5
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x1, x0, 31
pu_fetchif_conf_deq 0, 0, x1, x0, u8
ccr_decl x9
ccr_clr 4
addi x3, x0, 42
dm_load_act0 0, 0, x26, x3, pu, 1
addi x5, x0, 22
ss_pack_stride x18, x5, x5, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x9, x18, x5, x5, ss1
ccr_decl x9
ccr_set 0, 1
dm_store_of 0, 0, x12, ss1, pu
ss_pack_shape x9, x18, x5, x5, ss1
act0_src1_conf 0, 0, pu, ss1, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x5, x5, ss0
pu_of_conf1 0, 0, x18, x0, ss0
ss_pack_shape x9, x18, x5, x5, ss1
pu_of_conf2 0, 0, x0, ss1
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x7, x0, 1452
ss_pack_stride x9, x9, x7, ss2
ss_pack_stride x9, x9, x7, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x9, x9, x9, x7, ss3
ccr_decl x9
ccr_clr 0
lw x11, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x11, x8
l2_store x8, x12, ss3
end x0
