# case: test_einsum[case0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 8
mmu_conf x1, x2, 1
addi x3, x0, 24
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 26
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 27
mmu_conf x7, x6, 4
addi x8, x0, 28
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 4
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 65536
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x9, x6, ss6
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x9, x18, ss7
mfu_act1_conf_stride ss6, ss4, ss7
mfu_act1_conf_src1 x9, x18, x6, 0, l2
ss_pack_shape x6, x6, x9, x6, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x18, ss5
mfu_act1_conf_src2 x9, ss5, 1, l2
ss_pack_shape x6, x6, x9, x18, ss1
addi x22, x0, 12
mfu_act1_conf_dest x22, ss1
lui x23, 2
addi x23, x23, 2904
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 131072
addi x24, x24, 32
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x22, ss2
ss_pack_stride x6, x6, x22, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x6, x6, x6, x22, ss3
ccr_decl x6
ccr_clr 3
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x24, ss3
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 30
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_einsum[case1]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 18
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1570
mmu_conf x8, x1, 5
lui x9, 2
addi x9, x9, 1586
addi x10, x0, 6
mmu_conf x9, x10, 6
lui x11, 2
addi x11, x11, 1592
addi x12, x0, 1
mmu_conf x11, x12, 7
addi x13, x0, 12
l2_load_w_conf x13, x13, i8, i8, 0
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 458752
addi x15, x15, 0
addi x17, x0, 11
l2_load_w x15, x14, x17
addi x18, x0, 84
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 12
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
ss_pack_stride x12, x12, x10, ss0
addi x23, x0, 8
addi x24, x0, 32
ss_pack_stride x12, x23, x24, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x23, x10, ss2
ccr_decl x12
ccr_set 0, 1
lw x27, x0, 0
lui x25, 0
addi x25, x25, 0
add x25, x27, x25
lui x26, 327680
addi x26, x26, 0
l2_load x26, x25, ss2
addi x28, x0, 72
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x12
ccr_set 1, 1
lw x31, x0, 8
addi x29, x0, 180
add x29, x31, x29
lui x30, 262144
addi x30, x30, 0
addi x3, x0, 5
l2_load_w x30, x29, x3
addi x2, x0, 24
dm_load_w_conf 0, 0, 1, 1, x2
dm_load_w_conf2 0, 0, x12, x13
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x10, x13, ss3
ccr_decl x12
ccr_clr 1
dm_load_w 0, 0, x30, x15, ss3, pu
ss_pack_stride x12, x23, x24, ss1
addi x4, x0, 1024
ss_pack_stride x2, x12, x4, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x12, x12, x23, x10, ss2
addi x6, x0, 2
ccr_decl x6
ccr_clr 0
ccr_set 2, 1
lui x5, 196608
addi x5, x5, 0
mfu_transpose x5, x26, ss2
ss_pack_stride x2, x12, x4, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x12, x10, x12, x23, ss5
ccr_decl x12
ccr_clr 2
dm_load_l1 0, 0, x5, x0, ss5, if_
ss_pack_stride x2, x12, x23, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x10, x0
ss_pack_shape x12, x10, x12, x23, ss5
pu_fetchif_conf3 0, 0, x0, x12, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x7, x0, 31
pu_fetchif_conf_deq 0, 0, x7, x0, u8
addi x8, x0, 168
dm_load_act0 0, 0, x20, x8, pu, 1
ss_pack_stride x24, x12, x4, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x12, x13, x12, x23, ss3
ccr_decl x12
ccr_set 3, 1
lui x1, 65536
addi x1, x1, 0
dm_store_of 0, 0, x1, ss3, pu
ss_pack_shape x12, x13, x12, x23, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x13, x12, x23, ss1
pu_of_conf1 0, 0, x13, x0, ss1
ss_pack_shape x12, x13, x12, x23, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x24, x12, x4, ss0
ss_pack_stride x12, x4, x24, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x12, x13, x12, x23, ss3
ccr_decl x6
ccr_clr 3
ccr_set 4, 1
lui x9, 131072
addi x9, x9, 0
mfu_transpose x9, x1, ss3
ss_pack_stride x12, x4, x24, ss2
ss_pack_stride x12, x23, x13, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x12, x12, x23, x13, ss6
ccr_decl x12
ccr_clr 4
lw x14, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x14, x11
l2_store x11, x9, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 6
mmu_conf x1, x2, 1
addi x3, x0, 22
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 23
mmu_conf x5, x4, 3
addi x6, x0, 24
mmu_conf x6, x4, 4
addi x7, x0, 48
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 252
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
l2_load_w x13, x12, x5
addi x15, x0, 2
addi x16, x0, 4
ss_pack_stride x15, x16, x2, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x15, x16, x2, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x15, x16, x2, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x15, x16, x2, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 96
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_einsum[case2]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 24
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 288
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 28
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 336
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 32
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 384
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 36
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 432
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 77
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 119
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 151
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 193
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 80
mmu_conf x1, x2, 1
addi x3, x0, 96
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 97
mmu_conf x5, x4, 3
addi x6, x0, 4
addi x7, x0, 10
addi x8, x0, 6
ss_pack_stride x6, x7, x8, ss0
ss_pack_stride x6, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x6, x7, x8, ss2
ccr_decl x4
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
ss_pack_stride x6, x7, x1, ss1
ss_pack_stride x7, x6, x1, ss3
mfu_transpose_conf ss3, ss1, fp16, NHCW
ss_pack_shape x4, x6, x7, x8, ss2
addi x13, x0, 2
ccr_decl x13
ccr_clr 0
ccr_set 1, 1
lui x12, 65536
addi x12, x12, 1280
mfu_transpose x12, x10, ss2
ss_pack_stride x7, x6, x1, ss3
ss_pack_stride x7, x6, x8, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x4, x7, x6, x8, ss5
ccr_decl x4
ccr_clr 1
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 225
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 267
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 137
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 299
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 341
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 211
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 373
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 415
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 285
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_6
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 447
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 489
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 359
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_7
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 521
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 563
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_6
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 433
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_8
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 595
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 637
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_7
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 507
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_9
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 669
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 711
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_8
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 581
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_9
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 655
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_10
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 433
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_einsum[case3]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 12
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 144
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 16
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 192
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 20
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 240
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 24
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 288
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 28
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 336
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 32
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 384
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 36
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 120
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 40
addi x8, x0, 432
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 3
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 45
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 77
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 119
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileTransposeMatmul_2
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 151
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 193
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 80
mmu_conf x1, x2, 1
addi x3, x0, 96
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 97
mmu_conf x5, x4, 3
addi x6, x0, 10
addi x7, x0, 4
addi x8, x0, 3
ss_pack_stride x6, x7, x8, ss0
ss_pack_stride x6, x7, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x6, x7, x8, ss2
ccr_decl x4
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
ss_pack_stride x6, x7, x1, ss1
ss_pack_stride x7, x6, x1, ss3
mfu_transpose_conf ss3, ss1, fp16, NHCW
ss_pack_shape x4, x6, x7, x8, ss2
addi x13, x0, 2
ccr_decl x13
ccr_clr 0
ccr_set 1, 1
lui x12, 65536
addi x12, x12, 1280
mfu_transpose x12, x10, ss2
ss_pack_stride x7, x6, x1, ss3
ss_pack_stride x7, x6, x8, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x4, x7, x6, x8, ss5
ccr_decl x4
ccr_clr 1
lw x15, x0, 4
lui x14, 0
addi x14, x14, 0
add x14, x15, x14
l2_store x14, x12, ss5
end x0
# tile: k230/ptq TileTransposeMatmul_3
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 225
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 267
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 63
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_4
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 285
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 327
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 137
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_5
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 359
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 401
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 211
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_6
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 419
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 461
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 137
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_7
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 493
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 535
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 345
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_8
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 567
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 609
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_6
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 211
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_9
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 8
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1560
addi x9, x0, 5
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1565
addi x11, x0, 2
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1567
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 3
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
l2_load_w x16, x15, x11
addi x18, x0, 21
l2_load_w_conf x18, x18, fp16, fp16, 0
lw x21, x0, 8
addi x19, x0, 641
add x19, x21, x19
lui x20, 393216
addi x20, x20, 0
addi x22, x0, 23
l2_load_w x20, x19, x22
addi x23, x0, 6
ss_pack_stride x13, x13, x23, ss0
addi x24, x0, 4
addi x25, x0, 32
ss_pack_stride x13, x24, x25, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x13
ccr_set 0, 1
lw x28, x0, 0
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 262144
addi x27, x27, 0
l2_load x27, x26, ss2
addi x29, x0, 18
l2_load_w_conf x29, x29, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x1, x0, 8
addi x30, x0, 683
add x30, x1, x30
lui x31, 327680
addi x31, x31, 0
l2_load_w x31, x30, x9
addi x3, x0, 24
dm_load_w_conf 0, 0, 1, 1, x3
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x23, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x31, x16, ss3, pu
ss_pack_stride x13, x24, x25, ss1
addi x2, x0, 1024
ss_pack_stride x3, x13, x2, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x24, x23, ss2
ccr_decl x11
ccr_clr 0
ccr_set 2, 1
lui x4, 196608
addi x4, x4, 0
mfu_transpose x4, x27, ss2
ss_pack_stride x3, x13, x2, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x23, x13, x24, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x4, x0, ss5, if_
ss_pack_stride x3, x13, x24, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x23, x0
ss_pack_shape x13, x23, x13, x24, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x5, x0, 31
pu_fetchif_conf_deq 0, 0, x5, x0, u8
addi x6, x0, 42
dm_load_act0 0, 0, x20, x6, pu, 1
ss_pack_stride x25, x13, x2, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x13
ccr_set 3, 1
lui x7, 65536
addi x7, x7, 0
dm_store_of 0, 0, x7, ss3, pu
ss_pack_shape x13, x14, x13, x24, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x24, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x24, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x25, x13, x2, ss0
ss_pack_stride x13, x2, x25, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x24, ss3
ccr_decl x11
ccr_clr 3
ccr_set 4, 1
lui x8, 131072
addi x8, x8, 0
mfu_transpose x8, x7, ss3
ss_pack_stride x13, x2, x25, ss2
ss_pack_stride x13, x24, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x24, x14, ss6
ccr_decl x13
ccr_clr 4
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x8, ss6
end x0
# tile: k230/ptq TileLayerGroup_7
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 479
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_8
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 553
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_9
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 627
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# tile: k230/ptq TileLayerGroup_10
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 21
mmu_conf x5, x4, 3
addi x6, x0, 22
mmu_conf x6, x4, 4
addi x7, x0, 24
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 701
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 6
ss_pack_stride x4, x2, x16, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x2, x16, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x2, x16, ss5
mfu_act1_conf_dest x7, ss5
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x19, x0, 3
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 64
mfu_act1_compute x18, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x18, ss2
end x0
# case: test_einsum[case4]
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 0
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 16
mmu_conf x3, x2, 2
lui x4, 2
addi x4, x4, 16
addi x5, x0, 1536
mmu_conf x4, x5, 3
lui x6, 2
addi x6, x6, 1552
addi x7, x0, 20
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 1572
addi x9, x0, 9
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 1581
addi x11, x0, 3
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 1584
addi x13, x0, 1
mmu_conf x12, x13, 7
addi x14, x0, 6
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
addi x18, x0, 5
l2_load_w x16, x15, x18
addi x19, x0, 42
l2_load_w_conf x19, x19, fp16, fp16, 0
lw x22, x0, 8
addi x20, x0, 6
add x20, x22, x20
lui x21, 393216
addi x21, x21, 0
addi x23, x0, 23
l2_load_w x21, x20, x23
addi x24, x0, 12
ss_pack_stride x13, x13, x24, ss0
addi x25, x0, 10
addi x26, x0, 32
ss_pack_stride x13, x25, x26, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x25, x24, ss2
ccr_decl x13
ccr_set 0, 1
lw x29, x0, 0
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 262144
addi x28, x28, 0
l2_load x28, x27, ss2
addi x30, x0, 72
l2_load_w_conf x30, x30, i8, i8, 0
ccr_decl x13
ccr_set 1, 1
lw x3, x0, 8
addi x31, x0, 90
add x31, x3, x31
lui x1, 327680
addi x1, x1, 0
addi x2, x0, 11
l2_load_w x1, x31, x2
addi x4, x0, 24
dm_load_w_conf 0, 0, 1, 1, x4
dm_load_w_conf2 0, 0, x13, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x24, x14, ss3
ccr_decl x13
ccr_clr 1
dm_load_w 0, 0, x1, x16, ss3, pu
ss_pack_stride x13, x25, x26, ss1
addi x5, x0, 1024
ss_pack_stride x4, x13, x5, ss4
mfu_transpose_conf ss4, ss1, i8, NWCH
ss_pack_shape x13, x13, x25, x24, ss2
addi x7, x0, 2
ccr_decl x7
ccr_clr 0
ccr_set 2, 1
lui x6, 196608
addi x6, x6, 0
mfu_transpose x6, x28, ss2
ss_pack_stride x4, x13, x5, ss4
dm_load_l1_conf 0, 0, ss4, i8, if_
ss_pack_shape x13, x24, x13, x25, ss5
ccr_decl x13
ccr_clr 2
dm_load_l1 0, 0, x6, x0, ss5, if_
ss_pack_stride x4, x13, x25, ss6
pu_fetchif_conf1 0, 0, 1, 1, ss6
pu_fetchif_conf2 0, 0, x24, x0
ss_pack_shape x13, x24, x13, x25, ss5
pu_fetchif_conf3 0, 0, x0, x13, ss5
ss_pack_shape x0, x0, x0, x0, ss7
pu_fetchif_conf4 0, 0, x0, ss7
addi x8, x0, 31
pu_fetchif_conf_deq 0, 0, x8, x0, u8
addi x9, x0, 84
dm_load_act0 0, 0, x21, x9, pu, 1
ss_pack_stride x26, x13, x5, ss0
dm_store_of_conf 0, 0, ss0, fp16
ss_pack_shape x13, x14, x13, x25, ss3
ccr_decl x13
ccr_set 3, 1
lui x10, 65536
addi x10, x10, 0
dm_store_of 0, 0, x10, ss3, pu
ss_pack_shape x13, x14, x13, x25, ss3
act0_src1_conf 0, 0, pu, ss3, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x14, x13, x25, ss1
pu_of_conf1 0, 0, x14, x0, ss1
ss_pack_shape x13, x14, x13, x25, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x26, x13, x5, ss0
ss_pack_stride x13, x5, x26, ss2
mfu_transpose_conf ss2, ss0, fp16, NHWC
ss_pack_shape x13, x14, x13, x25, ss3
ccr_decl x7
ccr_clr 3
ccr_set 4, 1
lui x11, 131072
addi x11, x11, 0
mfu_transpose x11, x10, ss3
ss_pack_stride x13, x5, x26, ss2
ss_pack_stride x13, x25, x14, ss4
l2_store_conf ss4, ss2, fp16, fp32
ss_pack_shape x13, x13, x25, x14, ss6
ccr_decl x13
ccr_clr 4
lw x15, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x15, x12
l2_store x12, x11, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
mmu_conf x1, x1, 1
addi x2, x0, 32
addi x3, x0, 1
mmu_conf x2, x3, 2
addi x4, x0, 33
mmu_conf x4, x3, 3
addi x5, x0, 34
mmu_conf x5, x3, 4
addi x6, x0, 24
ss_pack_stride x3, x3, x6, ss0
ss_pack_stride x3, x3, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x7, x0, 120
ss_pack_shape x3, x3, x3, x7, ss2
ccr_decl x3
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 14
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x3
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 162
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 2
addi x17, x0, 3
addi x18, x0, 4
ss_pack_stride x16, x17, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x16, x17, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x3, x3, 0, l2
addi x19, x0, 5
ss_pack_shape x19, x16, x17, x18, ss5
mfu_act1_conf_src2 x3, ss5, 0, l2
mfu_act1_conf_src1 x3, x3, x3, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x3, ss4, 1, l2
ss_pack_shape x19, x16, x17, x18, ss5
mfu_act1_conf_dest x7, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 256
mfu_act1_compute x21, x9, x0, x13
ss_pack_stride x3, x3, x6, ss1
ss_pack_stride x3, x3, x6, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x3, x3, x3, x7, ss2
ccr_decl x3
ccr_clr 2
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
end x0
