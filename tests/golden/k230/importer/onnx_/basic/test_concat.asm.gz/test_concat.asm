# case: test_concat[0-in_shape0]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
ss_pack_stride x2, x2, x2, ss0
ss_pack_stride x2, x2, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_set 0, 1
lw x5, x0, 0
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
lui x4, 65536
addi x4, x4, 0
l2_load x4, x3, ss2
ss_pack_stride x2, x2, x2, ss1
addi x6, x0, 3
ss_pack_stride x2, x2, x6, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_clr 0
lw x8, x0, 12
lui x7, 0
addi x7, x7, 0
add x7, x8, x7
l2_store x7, x4, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
ss_pack_stride x2, x2, x2, ss0
ss_pack_stride x2, x2, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_set 0, 1
lw x5, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
lui x4, 65536
addi x4, x4, 0
l2_load x4, x3, ss2
ss_pack_stride x2, x2, x2, ss1
addi x6, x0, 3
ss_pack_stride x2, x2, x6, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_clr 0
lw x8, x0, 12
addi x7, x0, 4
add x7, x8, x7
l2_store x7, x4, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
ss_pack_stride x2, x2, x2, ss0
ss_pack_stride x2, x2, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_set 0, 1
lw x5, x0, 8
lui x3, 0
addi x3, x3, 0
add x3, x5, x3
lui x4, 65536
addi x4, x4, 0
l2_load x4, x3, ss2
ss_pack_stride x2, x2, x2, ss1
addi x6, x0, 3
ss_pack_stride x2, x2, x6, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x2, ss2
ccr_decl x2
ccr_clr 0
lw x8, x0, 12
addi x7, x0, 8
add x7, x8, x7
l2_store x7, x4, ss2
end x0
# case: test_concat[0-in_shape1]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
lui x8, 0
addi x8, x8, 0
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 48
add x8, x9, x8
l2_store x8, x5, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
ss_pack_stride x2, x2, x3, ss1
addi x7, x0, 36
ss_pack_stride x2, x2, x7, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_clr 0
lw x9, x0, 12
addi x8, x0, 96
add x8, x9, x8
l2_store x8, x5, ss2
end x0
# case: test_concat[0-in_shape2]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
addi x8, x0, 180
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x6, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
addi x8, x0, 180
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
addi x9, x0, 240
add x9, x10, x9
l2_store x9, x6, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
addi x8, x0, 180
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
addi x9, x0, 480
add x9, x10, x9
l2_store x9, x6, ss2
end x0
# case: test_concat[0-in_shape3]
# case: test_concat[1-in_shape1]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 0
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
addi x7, x0, 3
addi x8, x0, 4
ss_pack_stride x2, x7, x8, ss3
ss_pack_stride x2, x7, x3, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x2, x2, x7, x8, ss5
ccr_decl x2
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x5, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 4
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
addi x7, x0, 3
addi x8, x0, 4
ss_pack_stride x2, x7, x8, ss3
ss_pack_stride x2, x7, x3, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x2, x2, x7, x8, ss5
ccr_decl x2
ccr_clr 0
lw x10, x0, 12
addi x9, x0, 16
add x9, x10, x9
l2_store x9, x5, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 1
mmu_conf x1, x2, 1
addi x3, x0, 12
ss_pack_stride x2, x2, x3, ss0
ss_pack_stride x2, x2, x3, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x2, x2, x2, x3, ss2
ccr_decl x2
ccr_set 0, 1
lw x6, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x6, x4
lui x5, 65536
addi x5, x5, 0
l2_load x5, x4, ss2
addi x7, x0, 3
addi x8, x0, 4
ss_pack_stride x2, x7, x8, ss3
ss_pack_stride x2, x7, x3, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x2, x2, x7, x8, ss5
ccr_decl x2
ccr_clr 0
lw x10, x0, 12
addi x9, x0, 32
add x9, x10, x9
l2_store x9, x5, ss5
end x0
# case: test_concat[1-in_shape2]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 20
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_store x10, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 20
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
addi x10, x0, 80
add x10, x11, x10
l2_store x10, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 20
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
addi x10, x0, 160
add x10, x11, x10
l2_store x10, x6, ss5
end x0
# case: test_concat[1-in_shape3]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
lui x8, 5
addi x8, x8, 256
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x6, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
lui x8, 5
addi x8, x8, 256
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 7
addi x9, x9, 3072
add x9, x10, x9
l2_store x9, x6, ss2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
ss_pack_stride x3, x3, x4, ss1
lui x8, 5
addi x8, x8, 256
ss_pack_stride x3, x3, x8, ss3
l2_store_conf ss3, ss1, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_clr 0
lw x10, x0, 12
lui x9, 14
addi x9, x9, 2048
add x9, x10, x9
l2_store x9, x6, ss2
end x0
# case: test_concat[2-in_shape2]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 5
ss_pack_stride x8, x2, x9, ss3
addi x10, x0, 15
ss_pack_stride x8, x2, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x2, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_store x11, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 5
ss_pack_stride x8, x2, x9, ss3
addi x10, x0, 15
ss_pack_stride x8, x2, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x2, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
addi x11, x0, 20
add x11, x12, x11
l2_store x11, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 1
addi x4, x0, 60
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 5
ss_pack_stride x8, x2, x9, ss3
addi x10, x0, 15
ss_pack_stride x8, x2, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x2, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
addi x11, x0, 40
add x11, x12, x11
l2_store x11, x6, ss5
end x0
# case: test_concat[2-in_shape3]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
lui x9, 1
addi x9, x9, 2304
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
lui x10, 0
addi x10, x10, 0
add x10, x11, x10
l2_store x10, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
lui x9, 1
addi x9, x9, 2304
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
lui x10, 2
addi x10, x10, 1024
add x10, x11, x10
l2_store x10, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
lui x9, 1
addi x9, x9, 2304
ss_pack_stride x8, x3, x9, ss3
ss_pack_stride x8, x3, x4, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x3, x9, ss5
ccr_decl x3
ccr_clr 0
lw x11, x0, 12
lui x10, 5
addi x10, x10, 2048
add x10, x11, x10
l2_store x10, x6, ss5
end x0
# case: test_concat[3-in_shape3]
# tile: k230/ptq TileConcat_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 0
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 48
ss_pack_stride x8, x9, x9, ss3
addi x10, x0, 144
ss_pack_stride x8, x9, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x9, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
lui x11, 0
addi x11, x11, 0
add x11, x12, x11
l2_store x11, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 4
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 48
ss_pack_stride x8, x9, x9, ss3
addi x10, x0, 144
ss_pack_stride x8, x9, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x9, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
addi x11, x0, 192
add x11, x12, x11
l2_store x11, x6, ss5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 1
lui x4, 2
addi x4, x4, 2816
ss_pack_stride x3, x3, x4, ss0
ss_pack_stride x3, x3, x4, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x3, x3, x3, x4, ss2
ccr_decl x3
ccr_set 0, 1
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
lui x6, 65536
addi x6, x6, 0
l2_load x6, x5, ss2
addi x8, x0, 3
addi x9, x0, 48
ss_pack_stride x8, x9, x9, ss3
addi x10, x0, 144
ss_pack_stride x8, x9, x10, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x3, x8, x9, x9, ss5
ccr_decl x3
ccr_clr 0
lw x12, x0, 12
addi x11, x0, 384
add x11, x12, x11
l2_store x11, x6, ss5
end x0
