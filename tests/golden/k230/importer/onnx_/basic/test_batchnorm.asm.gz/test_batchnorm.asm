# case: test_batchnorm[0.01-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 8
mmu_conf x3, x4, 2
addi x5, x0, 600
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 601
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 512
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 56
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 24
ss_pack_stride x4, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 1024
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 112
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x4, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_batchnorm[0.01-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 2176
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 2192
addi x4, x0, 56
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 2248
addi x6, x0, 1
mmu_conf x5, x6, 3
lui x7, 2
addi x7, x7, 2249
mmu_conf x7, x6, 4
lui x8, 12
addi x8, x8, 1024
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 448
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 896
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 64
addi x18, x0, 28
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x21, x0, 3
ccr_decl x21
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65561
addi x20, x20, 2048
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 896
add x22, x24, x22
lui x23, 131072
addi x23, x23, 0
l2_load_w x23, x22, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x21
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x23
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x10, ss2
end x0
# case: test_batchnorm[None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 8
mmu_conf x3, x4, 2
addi x5, x0, 600
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 601
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 512
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 56
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 128
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 24
ss_pack_stride x4, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65538
addi x19, x19, 1024
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 112
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x4, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_batchnorm[None-in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 2
addi x2, x2, 2176
mmu_conf x1, x2, 1
lui x3, 2
addi x3, x3, 2192
addi x4, x0, 56
mmu_conf x3, x4, 2
lui x5, 2
addi x5, x5, 2248
addi x6, x0, 1
mmu_conf x5, x6, 3
lui x7, 2
addi x7, x7, 2249
mmu_conf x7, x6, 4
lui x8, 12
addi x8, x8, 1024
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 448
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 896
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 64
addi x18, x0, 28
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x21, x0, 3
ccr_decl x21
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65561
addi x20, x20, 2048
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 896
add x22, x24, x22
lui x23, 131072
addi x23, x23, 0
l2_load_w x23, x22, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x21
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x23
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x10, ss2
end x0
