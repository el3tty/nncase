# case: test_softsign[in_shape0]
