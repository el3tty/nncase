# case: test_binary[rhs_shape0-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 2
addi x16, x16, 2694
mfu_act1_conf_deq x16, x0, u8, 0
mfu_act1_conf_deq x16, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 14
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 28
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 2
addi x16, x16, 2694
mfu_act1_conf_deq x16, x0, u8, 0
mfu_act1_conf_deq x16, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 42
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 2
addi x16, x16, 2694
mfu_act1_conf_deq x16, x0, u8, 0
mfu_act1_conf_deq x16, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 56
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 2
addi x16, x16, 2694
mfu_act1_conf_deq x16, x0, u8, 0
mfu_act1_conf_deq x16, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape0-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x18, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 14
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 28
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x18, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 42
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x18, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 56
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x18, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# case: test_binary[rhs_shape0-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 2
addi x19, x19, 3076
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 42
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 84
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 2
addi x19, x19, 3076
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 126
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 2
addi x19, x19, 3076
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 168
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 2
addi x19, x19, 3076
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# case: test_binary[rhs_shape0-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 2
addi x21, x21, 3076
mfu_act1_conf_deq x21, x0, u8, 0
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x23, 65536
addi x23, x23, 0
mfu_act1_compute x23, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x23, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
addi x26, x0, 384
add x26, x28, x26
lui x27, 131073
addi x27, x27, 3072
l2_load x27, x26, ss7
addi x29, x0, 1536
mfu_act1_conf_src1 x29, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x29, ss3
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x30, 65538
addi x30, x30, 2048
lui x31, 196608
addi x31, x31, 28
mfu_act1_compute x30, x27, x0, x31
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x3, x0, 4
addi x1, x0, 1536
add x1, x3, x1
l2_store x1, x30, ss7
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 42
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileAct1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 84
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 2
addi x21, x21, 3076
mfu_act1_conf_deq x21, x0, u8, 0
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x23, 65536
addi x23, x23, 0
mfu_act1_compute x23, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x23, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
addi x26, x0, 384
add x26, x28, x26
lui x27, 131073
addi x27, x27, 3072
l2_load x27, x26, ss7
addi x29, x0, 1536
mfu_act1_conf_src1 x29, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x29, ss3
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x30, 65538
addi x30, x30, 2048
lui x31, 196608
addi x31, x31, 28
mfu_act1_compute x30, x27, x0, x31
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x3, x0, 4
addi x1, x0, 1536
add x1, x3, x1
l2_store x1, x30, ss7
end x0
# tile: k230/ptq TileAct1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 126
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 2
addi x21, x21, 3076
mfu_act1_conf_deq x21, x0, u8, 0
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x23, 65536
addi x23, x23, 0
mfu_act1_compute x23, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x23, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
addi x26, x0, 384
add x26, x28, x26
lui x27, 131073
addi x27, x27, 3072
l2_load x27, x26, ss7
addi x29, x0, 1536
mfu_act1_conf_src1 x29, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x29, ss3
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x30, 65538
addi x30, x30, 2048
lui x31, 196608
addi x31, x31, 28
mfu_act1_compute x30, x27, x0, x31
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x3, x0, 4
addi x1, x0, 1536
add x1, x3, x1
l2_store x1, x30, ss7
end x0
# tile: k230/ptq TileAct1_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 168
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 2
addi x21, x21, 3076
mfu_act1_conf_deq x21, x0, u8, 0
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x23, 65536
addi x23, x23, 0
mfu_act1_compute x23, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x23, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x28, x0, 0
addi x26, x0, 384
add x26, x28, x26
lui x27, 131073
addi x27, x27, 3072
l2_load x27, x26, ss7
addi x29, x0, 1536
mfu_act1_conf_src1 x29, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x29, ss3
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x22, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x30, 65538
addi x30, x30, 2048
lui x31, 196608
addi x31, x31, 28
mfu_act1_compute x30, x27, x0, x31
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x3, x0, 4
addi x1, x0, 1536
add x1, x3, x1
l2_store x1, x30, ss7
end x0
# case: test_binary[rhs_shape1-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 6
mmu_conf x1, x2, 1
addi x3, x0, 22
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 24
mmu_conf x5, x4, 3
addi x6, x0, 26
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 27
mmu_conf x8, x7, 5
addi x9, x0, 3
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 32
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x7, x7, x9, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x9, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x7, ss3, 1, l2
ss_pack_shape x7, x7, x7, x9, ss2
mfu_act1_conf_dest x9, ss2
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x9
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 131072
addi x19, x19, 32
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 14
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load_w x21, x20, x17
ss_pack_stride x7, x7, x9, ss1
ss_pack_stride x7, x7, x9, ss4
l2_load_conf ss4, ss1, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 3, 1
lw x25, x0, 8
addi x23, x0, 28
add x23, x25, x23
lui x24, 65536
addi x24, x24, 0
l2_load x24, x23, ss2
ss_pack_stride x7, x7, x9, ss4
ss_pack_stride x7, x7, x9, ss4
ss_pack_stride x7, x7, x9, ss4
mfu_act1_conf_stride ss4, ss4, ss4
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x7, x7, x9, ss2
mfu_act1_conf_src2 x7, ss2, 0, l2
mfu_act1_conf_src1 x9, x7, x7, 1, l2
ss_pack_shape x7, x7, x7, x9, ss2
mfu_act1_conf_src2 x7, ss2, 1, l2
ss_pack_shape x7, x7, x7, x9, ss2
mfu_act1_conf_dest x9, ss2
lui x26, 2
addi x26, x26, 3020
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x24, x21
ss_pack_stride x7, x7, x9, ss4
ss_pack_stride x7, x7, x9, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x11, ss2
end x0
# case: test_binary[rhs_shape1-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 46
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 47
mmu_conf x7, x6, 4
addi x8, x0, 48
mmu_conf x8, x6, 5
addi x9, x0, 192
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
ss_pack_stride x6, x22, x18, ss6
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x22, x18, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x22, x18, ss7
mfu_act1_conf_src2 x6, ss7, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x18, ss5
mfu_act1_conf_src2 x22, ss5, 1, l2
ss_pack_shape x6, x6, x22, x18, ss7
mfu_act1_conf_dest x9, ss7
lui x23, 2
addi x23, x23, 3075
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x25, x0, 4
ccr_decl x25
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x6, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 3
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x24, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 26
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 46
addi x6, x0, 3
mmu_conf x5, x6, 3
addi x7, x0, 49
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 50
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x6, ss0
ss_pack_stride x8, x8, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x6, ss2
ccr_decl x8
ccr_set 0, 1
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x16, x0, 12
addi x14, x0, 40
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x8, x8, x6, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x6, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_dest x6, ss2
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x22, x0, 12
addi x20, x0, 54
add x20, x22, x20
lui x21, 196608
addi x21, x21, 32
l2_load_w x21, x20, x17
ss_pack_stride x8, x8, x6, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x6, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_dest x6, ss2
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x0, x21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 12
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x17
addi x27, x0, 192
ss_pack_stride x8, x8, x27, ss4
ss_pack_stride x8, x8, x27, ss5
l2_load_conf ss5, ss4, i8, i8
ss_pack_shape x8, x8, x8, x27, ss6
ccr_decl x8
ccr_set 3, 1
lw x30, x0, 0
lui x28, 0
addi x28, x28, 0
add x28, x30, x28
lui x29, 131072
addi x29, x29, 0
l2_load x29, x28, ss6
ss_pack_stride x8, x8, x6, ss1
addi x31, x0, 64
ss_pack_stride x8, x31, x6, ss7
ss_pack_stride x8, x31, x6, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x31, ss2, 0, l2
mfu_act1_conf_src1 x27, x8, x8, 1, l2
ss_pack_shape x8, x8, x31, x6, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x8, x31, x6, ss0
mfu_act1_conf_dest x27, ss0
addi x1, x0, 255
mfu_act1_conf_deq x23, x1, u8, 0
lui x2, 2
addi x2, x2, 3075
mfu_act1_conf_deq x2, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x3, x0, 4
ccr_decl x3
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x19, x11, x29, x25
ss_pack_stride x8, x8, x27, ss5
ss_pack_stride x8, x8, x27, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x27, ss6
ccr_decl x8
ccr_clr 2
lw x5, x0, 8
lui x4, 0
addi x4, x4, 0
add x4, x5, x4
l2_store x4, x19, ss6
end x0
# case: test_binary[rhs_shape1-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 94
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 96
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 97
mmu_conf x9, x8, 5
addi x10, x0, 576
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
ss_pack_stride x19, x23, x19, ss6
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x19, x23, x19, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x23, x19, ss7
mfu_act1_conf_src2 x8, ss7, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x19, ss5
addi x24, x0, 192
mfu_act1_conf_src2 x24, ss5, 1, l2
ss_pack_shape x8, x19, x23, x19, ss7
mfu_act1_conf_dest x10, ss7
lui x25, 2
addi x25, x25, 3075
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 54
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 18
mmu_conf x3, x4, 2
addi x5, x0, 106
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 110
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 111
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 96
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x23, x0, 12
addi x21, x0, 110
add x21, x23, x21
lui x22, 196608
addi x22, x22, 64
l2_load_w x22, x21, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x20, x0, x22
addi x25, x0, 21
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x28, x0, 12
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
addi x29, x0, 576
ss_pack_stride x8, x8, x29, ss4
ss_pack_stride x8, x8, x29, ss5
l2_load_conf ss5, ss4, i8, i8
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_set 3, 1
lw x1, x0, 0
lui x30, 0
addi x30, x30, 0
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load x31, x30, ss6
ss_pack_stride x8, x8, x10, ss1
addi x2, x0, 64
ss_pack_stride x10, x2, x10, ss7
ss_pack_stride x10, x2, x10, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x3, x0, 192
mfu_act1_conf_src2 x3, ss2, 0, l2
mfu_act1_conf_src1 x29, x8, x8, 1, l2
ss_pack_shape x8, x10, x2, x10, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x10, x2, x10, ss0
mfu_act1_conf_dest x29, ss0
addi x4, x0, 255
mfu_act1_conf_deq x24, x4, u8, 0
lui x5, 2
addi x5, x5, 3075
mfu_act1_conf_deq x5, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x20, x12, x31, x27
ss_pack_stride x8, x8, x29, ss5
ss_pack_stride x8, x8, x29, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_clr 2
lw x9, x0, 8
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
l2_store x7, x20, ss6
end x0
# case: test_binary[rhs_shape1-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 288
mmu_conf x3, x4, 2
addi x5, x0, 880
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 882
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 196608
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, i8, i8
lui x14, 1
addi x14, x14, 512
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 3
ss_pack_stride x8, x8, x18, ss3
ss_pack_stride x8, x8, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x18, ss5
ccr_decl x8
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 262144
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
ss_pack_stride x18, x22, x18, ss6
ss_pack_stride x8, x8, x18, ss4
ss_pack_stride x18, x22, x18, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x14, x8, x8, 0, l2
addi x23, x0, 8
ss_pack_shape x23, x18, x22, x18, ss7
mfu_act1_conf_src2 x8, ss7, 0, l2
mfu_act1_conf_src1 x18, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x18, ss5
addi x24, x0, 1536
mfu_act1_conf_src2 x24, ss5, 1, l2
ss_pack_shape x23, x18, x22, x18, ss7
mfu_act1_conf_dest x14, ss7
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 65536
addi x27, x27, 0
mfu_act1_compute x27, x16, x20, x11
ss_pack_stride x8, x8, x2, ss1
ss_pack_stride x8, x8, x2, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss2
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 54
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 740
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 741
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 96
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 1024
mfu_act1_compute x20, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x23, x0, 12
addi x21, x0, 110
add x21, x23, x21
lui x22, 196608
addi x22, x22, 64
l2_load_w x22, x21, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x20, x0, x22
addi x25, x0, 21
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x28, x0, 12
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss5
l2_load_conf ss5, ss4, i8, i8
lui x29, 1
addi x29, x29, 512
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_set 3, 1
lw x1, x0, 0
lui x30, 0
addi x30, x30, 0
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load x31, x30, ss6
ss_pack_stride x8, x8, x10, ss1
addi x3, x0, 64
ss_pack_stride x10, x3, x10, ss7
ss_pack_stride x10, x3, x10, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x4, x0, 1536
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x29, x8, x8, 1, l2
addi x5, x0, 8
ss_pack_shape x5, x10, x3, x10, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x5, x10, x3, x10, ss0
mfu_act1_conf_dest x29, ss0
addi x6, x0, 255
mfu_act1_conf_deq x24, x6, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x7, x0, 4
ccr_decl x7
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x20, x12, x31, x27
ss_pack_stride x8, x8, x2, ss5
ss_pack_stride x8, x8, x2, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_clr 2
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
l2_store x9, x20, ss6
end x0
# case: test_binary[rhs_shape10-lhs_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 209
mmu_conf x6, x5, 4
addi x7, x0, 7
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 192
ss_pack_stride x5, x5, x16, ss3
ss_pack_stride x5, x5, x16, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x5, x5, x5, x17, ss5
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x5, x5, x12, ss1
addi x21, x0, 64
ss_pack_stride x5, x21, x12, ss6
ss_pack_stride x5, x21, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x22, x0, 512
mfu_act1_conf_src2 x22, ss2, 0, l2
mfu_act1_conf_src1 x17, x5, x5, 1, l2
addi x23, x0, 8
ss_pack_shape x23, x5, x21, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x23, x5, x21, x12, ss7
mfu_act1_conf_dest x17, ss7
lui x24, 2
addi x24, x24, 3017
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 131072
addi x26, x26, 0
mfu_act1_compute x26, x14, x19, x9
ss_pack_stride x5, x5, x16, ss4
ss_pack_stride x5, x5, x16, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x17, ss5
ccr_decl x5
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 209
mmu_conf x6, x5, 4
addi x7, x0, 7
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
addi x16, x0, 192
ss_pack_stride x5, x5, x16, ss3
ss_pack_stride x5, x5, x16, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x5, x5, x5, x17, ss5
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x5, x5, x12, ss1
addi x21, x0, 64
ss_pack_stride x5, x21, x12, ss6
ss_pack_stride x5, x21, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x22, x0, 512
mfu_act1_conf_src2 x22, ss2, 0, l2
mfu_act1_conf_src1 x17, x5, x5, 1, l2
addi x23, x0, 8
ss_pack_shape x23, x5, x21, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x23, x5, x21, x12, ss7
mfu_act1_conf_dest x17, ss7
lui x24, 2
addi x24, x24, 3017
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 131072
addi x26, x26, 0
mfu_act1_compute x26, x14, x19, x9
ss_pack_stride x5, x5, x16, ss4
ss_pack_stride x5, x5, x16, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x17, ss5
ccr_decl x5
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 2
addi x12, x12, 2062
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape10-lhs_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 6
mmu_conf x4, x5, 3
addi x6, x0, 214
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 7
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 192
ss_pack_stride x7, x7, x13, ss0
ss_pack_stride x7, x7, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x7, x7, x7, x13, ss2
ccr_decl x7
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x7, x7, x13, ss1
ss_pack_stride x7, x7, x13, ss3
l2_load_conf ss3, ss1, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x7, x7, x7, x17, ss4
ccr_decl x7
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss4
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x7, x21, x22, ss5
ss_pack_stride x7, x21, x22, ss5
ss_pack_stride x7, x21, x22, ss5
mfu_act1_conf_stride ss5, ss5, ss5
mfu_act1_conf_src1 x13, x7, x7, 0, l2
ss_pack_shape x7, x7, x21, x22, ss6
addi x23, x0, 8
mfu_act1_conf_src2 x23, ss6, 0, l2
mfu_act1_conf_src1 x17, x7, x7, 1, l2
ss_pack_shape x23, x7, x21, x22, ss7
mfu_act1_conf_src2 x7, ss7, 1, l2
ss_pack_shape x23, x7, x21, x22, ss7
mfu_act1_conf_dest x17, ss7
lui x24, 2
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 131072
addi x26, x26, 0
mfu_act1_compute x26, x15, x19, x10
ss_pack_stride x7, x7, x13, ss3
ss_pack_stride x7, x7, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x17, ss4
ccr_decl x7
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss4
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
mmu_conf x3, x2, 2
addi x4, x0, 208
addi x5, x0, 6
mmu_conf x4, x5, 3
addi x6, x0, 214
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 7
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 192
ss_pack_stride x7, x7, x13, ss0
ss_pack_stride x7, x7, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x7, x7, x7, x13, ss2
ccr_decl x7
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x7, x7, x13, ss1
ss_pack_stride x7, x7, x13, ss3
l2_load_conf ss3, ss1, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x7, x7, x7, x17, ss4
ccr_decl x7
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss4
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x7, x21, x22, ss5
ss_pack_stride x7, x21, x22, ss5
ss_pack_stride x7, x21, x22, ss5
mfu_act1_conf_stride ss5, ss5, ss5
mfu_act1_conf_src1 x13, x7, x7, 0, l2
ss_pack_shape x7, x7, x21, x22, ss6
addi x23, x0, 8
mfu_act1_conf_src2 x23, ss6, 0, l2
mfu_act1_conf_src1 x17, x7, x7, 1, l2
ss_pack_shape x23, x7, x21, x22, ss7
mfu_act1_conf_src2 x7, ss7, 1, l2
ss_pack_shape x23, x7, x21, x22, ss7
mfu_act1_conf_dest x17, ss7
lui x24, 2
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 131072
addi x26, x26, 0
mfu_act1_compute x26, x15, x19, x10
ss_pack_stride x7, x7, x13, ss3
ss_pack_stride x7, x7, x13, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x7, x7, x7, x17, ss4
ccr_decl x7
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss4
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 2
addi x12, x12, 2062
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# case: test_binary[rhs_shape10-lhs_shape2]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 36
mmu_conf x5, x6, 3
addi x7, x0, 820
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x14, x14, x4, ss3
ss_pack_stride x14, x14, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x18, x0, 1536
ss_pack_shape x14, x14, x14, x18, ss5
ccr_decl x14
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 3
addi x23, x0, 64
ss_pack_stride x22, x23, x22, ss6
ss_pack_stride x14, x23, x22, ss7
ss_pack_stride x22, x23, x22, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x22, x23, x22, ss0
addi x24, x0, 8
mfu_act1_conf_src2 x24, ss0, 0, l2
mfu_act1_conf_src1 x4, x14, x22, 1, l2
ss_pack_shape x24, x14, x23, x22, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x24, x22, x23, x22, ss2
lui x25, 1
addi x25, x25, 512
mfu_act1_conf_dest x25, ss2
lui x26, 2
addi x26, x26, 3075
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x16, x20, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x2, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x14, x14, x14, x25, ss4
ccr_decl x14
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 36
mmu_conf x5, x6, 3
addi x7, x0, 820
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x14, x14, x4, ss3
ss_pack_stride x14, x14, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x18, x0, 1536
ss_pack_shape x14, x14, x14, x18, ss5
ccr_decl x14
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 3
addi x23, x0, 64
ss_pack_stride x22, x23, x22, ss6
ss_pack_stride x14, x23, x22, ss7
ss_pack_stride x22, x23, x22, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x22, x23, x22, ss0
addi x24, x0, 8
mfu_act1_conf_src2 x24, ss0, 0, l2
mfu_act1_conf_src1 x4, x14, x22, 1, l2
ss_pack_shape x24, x14, x23, x22, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x24, x22, x23, x22, ss2
lui x25, 1
addi x25, x25, 512
mfu_act1_conf_dest x25, ss2
lui x26, 2
addi x26, x26, 3075
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x16, x20, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x2, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x14, x14, x14, x25, ss4
ccr_decl x14
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 2
addi x13, x13, 2090
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# case: test_binary[rhs_shape10-lhs_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 688
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 692
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 693
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
lui x10, 1
addi x10, x10, 512
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x18
addi x27, x0, 192
ss_pack_stride x8, x8, x27, ss6
ss_pack_stride x8, x8, x27, ss7
l2_load_conf ss7, ss6, fp16, fp32
addi x28, x0, 1536
ss_pack_shape x8, x8, x8, x28, ss0
ccr_decl x8
ccr_set 3, 1
lw x31, x0, 8
addi x29, x0, 84
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load x30, x29, ss0
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x8, x20, x19, ss1
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x27, x8, x19, 1, l2
ss_pack_shape x21, x8, x20, x19, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x1, 2
addi x1, x1, 3076
mfu_act1_conf_deq x1, x0, u8, 0
mfu_act1_conf_deq x1, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x23, x30, x25
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x4, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x4, x3
l2_store x3, x12, ss6
end x0
# case: test_binary[rhs_shape11-lhs_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 113
mmu_conf x7, x6, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 3
ss_pack_stride x6, x6, x13, ss0
ss_pack_stride x6, x6, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x13, ss2
ccr_decl x6
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
addi x17, x0, 192
ss_pack_stride x6, x6, x17, ss3
ss_pack_stride x6, x6, x17, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x17, ss5
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x6, x6, x13, ss1
addi x21, x0, 64
ss_pack_stride x13, x21, x6, ss6
ss_pack_stride x13, x21, x13, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x13, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x13, ss2
mfu_act1_conf_src2 x17, ss2, 0, l2
mfu_act1_conf_src1 x17, x13, x6, 1, l2
ss_pack_shape x6, x13, x21, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x6, x13, x21, x13, ss3
addi x22, x0, 576
mfu_act1_conf_dest x22, ss3
lui x23, 2
addi x23, x23, 3004
mfu_act1_conf_deq x23, x0, u8, 0
lui x24, 4
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x13
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x25, 65536
addi x25, x25, 0
mfu_act1_compute x25, x15, x19, x10
ss_pack_stride x6, x6, x22, ss4
ss_pack_stride x6, x6, x22, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x22, ss5
ccr_decl x6
ccr_clr 2
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x25, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 113
mmu_conf x7, x6, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 3
ss_pack_stride x6, x6, x13, ss0
ss_pack_stride x6, x6, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x13, ss2
ccr_decl x6
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
addi x17, x0, 192
ss_pack_stride x6, x6, x17, ss3
ss_pack_stride x6, x6, x17, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x17, ss5
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x6, x6, x13, ss1
addi x21, x0, 64
ss_pack_stride x13, x21, x6, ss6
ss_pack_stride x13, x21, x13, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x13, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x13, ss2
mfu_act1_conf_src2 x17, ss2, 0, l2
mfu_act1_conf_src1 x17, x13, x6, 1, l2
ss_pack_shape x6, x13, x21, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x6, x13, x21, x13, ss3
addi x22, x0, 576
mfu_act1_conf_dest x22, ss3
lui x23, 2
addi x23, x23, 3004
mfu_act1_conf_deq x23, x0, u8, 0
lui x24, 4
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x13
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x25, 65536
addi x25, x25, 0
mfu_act1_compute x25, x15, x19, x10
ss_pack_stride x6, x6, x22, ss4
ss_pack_stride x6, x6, x22, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x22, ss5
ccr_decl x6
ccr_clr 2
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x25, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 810
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape11-lhs_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 12
mmu_conf x5, x6, 3
addi x7, x0, 124
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 192
ss_pack_stride x8, x8, x14, ss0
ss_pack_stride x8, x8, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x8, x8, x14, ss1
ss_pack_stride x8, x8, x14, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss2
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x8, x21, x22, ss4
ss_pack_stride x22, x21, x8, ss5
ss_pack_stride x22, x21, x22, ss6
mfu_act1_conf_stride ss4, ss5, ss6
mfu_act1_conf_src1 x14, x8, x8, 0, l2
ss_pack_shape x8, x8, x21, x22, ss7
mfu_act1_conf_src2 x22, ss7, 0, l2
mfu_act1_conf_src1 x14, x22, x8, 1, l2
ss_pack_shape x8, x22, x21, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x22, x21, x22, ss1
addi x23, x0, 576
mfu_act1_conf_dest x23, ss1
lui x24, 2
addi x24, x24, 3074
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 65536
addi x26, x26, 0
mfu_act1_compute x26, x16, x19, x11
ss_pack_stride x8, x8, x23, ss3
ss_pack_stride x8, x8, x23, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x23, ss2
ccr_decl x8
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss2
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 12
mmu_conf x5, x6, 3
addi x7, x0, 124
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 192
ss_pack_stride x8, x8, x14, ss0
ss_pack_stride x8, x8, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x8, x8, x14, ss1
ss_pack_stride x8, x8, x14, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss2
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x8, x21, x22, ss4
ss_pack_stride x22, x21, x8, ss5
ss_pack_stride x22, x21, x22, ss6
mfu_act1_conf_stride ss4, ss5, ss6
mfu_act1_conf_src1 x14, x8, x8, 0, l2
ss_pack_shape x8, x8, x21, x22, ss7
mfu_act1_conf_src2 x22, ss7, 0, l2
mfu_act1_conf_src1 x14, x22, x8, 1, l2
ss_pack_shape x8, x22, x21, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x22, x21, x22, ss1
addi x23, x0, 576
mfu_act1_conf_dest x23, ss1
lui x24, 2
addi x24, x24, 3074
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 65536
addi x26, x26, 0
mfu_act1_compute x26, x16, x19, x11
ss_pack_stride x8, x8, x23, ss3
ss_pack_stride x8, x8, x23, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x23, ss2
ccr_decl x8
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss2
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 810
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# case: test_binary[rhs_shape11-lhs_shape2]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 48
mmu_conf x1, x2, 1
addi x3, x0, 64
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 88
mmu_conf x5, x1, 3
addi x6, x0, 104
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
addi x15, x0, 384
ss_pack_stride x13, x13, x15, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x15, ss2
ccr_decl x13
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 192
ss_pack_stride x13, x13, x19, ss3
addi x20, x0, 128
ss_pack_stride x13, x13, x20, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x13, x13, x13, x20, ss5
ccr_decl x13
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 3
ss_pack_stride x7, x3, x24, ss6
ss_pack_stride x7, x3, x13, ss7
ss_pack_stride x7, x3, x24, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x15, x13, x13, 0, l2
ss_pack_shape x13, x7, x3, x24, ss0
mfu_act1_conf_src2 x13, ss0, 0, l2
mfu_act1_conf_src1 x20, x24, x13, 1, l2
ss_pack_shape x13, x7, x3, x13, ss1
mfu_act1_conf_src2 x13, ss1, 1, l2
ss_pack_shape x13, x7, x3, x24, ss0
mfu_act1_conf_dest x15, ss0
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 65536
addi x27, x27, 0
mfu_act1_compute x27, x17, x22, x10
ss_pack_stride x13, x13, x15, ss2
ss_pack_stride x13, x13, x14, ss3
l2_store_conf ss3, ss2, fp16, fp32
ss_pack_shape x13, x13, x13, x15, ss4
ccr_decl x13
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss4
ss_pack_stride x13, x13, x14, ss3
ss_pack_stride x13, x13, x19, ss5
l2_load_conf ss5, ss3, i8, i8
ss_pack_shape x13, x13, x13, x19, ss7
ccr_decl x13
ccr_set 3, 1
lw x2, x0, 0
addi x30, x0, 384
add x30, x2, x30
lui x31, 131072
addi x31, x31, 384
l2_load x31, x30, ss7
ss_pack_stride x13, x13, x19, ss5
ss_pack_stride x13, x13, x3, ss6
l2_load_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x3, ss1
ccr_decl x13
ccr_set 4, 1
lw x1, x0, 8
addi x4, x0, 554
add x4, x1, x4
lui x5, 196608
addi x5, x5, 256
l2_load x5, x4, ss1
ss_pack_stride x13, x3, x24, ss0
ss_pack_stride x13, x3, x13, ss2
ss_pack_stride x7, x3, x24, ss4
mfu_act1_conf_stride ss0, ss2, ss4
mfu_act1_conf_src1 x19, x13, x13, 0, l2
ss_pack_shape x13, x13, x3, x24, ss3
mfu_act1_conf_src2 x13, ss3, 0, l2
mfu_act1_conf_src1 x3, x24, x13, 1, l2
ss_pack_shape x13, x13, x3, x13, ss7
mfu_act1_conf_src2 x13, ss7, 1, l2
ss_pack_shape x13, x13, x3, x24, ss3
mfu_act1_conf_dest x19, ss3
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x24
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x6, 65536
addi x6, x6, 768
lui x8, 262144
addi x8, x8, 28
mfu_act1_compute x6, x31, x5, x8
ss_pack_stride x13, x13, x15, ss5
ss_pack_stride x13, x13, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x19, ss1
ccr_decl x13
ccr_clr 5
lw x11, x0, 4
addi x9, x0, 1536
add x9, x11, x9
l2_store x9, x6, ss1
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 48
mmu_conf x1, x2, 1
addi x3, x0, 64
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 88
mmu_conf x5, x1, 3
addi x6, x0, 104
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
addi x15, x0, 384
ss_pack_stride x13, x13, x15, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x15, ss2
ccr_decl x13
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 192
ss_pack_stride x13, x13, x19, ss3
addi x20, x0, 128
ss_pack_stride x13, x13, x20, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x13, x13, x13, x20, ss5
ccr_decl x13
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 3
ss_pack_stride x7, x3, x24, ss6
ss_pack_stride x7, x3, x13, ss7
ss_pack_stride x7, x3, x24, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x15, x13, x13, 0, l2
ss_pack_shape x13, x7, x3, x24, ss0
mfu_act1_conf_src2 x13, ss0, 0, l2
mfu_act1_conf_src1 x20, x24, x13, 1, l2
ss_pack_shape x13, x7, x3, x13, ss1
mfu_act1_conf_src2 x13, ss1, 1, l2
ss_pack_shape x13, x7, x3, x24, ss0
mfu_act1_conf_dest x15, ss0
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 65536
addi x27, x27, 0
mfu_act1_compute x27, x17, x22, x10
ss_pack_stride x13, x13, x15, ss2
ss_pack_stride x13, x13, x14, ss3
l2_store_conf ss3, ss2, fp16, fp32
ss_pack_shape x13, x13, x13, x15, ss4
ccr_decl x13
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss4
ss_pack_stride x13, x13, x14, ss3
ss_pack_stride x13, x13, x19, ss5
l2_load_conf ss5, ss3, i8, i8
ss_pack_shape x13, x13, x13, x19, ss7
ccr_decl x13
ccr_set 3, 1
lw x2, x0, 0
addi x30, x0, 384
add x30, x2, x30
lui x31, 131072
addi x31, x31, 384
l2_load x31, x30, ss7
ss_pack_stride x13, x13, x19, ss5
ss_pack_stride x13, x13, x3, ss6
l2_load_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x3, ss1
ccr_decl x13
ccr_set 4, 1
lw x1, x0, 8
addi x4, x0, 554
add x4, x1, x4
lui x5, 196608
addi x5, x5, 256
l2_load x5, x4, ss1
ss_pack_stride x13, x3, x24, ss0
ss_pack_stride x13, x3, x13, ss2
ss_pack_stride x7, x3, x24, ss4
mfu_act1_conf_stride ss0, ss2, ss4
mfu_act1_conf_src1 x19, x13, x13, 0, l2
ss_pack_shape x13, x13, x3, x24, ss3
mfu_act1_conf_src2 x13, ss3, 0, l2
mfu_act1_conf_src1 x3, x24, x13, 1, l2
ss_pack_shape x13, x13, x3, x13, ss7
mfu_act1_conf_src2 x13, ss7, 1, l2
ss_pack_shape x13, x13, x3, x24, ss3
mfu_act1_conf_dest x19, ss3
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x24
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x6, 65536
addi x6, x6, 768
lui x8, 262144
addi x8, x8, 28
mfu_act1_compute x6, x31, x5, x8
ss_pack_stride x13, x13, x15, ss5
ss_pack_stride x13, x13, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x19, ss1
ccr_decl x13
ccr_clr 5
lw x11, x0, 4
addi x9, x0, 1536
add x9, x11, x9
l2_store x9, x6, ss1
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 810
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# case: test_binary[rhs_shape11-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
mmu_conf x5, x1, 3
addi x6, x0, 608
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x15, x0, 8
ss_pack_shape x15, x13, x13, x2, ss2
ccr_decl x13
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
ss_pack_stride x13, x13, x4, ss3
addi x19, x0, 128
ss_pack_stride x13, x13, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x13, x13, x13, x19, ss5
ccr_decl x13
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
addi x24, x0, 3
ss_pack_stride x7, x23, x24, ss6
ss_pack_stride x7, x23, x13, ss7
ss_pack_stride x7, x23, x24, ss6
mfu_act1_conf_stride ss6, ss7, ss6
lui x25, 1
addi x25, x25, 3072
mfu_act1_conf_src1 x25, x13, x13, 0, l2
ss_pack_shape x15, x7, x23, x24, ss0
mfu_act1_conf_src2 x13, ss0, 0, l2
mfu_act1_conf_src1 x19, x24, x13, 1, l2
ss_pack_shape x13, x7, x23, x13, ss1
mfu_act1_conf_src2 x15, ss1, 1, l2
ss_pack_shape x15, x7, x23, x24, ss0
mfu_act1_conf_dest x25, ss0
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x17, x21, x10
ss_pack_stride x13, x13, x2, ss2
ss_pack_stride x13, x13, x14, ss3
l2_store_conf ss3, ss2, fp16, fp32
ss_pack_shape x15, x13, x13, x2, ss4
ccr_decl x13
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
ss_pack_stride x13, x13, x14, ss3
ss_pack_stride x13, x13, x4, ss5
l2_load_conf ss5, ss3, i8, i8
ss_pack_shape x15, x13, x13, x4, ss7
ccr_decl x13
ccr_set 3, 1
lw x5, x0, 0
addi x31, x0, 384
add x31, x5, x31
lui x3, 131073
addi x3, x3, 3072
l2_load x3, x31, ss7
ss_pack_stride x13, x13, x4, ss5
ss_pack_stride x13, x13, x23, ss6
l2_load_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x23, ss1
ccr_decl x13
ccr_set 4, 1
lw x8, x0, 8
addi x1, x0, 554
add x1, x8, x1
lui x6, 196608
addi x6, x6, 256
l2_load x6, x1, ss1
ss_pack_stride x13, x23, x24, ss0
ss_pack_stride x13, x23, x13, ss2
ss_pack_stride x7, x23, x24, ss4
mfu_act1_conf_stride ss0, ss2, ss4
addi x9, x0, 1536
mfu_act1_conf_src1 x9, x13, x13, 0, l2
ss_pack_shape x15, x13, x23, x24, ss3
mfu_act1_conf_src2 x13, ss3, 0, l2
mfu_act1_conf_src1 x23, x24, x13, 1, l2
ss_pack_shape x13, x13, x23, x13, ss7
mfu_act1_conf_src2 x15, ss7, 1, l2
ss_pack_shape x15, x13, x23, x24, ss3
mfu_act1_conf_dest x9, ss3
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x24
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x11, 65538
addi x11, x11, 2048
lui x12, 262144
addi x12, x12, 28
mfu_act1_compute x11, x3, x6, x12
ss_pack_stride x13, x13, x2, ss5
ss_pack_stride x13, x13, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x15, x13, x13, x4, ss1
ccr_decl x13
ccr_clr 5
lw x18, x0, 4
addi x16, x0, 1536
add x16, x18, x16
l2_store x16, x11, ss1
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 810
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 742
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 743
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 810
add x15, x17, x15
lui x16, 196608
addi x16, x16, 128
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65538
addi x22, x22, 1024
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 852
add x23, x25, x23
lui x24, 196608
addi x24, x24, 64
l2_load_w x24, x23, x18
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x0, x24
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x29, x0, 12
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 196608
addi x28, x28, 0
l2_load_w x28, x27, x18
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
lui x30, 1
addi x30, x30, 512
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_set 3, 1
lw x3, x0, 0
lui x31, 0
addi x31, x31, 0
add x31, x3, x31
lui x1, 131072
addi x1, x1, 0
l2_load x1, x31, ss0
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x19, x20, x19, ss1
ss_pack_stride x19, x20, x19, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x10, x19, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
addi x4, x0, 8
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x30, x8, x8, 1, l2
ss_pack_shape x4, x19, x20, x19, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x4, x19, x20, x19, ss2
mfu_act1_conf_dest x30, ss2
addi x5, x0, 255
mfu_act1_conf_deq x26, x5, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x6, x0, 4
ccr_decl x6
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x22, x12, x1, x28
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_clr 2
lw x9, x0, 8
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
l2_store x7, x22, ss0
end x0
# case: test_binary[rhs_shape2-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 6
mmu_conf x1, x2, 1
addi x3, x0, 22
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 24
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 25
mmu_conf x7, x6, 4
addi x8, x0, 26
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x6, x9, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 2, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss2
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x9, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x6, ss2, 1, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_dest x9, ss2
lui x21, 2
addi x21, x21, 2990
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x23, x0, 4
ccr_decl x23
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x22, 131072
addi x22, x22, 32
mfu_act1_compute x22, x11, x19, x15
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 3
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x22, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 26
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 6
mmu_conf x1, x2, 1
addi x3, x0, 22
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 24
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 25
mmu_conf x7, x6, 4
addi x8, x0, 26
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 131072
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x6, x9, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 2, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss2
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x9, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x6, ss2, 1, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_dest x9, ss2
lui x21, 2
addi x21, x21, 2990
mfu_act1_conf_deq x21, x0, u8, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x23, x0, 4
ccr_decl x23
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x22, 131072
addi x22, x22, 32
mfu_act1_compute x22, x11, x19, x15
ss_pack_stride x6, x6, x9, ss3
ss_pack_stride x6, x6, x9, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 3
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x22, ss2
end x0
# case: test_binary[rhs_shape2-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 46
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 47
mmu_conf x7, x6, 4
addi x8, x0, 48
mmu_conf x8, x6, 5
addi x9, x0, 192
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
ss_pack_stride x6, x22, x18, ss6
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x22, x18, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x22, x18, ss7
mfu_act1_conf_src2 x6, ss7, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x18, ss5
mfu_act1_conf_src2 x22, ss5, 1, l2
ss_pack_shape x6, x6, x22, x18, ss7
mfu_act1_conf_dest x9, ss7
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x25, x0, 4
ccr_decl x25
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x6, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 3
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x24, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 26
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 46
addi x6, x0, 3
mmu_conf x5, x6, 3
addi x7, x0, 49
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 50
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x6, ss0
ss_pack_stride x8, x8, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x6, ss2
ccr_decl x8
ccr_set 0, 1
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x16, x0, 12
addi x14, x0, 40
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
ss_pack_stride x8, x8, x6, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x6, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_dest x6, ss2
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x22, x0, 12
addi x20, x0, 54
add x20, x22, x20
lui x21, 196608
addi x21, x21, 32
l2_load_w x21, x20, x17
ss_pack_stride x8, x8, x6, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x6, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_dest x6, ss2
lui x23, 2
addi x23, x23, 3076
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x19, x0, x21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 12
lui x24, 0
addi x24, x24, 0
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x17
addi x27, x0, 192
ss_pack_stride x8, x8, x27, ss4
ss_pack_stride x8, x8, x27, ss5
l2_load_conf ss5, ss4, i8, i8
ss_pack_shape x8, x8, x8, x27, ss6
ccr_decl x8
ccr_set 3, 1
lw x30, x0, 0
lui x28, 0
addi x28, x28, 0
add x28, x30, x28
lui x29, 131072
addi x29, x29, 0
l2_load x29, x28, ss6
ss_pack_stride x8, x8, x6, ss1
addi x31, x0, 64
ss_pack_stride x8, x31, x6, ss7
ss_pack_stride x8, x31, x6, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x6, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x6, ss2
mfu_act1_conf_src2 x31, ss2, 0, l2
mfu_act1_conf_src1 x27, x8, x8, 1, l2
ss_pack_shape x8, x8, x31, x6, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x8, x31, x6, ss0
mfu_act1_conf_dest x27, ss0
addi x1, x0, 255
mfu_act1_conf_deq x23, x1, u8, 0
mfu_act1_conf_deq x23, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x2, x0, 4
ccr_decl x2
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x19, x11, x29, x25
ss_pack_stride x8, x8, x27, ss5
ss_pack_stride x8, x8, x27, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x27, ss6
ccr_decl x8
ccr_clr 2
lw x4, x0, 8
lui x3, 0
addi x3, x3, 0
add x3, x4, x3
l2_store x3, x19, ss6
end x0
# case: test_binary[rhs_shape2-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 94
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 96
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 97
mmu_conf x9, x8, 5
addi x10, x0, 576
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
ss_pack_stride x19, x23, x19, ss6
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x19, x23, x19, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x23, x19, ss7
mfu_act1_conf_src2 x8, ss7, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x19, ss5
addi x24, x0, 192
mfu_act1_conf_src2 x24, ss5, 1, l2
ss_pack_shape x8, x19, x23, x19, ss7
mfu_act1_conf_dest x10, ss7
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 54
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 18
mmu_conf x3, x4, 2
addi x5, x0, 106
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 110
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 111
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 96
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x23, x0, 12
addi x21, x0, 110
add x21, x23, x21
lui x22, 196608
addi x22, x22, 64
l2_load_w x22, x21, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x20, x0, x22
addi x25, x0, 21
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x28, x0, 12
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
addi x29, x0, 576
ss_pack_stride x8, x8, x29, ss4
ss_pack_stride x8, x8, x29, ss5
l2_load_conf ss5, ss4, i8, i8
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_set 3, 1
lw x1, x0, 0
lui x30, 0
addi x30, x30, 0
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load x31, x30, ss6
ss_pack_stride x8, x8, x10, ss1
addi x2, x0, 64
ss_pack_stride x10, x2, x10, ss7
ss_pack_stride x10, x2, x10, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x3, x0, 192
mfu_act1_conf_src2 x3, ss2, 0, l2
mfu_act1_conf_src1 x29, x8, x8, 1, l2
ss_pack_shape x8, x10, x2, x10, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x10, x2, x10, ss0
mfu_act1_conf_dest x29, ss0
addi x4, x0, 255
mfu_act1_conf_deq x24, x4, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x20, x12, x31, x27
ss_pack_stride x8, x8, x29, ss5
ss_pack_stride x8, x8, x29, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_clr 2
lw x7, x0, 8
lui x5, 0
addi x5, x5, 0
add x5, x7, x5
l2_store x5, x20, ss6
end x0
# case: test_binary[rhs_shape2-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 288
mmu_conf x3, x4, 2
addi x5, x0, 880
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 882
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 196608
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, i8, i8
lui x14, 1
addi x14, x14, 512
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 3
ss_pack_stride x8, x8, x18, ss3
ss_pack_stride x8, x8, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x18, ss5
ccr_decl x8
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 262144
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
ss_pack_stride x18, x22, x18, ss6
ss_pack_stride x8, x8, x18, ss4
ss_pack_stride x18, x22, x18, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x14, x8, x8, 0, l2
addi x23, x0, 8
ss_pack_shape x23, x18, x22, x18, ss7
mfu_act1_conf_src2 x8, ss7, 0, l2
mfu_act1_conf_src1 x18, x8, x8, 1, l2
ss_pack_shape x8, x8, x8, x18, ss5
addi x24, x0, 1536
mfu_act1_conf_src2 x24, ss5, 1, l2
ss_pack_shape x23, x18, x22, x18, ss7
mfu_act1_conf_dest x14, ss7
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 65536
addi x27, x27, 0
mfu_act1_compute x27, x16, x20, x11
ss_pack_stride x8, x8, x2, ss1
ss_pack_stride x8, x8, x2, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss2
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 54
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 740
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 741
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 96
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 1024
mfu_act1_compute x20, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x23, x0, 12
addi x21, x0, 110
add x21, x23, x21
lui x22, 196608
addi x22, x22, 64
l2_load_w x22, x21, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x8, x8, x10, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x8, ss2, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x8, ss3, 1, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_dest x10, ss2
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x10
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x20, x0, x22
addi x25, x0, 21
l2_load_w_conf x25, x25, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x28, x0, 12
lui x26, 0
addi x26, x26, 0
add x26, x28, x26
lui x27, 196608
addi x27, x27, 0
l2_load_w x27, x26, x18
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss5
l2_load_conf ss5, ss4, i8, i8
lui x29, 1
addi x29, x29, 512
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_set 3, 1
lw x1, x0, 0
lui x30, 0
addi x30, x30, 0
add x30, x1, x30
lui x31, 131072
addi x31, x31, 0
l2_load x31, x30, ss6
ss_pack_stride x8, x8, x10, ss1
addi x3, x0, 64
ss_pack_stride x10, x3, x10, ss7
ss_pack_stride x10, x3, x10, ss7
mfu_act1_conf_stride ss1, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x4, x0, 1536
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x29, x8, x8, 1, l2
addi x5, x0, 8
ss_pack_shape x5, x10, x3, x10, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x5, x10, x3, x10, ss0
mfu_act1_conf_dest x29, ss0
addi x6, x0, 255
mfu_act1_conf_deq x24, x6, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x7, x0, 4
ccr_decl x7
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x20, x12, x31, x27
ss_pack_stride x8, x8, x2, ss5
ss_pack_stride x8, x8, x2, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x8, x8, x8, x29, ss6
ccr_decl x8
ccr_clr 2
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
l2_store x9, x20, ss6
end x0
# case: test_binary[rhs_shape3-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 46
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 64
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x18, x6, ss6
ss_pack_stride x6, x18, x9, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x18, ss2, 0, l2
mfu_act1_conf_src1 x18, x9, x6, 1, l2
ss_pack_shape x6, x6, x18, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x6, x6, x18, x9, ss3
addi x22, x0, 192
mfu_act1_conf_dest x22, ss3
lui x23, 2
addi x23, x23, 3006
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x22, ss4
ss_pack_stride x6, x6, x22, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x22, ss5
ccr_decl x6
ccr_clr 3
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x24, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 270
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 46
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 64
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x18, x6, ss6
ss_pack_stride x6, x18, x9, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x18, ss2, 0, l2
mfu_act1_conf_src1 x18, x9, x6, 1, l2
ss_pack_shape x6, x6, x18, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x6, x6, x18, x9, ss3
addi x22, x0, 192
mfu_act1_conf_dest x22, ss3
lui x23, 2
addi x23, x23, 3006
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x22, ss4
ss_pack_stride x6, x6, x22, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x22, ss5
ccr_decl x6
ccr_clr 3
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x24, ss5
end x0
# case: test_binary[rhs_shape3-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 46
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 47
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 32
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 64
addi x20, x0, 3
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 384
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 8
addi x23, x0, 14
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
ss_pack_stride x8, x8, x19, ss6
ss_pack_stride x8, x8, x19, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss0
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 28
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss0
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x8, x19, x8, ss1
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x19, x20, x8, 1, l2
ss_pack_shape x8, x8, x19, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3074
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x27, x24
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss6
end x0
# case: test_binary[rhs_shape3-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 92
mmu_conf x5, x4, 3
addi x6, x0, 96
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 97
mmu_conf x8, x7, 5
addi x9, x0, 576
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss2
ccr_decl x7
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 21
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 64
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 64
ss_pack_stride x18, x19, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x19, x18, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x7, x18, x19, x18, ss5
mfu_act1_conf_dest x9, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x21, 65536
addi x21, x21, 1152
mfu_act1_compute x21, x11, x0, x15
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 196608
addi x23, x23, 0
l2_load_w x23, x22, x17
ss_pack_stride x7, x7, x19, ss6
ss_pack_stride x7, x7, x19, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x7, x7, x7, x19, ss0
ccr_decl x7
ccr_set 3, 1
lw x27, x0, 8
addi x25, x0, 84
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load x26, x25, ss0
ss_pack_stride x18, x19, x18, ss3
ss_pack_stride x7, x19, x7, ss1
ss_pack_stride x18, x19, x18, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x9, x7, x7, 0, l2
ss_pack_shape x7, x18, x19, x18, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x19, x18, x7, 1, l2
ss_pack_shape x7, x7, x19, x7, ss2
mfu_act1_conf_src2 x18, ss2, 1, l2
ss_pack_shape x7, x18, x19, x18, ss5
mfu_act1_conf_dest x9, ss5
lui x28, 2
addi x28, x28, 3076
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x11, x21, x26, x23
ss_pack_stride x7, x7, x9, ss4
ss_pack_stride x7, x7, x9, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x9, ss6
ccr_decl x7
ccr_clr 0
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x11, ss6
end x0
# case: test_binary[rhs_shape3-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 288
mmu_conf x3, x4, 2
addi x5, x0, 880
addi x6, x0, 8
mmu_conf x5, x6, 3
addi x7, x0, 888
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
lui x15, 1
addi x15, x15, 512
ss_pack_shape x14, x14, x14, x15, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 64
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x14, x14, x14, x19, ss5
ccr_decl x14
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 3
ss_pack_stride x23, x19, x23, ss6
ss_pack_stride x14, x19, x14, ss7
ss_pack_stride x23, x19, x23, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x15, x14, x14, 0, l2
ss_pack_shape x6, x23, x19, x23, ss0
mfu_act1_conf_src2 x14, ss0, 0, l2
mfu_act1_conf_src1 x19, x23, x14, 1, l2
ss_pack_shape x14, x14, x19, x14, ss1
addi x24, x0, 24
mfu_act1_conf_src2 x24, ss1, 1, l2
ss_pack_shape x6, x23, x19, x23, ss0
mfu_act1_conf_dest x15, ss0
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 65536
addi x27, x27, 0
mfu_act1_compute x27, x17, x21, x11
ss_pack_stride x14, x14, x2, ss2
ss_pack_stride x14, x14, x2, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x14, x14, x14, x15, ss3
ccr_decl x14
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss3
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 298
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 740
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 741
mmu_conf x9, x8, 5
addi x10, x0, 64
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 340
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x10, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x10, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x10, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x10, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x21, x0, 3
ccr_decl x21
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 1024
mfu_act1_compute x20, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x24, x0, 12
addi x22, x0, 354
add x22, x24, x22
lui x23, 196608
addi x23, x23, 64
l2_load_w x23, x22, x18
ss_pack_stride x8, x10, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x10, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x10, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x10, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x21
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x20, x0, x23
addi x26, x0, 21
l2_load_w_conf x26, x26, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x29, x0, 12
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 196608
addi x28, x28, 0
l2_load_w x28, x27, x18
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
lui x30, 1
addi x30, x30, 512
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_set 3, 1
lw x3, x0, 0
lui x31, 0
addi x31, x31, 0
add x31, x3, x31
lui x1, 131072
addi x1, x1, 0
l2_load x1, x31, ss0
ss_pack_stride x8, x10, x8, ss3
ss_pack_stride x21, x10, x21, ss1
ss_pack_stride x21, x10, x21, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x10, x21, x8, 0, l2
ss_pack_shape x8, x8, x10, x8, ss5
addi x4, x0, 24
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x30, x8, x8, 1, l2
addi x5, x0, 8
ss_pack_shape x5, x21, x10, x21, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x5, x21, x10, x21, ss2
mfu_act1_conf_dest x30, ss2
addi x6, x0, 255
mfu_act1_conf_deq x25, x6, u8, 0
mfu_act1_conf_deq x25, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x7, x0, 4
ccr_decl x7
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x20, x12, x1, x28
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_clr 2
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
l2_store x9, x20, ss0
end x0
# case: test_binary[rhs_shape4-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 52
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 53
mmu_conf x7, x6, 4
addi x8, x0, 54
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 192
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x6, x9, ss1
addi x22, x0, 64
ss_pack_stride x6, x22, x9, ss6
ss_pack_stride x6, x22, x9, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x22, ss2, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x22, x9, ss7
mfu_act1_conf_src2 x6, ss7, 1, l2
ss_pack_shape x6, x6, x22, x9, ss7
mfu_act1_conf_dest x18, ss7
lui x23, 2
addi x23, x23, 3071
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x25, x0, 4
ccr_decl x25
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x6, x18, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_clr 3
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x24, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 782
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 52
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 53
mmu_conf x7, x6, 4
addi x8, x0, 54
mmu_conf x8, x6, 5
addi x9, x0, 3
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 192
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x6, x9, ss1
addi x22, x0, 64
ss_pack_stride x6, x22, x9, ss6
ss_pack_stride x6, x22, x9, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x9, ss2
mfu_act1_conf_src2 x22, ss2, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x22, x9, ss7
mfu_act1_conf_src2 x6, ss7, 1, l2
ss_pack_shape x6, x6, x22, x9, ss7
mfu_act1_conf_dest x18, ss7
lui x23, 2
addi x23, x23, 3071
mfu_act1_conf_deq x23, x0, u8, 0
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x25, x0, 4
ccr_decl x25
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65536
addi x24, x24, 384
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x6, x18, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_clr 3
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x24, ss5
end x0
# case: test_binary[rhs_shape4-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 52
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 54
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 55
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 32
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 64
addi x20, x0, 3
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 384
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 8
addi x23, x0, 14
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 28
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss2
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x10, x8, x8, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3075
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x27, x24
ss_pack_stride x8, x8, x10, ss6
ss_pack_stride x8, x8, x10, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss2
end x0
# case: test_binary[rhs_shape4-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 104
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 105
mmu_conf x9, x8, 5
addi x10, x0, 576
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1152
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
addi x26, x0, 192
ss_pack_stride x8, x8, x26, ss6
ss_pack_stride x8, x8, x26, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x26, ss0
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 8
addi x27, x0, 84
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss0
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x8, x20, x19, ss1
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x26, x8, x8, 1, l2
ss_pack_shape x8, x8, x20, x19, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
mfu_act1_conf_deq x30, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x28, x24
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss6
end x0
# case: test_binary[rhs_shape4-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 288
mmu_conf x3, x4, 2
addi x5, x0, 880
addi x6, x0, 24
mmu_conf x5, x6, 3
addi x7, x0, 904
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
lui x15, 1
addi x15, x15, 512
ss_pack_shape x14, x14, x14, x15, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 192
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x14, x14, x14, x19, ss5
ccr_decl x14
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 3
addi x24, x0, 64
ss_pack_stride x23, x24, x23, ss6
ss_pack_stride x14, x24, x23, ss7
ss_pack_stride x23, x24, x23, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x15, x14, x14, 0, l2
addi x25, x0, 8
ss_pack_shape x25, x23, x24, x23, ss0
mfu_act1_conf_src2 x14, ss0, 0, l2
mfu_act1_conf_src1 x19, x14, x14, 1, l2
ss_pack_shape x14, x14, x24, x23, ss1
mfu_act1_conf_src2 x6, ss1, 1, l2
ss_pack_shape x25, x23, x24, x23, ss0
mfu_act1_conf_dest x15, ss0
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x17, x21, x11
ss_pack_stride x14, x14, x2, ss2
ss_pack_stride x14, x14, x2, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x14, x14, x14, x15, ss3
ccr_decl x14
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss3
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 810
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 740
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 741
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 7
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 852
add x15, x17, x15
lui x16, 196608
addi x16, x16, 96
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 64
addi x20, x0, 3
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65538
addi x22, x22, 1024
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 866
add x23, x25, x23
lui x24, 196608
addi x24, x24, 64
l2_load_w x24, x23, x18
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x8, x19, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x8, x19, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x0, x24
addi x27, x0, 21
l2_load_w_conf x27, x27, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x30, x0, 12
lui x28, 0
addi x28, x28, 0
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x18
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
lui x31, 1
addi x31, x31, 512
ss_pack_shape x8, x8, x8, x31, ss0
ccr_decl x8
ccr_set 3, 1
lw x4, x0, 0
lui x1, 0
addi x1, x1, 0
add x1, x4, x1
lui x3, 131072
addi x3, x3, 0
l2_load x3, x1, ss0
ss_pack_stride x8, x19, x20, ss3
ss_pack_stride x20, x19, x20, ss1
ss_pack_stride x20, x19, x20, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x19, x20, ss5
addi x5, x0, 24
mfu_act1_conf_src2 x5, ss5, 0, l2
mfu_act1_conf_src1 x31, x8, x8, 1, l2
addi x6, x0, 8
ss_pack_shape x6, x20, x19, x20, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x6, x20, x19, x20, ss2
mfu_act1_conf_dest x31, ss2
addi x7, x0, 255
mfu_act1_conf_deq x26, x7, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x9, x0, 4
ccr_decl x9
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x22, x12, x3, x29
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x31, ss0
ccr_decl x8
ccr_clr 2
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x22, ss0
end x0
# case: test_binary[rhs_shape5-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 102
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 103
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 192
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
ss_pack_stride x8, x8, x10, ss1
addi x23, x0, 64
ss_pack_stride x10, x23, x8, ss6
ss_pack_stride x10, x23, x10, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x19, ss2, 0, l2
mfu_act1_conf_src1 x19, x10, x8, 1, l2
ss_pack_shape x8, x10, x23, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x10, x23, x10, ss3
addi x24, x0, 576
mfu_act1_conf_dest x24, ss3
lui x25, 2
addi x25, x25, 3022
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x24, ss4
ss_pack_stride x8, x8, x24, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x24, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 810
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 102
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 103
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 192
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
ss_pack_stride x8, x8, x10, ss1
addi x23, x0, 64
ss_pack_stride x10, x23, x8, ss6
ss_pack_stride x10, x23, x10, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
mfu_act1_conf_src2 x19, ss2, 0, l2
mfu_act1_conf_src1 x19, x10, x8, 1, l2
ss_pack_shape x8, x10, x23, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x10, x23, x10, ss3
addi x24, x0, 576
mfu_act1_conf_dest x24, ss3
lui x25, 2
addi x25, x25, 3022
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x24, ss4
ss_pack_stride x8, x8, x24, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x24, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# case: test_binary[rhs_shape5-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 102
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 103
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss2
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x8, x22, x23, ss4
ss_pack_stride x23, x22, x8, ss5
ss_pack_stride x23, x22, x23, ss6
mfu_act1_conf_stride ss4, ss5, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x22, x23, ss7
mfu_act1_conf_src2 x23, ss7, 0, l2
mfu_act1_conf_src1 x10, x23, x8, 1, l2
ss_pack_shape x8, x23, x22, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x23, x22, x23, ss1
addi x24, x0, 576
mfu_act1_conf_dest x24, ss1
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x20, x16
ss_pack_stride x8, x8, x24, ss3
ss_pack_stride x8, x8, x24, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x24, ss2
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 810
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 102
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 103
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss3
l2_load_conf ss3, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss2
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x8, x22, x23, ss4
ss_pack_stride x23, x22, x8, ss5
ss_pack_stride x23, x22, x23, ss6
mfu_act1_conf_stride ss4, ss5, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x22, x23, ss7
mfu_act1_conf_src2 x23, ss7, 0, l2
mfu_act1_conf_src1 x10, x23, x8, 1, l2
ss_pack_shape x8, x23, x22, x8, ss0
mfu_act1_conf_src2 x8, ss0, 1, l2
ss_pack_shape x8, x23, x22, x23, ss1
addi x24, x0, 576
mfu_act1_conf_dest x24, ss1
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x20, x16
ss_pack_stride x8, x8, x24, ss3
ss_pack_stride x8, x8, x24, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x24, ss2
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss2
end x0
# case: test_binary[rhs_shape5-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 100
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 104
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 105
mmu_conf x9, x8, 5
addi x10, x0, 576
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1152
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
addi x26, x0, 192
ss_pack_stride x8, x8, x26, ss6
ss_pack_stride x8, x8, x26, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x26, ss0
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 8
addi x27, x0, 84
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss0
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x8, ss1
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x26, x19, x8, 1, l2
ss_pack_shape x8, x19, x20, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
mfu_act1_conf_deq x30, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x28, x24
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss6
end x0
# case: test_binary[rhs_shape5-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
mmu_conf x5, x1, 3
addi x6, x0, 608
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x15, x0, 8
ss_pack_shape x15, x13, x13, x2, ss2
ccr_decl x13
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
ss_pack_stride x13, x13, x4, ss3
addi x19, x0, 128
ss_pack_stride x13, x13, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x13, x13, x13, x19, ss5
ccr_decl x13
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 196608
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
addi x24, x0, 3
ss_pack_stride x7, x23, x24, ss6
ss_pack_stride x7, x23, x13, ss7
ss_pack_stride x7, x23, x24, ss6
mfu_act1_conf_stride ss6, ss7, ss6
lui x25, 1
addi x25, x25, 3072
mfu_act1_conf_src1 x25, x13, x13, 0, l2
ss_pack_shape x15, x7, x23, x24, ss0
mfu_act1_conf_src2 x13, ss0, 0, l2
mfu_act1_conf_src1 x19, x24, x13, 1, l2
ss_pack_shape x13, x7, x23, x13, ss1
mfu_act1_conf_src2 x15, ss1, 1, l2
ss_pack_shape x15, x7, x23, x24, ss0
mfu_act1_conf_dest x25, ss0
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x24
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x17, x21, x10
ss_pack_stride x13, x13, x2, ss2
ss_pack_stride x13, x13, x14, ss3
l2_store_conf ss3, ss2, fp16, fp32
ss_pack_shape x15, x13, x13, x2, ss4
ccr_decl x13
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
ss_pack_stride x13, x13, x14, ss3
ss_pack_stride x13, x13, x4, ss5
l2_load_conf ss5, ss3, i8, i8
ss_pack_shape x15, x13, x13, x4, ss7
ccr_decl x13
ccr_set 3, 1
lw x5, x0, 0
addi x31, x0, 384
add x31, x5, x31
lui x3, 131073
addi x3, x3, 3072
l2_load x3, x31, ss7
ss_pack_stride x13, x13, x4, ss5
ss_pack_stride x13, x13, x23, ss6
l2_load_conf ss6, ss5, fp16, fp32
ss_pack_shape x13, x13, x13, x23, ss1
ccr_decl x13
ccr_set 4, 1
lw x8, x0, 8
addi x1, x0, 554
add x1, x8, x1
lui x6, 196608
addi x6, x6, 256
l2_load x6, x1, ss1
ss_pack_stride x13, x23, x24, ss0
ss_pack_stride x13, x23, x13, ss2
ss_pack_stride x7, x23, x24, ss4
mfu_act1_conf_stride ss0, ss2, ss4
addi x9, x0, 1536
mfu_act1_conf_src1 x9, x13, x13, 0, l2
ss_pack_shape x15, x13, x23, x24, ss3
mfu_act1_conf_src2 x13, ss3, 0, l2
mfu_act1_conf_src1 x23, x24, x13, 1, l2
ss_pack_shape x13, x13, x23, x13, ss7
mfu_act1_conf_src2 x15, ss7, 1, l2
ss_pack_shape x15, x13, x23, x24, ss3
mfu_act1_conf_dest x9, ss3
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x24
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x11, 65538
addi x11, x11, 2048
lui x12, 262144
addi x12, x12, 28
mfu_act1_compute x11, x3, x6, x12
ss_pack_stride x13, x13, x2, ss5
ss_pack_stride x13, x13, x14, ss6
l2_store_conf ss6, ss5, fp16, fp32
ss_pack_shape x15, x13, x13, x4, ss1
ccr_decl x13
ccr_clr 5
lw x18, x0, 4
addi x16, x0, 1536
add x16, x18, x16
l2_store x16, x11, ss1
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 810
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 742
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 743
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 810
add x15, x17, x15
lui x16, 196608
addi x16, x16, 128
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65538
addi x22, x22, 1024
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 852
add x23, x25, x23
lui x24, 196608
addi x24, x24, 64
l2_load_w x24, x23, x18
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x8, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x8, ss5
mfu_act1_conf_dest x10, ss5
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x0, x24
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x29, x0, 12
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 196608
addi x28, x28, 0
l2_load_w x28, x27, x18
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
lui x30, 1
addi x30, x30, 512
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_set 3, 1
lw x3, x0, 0
lui x31, 0
addi x31, x31, 0
add x31, x3, x31
lui x1, 131072
addi x1, x1, 0
l2_load x1, x31, ss0
ss_pack_stride x19, x20, x8, ss3
ss_pack_stride x19, x20, x19, ss1
ss_pack_stride x19, x20, x19, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x10, x19, x8, 0, l2
ss_pack_shape x8, x19, x20, x8, ss5
addi x4, x0, 8
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x30, x8, x8, 1, l2
ss_pack_shape x4, x19, x20, x19, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x4, x19, x20, x19, ss2
mfu_act1_conf_dest x30, ss2
addi x5, x0, 255
mfu_act1_conf_deq x26, x5, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x6, x0, 4
ccr_decl x6
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x22, x12, x1, x28
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x30, ss0
ccr_decl x8
ccr_clr 2
lw x9, x0, 8
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
l2_store x7, x22, ss0
end x0
# case: test_binary[rhs_shape6-lhs_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 124
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 126
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 127
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 576
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
ss_pack_stride x8, x8, x10, ss1
addi x23, x0, 64
ss_pack_stride x10, x23, x10, ss6
ss_pack_stride x10, x23, x10, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x24, x0, 192
mfu_act1_conf_src2 x24, ss2, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x10, x23, x10, ss7
mfu_act1_conf_src2 x8, ss7, 1, l2
ss_pack_shape x8, x10, x23, x10, ss7
mfu_act1_conf_dest x19, ss7
lui x25, 2
addi x25, x25, 2945
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x8, x8, x19, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 1
addi x12, x12, 2346
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 124
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 126
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 127
mmu_conf x9, x8, 5
addi x10, x0, 3
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 576
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
ss_pack_stride x8, x8, x10, ss1
addi x23, x0, 64
ss_pack_stride x10, x23, x10, ss6
ss_pack_stride x10, x23, x10, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x8, x10, ss2
addi x24, x0, 192
mfu_act1_conf_src2 x24, ss2, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x10, x23, x10, ss7
mfu_act1_conf_src2 x8, ss7, 1, l2
ss_pack_shape x8, x10, x23, x10, ss7
mfu_act1_conf_dest x19, ss7
lui x25, 2
addi x25, x25, 2945
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x8, x8, x19, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# case: test_binary[rhs_shape6-lhs_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 124
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 126
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 127
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 576
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
addi x24, x0, 3
ss_pack_stride x8, x23, x24, ss6
ss_pack_stride x24, x23, x24, ss7
ss_pack_stride x24, x23, x24, ss7
mfu_act1_conf_stride ss6, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x23, x24, ss0
mfu_act1_conf_src2 x24, ss0, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x24, x23, x24, ss1
mfu_act1_conf_src2 x8, ss1, 1, l2
ss_pack_shape x8, x24, x23, x24, ss1
mfu_act1_conf_dest x19, ss1
lui x25, 2
addi x25, x25, 3075
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x8, x8, x19, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 1
addi x12, x12, 2346
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 124
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 126
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 127
mmu_conf x9, x8, 5
addi x10, x0, 192
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 576
ss_pack_stride x8, x8, x19, ss3
ss_pack_stride x8, x8, x19, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_set 2, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load x21, x20, ss5
addi x23, x0, 64
addi x24, x0, 3
ss_pack_stride x8, x23, x24, ss6
ss_pack_stride x24, x23, x24, ss7
ss_pack_stride x24, x23, x24, ss7
mfu_act1_conf_stride ss6, ss7, ss7
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x8, x23, x24, ss0
mfu_act1_conf_src2 x24, ss0, 0, l2
mfu_act1_conf_src1 x19, x8, x8, 1, l2
ss_pack_shape x8, x24, x23, x24, ss1
mfu_act1_conf_src2 x8, ss1, 1, l2
ss_pack_shape x8, x24, x23, x24, ss1
mfu_act1_conf_dest x19, ss1
lui x25, 2
addi x25, x25, 3075
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
addi x27, x0, 4
ccr_decl x27
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x26, 65536
addi x26, x26, 1152
mfu_act1_compute x26, x12, x21, x16
ss_pack_stride x8, x8, x19, ss4
ss_pack_stride x8, x8, x19, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x19, ss5
ccr_decl x8
ccr_clr 3
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x26, ss5
end x0
# case: test_binary[rhs_shape6-lhs_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 124
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 128
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 129
mmu_conf x9, x8, 5
addi x10, x0, 576
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65536
addi x22, x22, 1152
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 8
addi x23, x0, 42
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
ss_pack_stride x8, x8, x10, ss1
ss_pack_stride x8, x8, x10, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 3, 1
lw x28, x0, 8
addi x26, x0, 84
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load x27, x26, ss2
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x10, x8, x8, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 1, l2
ss_pack_shape x8, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x27, x24
ss_pack_stride x8, x8, x10, ss6
ss_pack_stride x8, x8, x10, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x12, ss2
end x0
# case: test_binary[rhs_shape6-lhs_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 36
mmu_conf x3, x4, 2
addi x5, x0, 628
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 632
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 633
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
lui x10, 1
addi x10, x10, 512
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x18
ss_pack_stride x8, x8, x2, ss1
ss_pack_stride x8, x8, x2, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x2, ss7
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 8
addi x27, x0, 84
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss7
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x2, x8, x8, 1, l2
ss_pack_shape x8, x19, x20, x19, ss0
mfu_act1_conf_src2 x21, ss0, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
mfu_act1_conf_deq x30, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x23, x28, x25
ss_pack_stride x8, x8, x2, ss2
ss_pack_stride x8, x8, x2, ss2
l2_store_conf ss2, ss2, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss4
ccr_decl x8
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss4
end x0
# case: test_binary[rhs_shape7-lhs_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 785
mmu_conf x7, x6, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 3
ss_pack_stride x6, x6, x13, ss0
ss_pack_stride x6, x6, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x13, ss2
ccr_decl x6
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x6, x6, x4, ss3
ss_pack_stride x6, x6, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x6, x6, x6, x17, ss5
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x6, x6, x13, ss1
addi x21, x0, 64
ss_pack_stride x13, x21, x6, ss6
ss_pack_stride x13, x21, x13, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x13, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x13, ss2
mfu_act1_conf_src2 x17, ss2, 0, l2
mfu_act1_conf_src1 x17, x13, x6, 1, l2
addi x22, x0, 8
ss_pack_shape x22, x13, x21, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x22, x13, x21, x13, ss3
lui x23, 1
addi x23, x23, 512
mfu_act1_conf_dest x23, ss3
lui x24, 2
addi x24, x24, 3044
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x13
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 65536
addi x26, x26, 0
mfu_act1_compute x26, x15, x19, x10
ss_pack_stride x6, x6, x2, ss4
ss_pack_stride x6, x6, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x23, ss5
ccr_decl x6
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 785
mmu_conf x7, x6, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 3
ss_pack_stride x6, x6, x13, ss0
ss_pack_stride x6, x6, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x13, ss2
ccr_decl x6
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x6, x6, x4, ss3
ss_pack_stride x6, x6, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x6, x6, x6, x17, ss5
ccr_decl x6
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss5
ss_pack_stride x6, x6, x13, ss1
addi x21, x0, 64
ss_pack_stride x13, x21, x6, ss6
ss_pack_stride x13, x21, x13, ss7
mfu_act1_conf_stride ss1, ss6, ss7
mfu_act1_conf_src1 x13, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x13, ss2
mfu_act1_conf_src2 x17, ss2, 0, l2
mfu_act1_conf_src1 x17, x13, x6, 1, l2
addi x22, x0, 8
ss_pack_shape x22, x13, x21, x6, ss0
mfu_act1_conf_src2 x6, ss0, 1, l2
ss_pack_shape x22, x13, x21, x13, ss3
lui x23, 1
addi x23, x23, 512
mfu_act1_conf_dest x23, ss3
lui x24, 2
addi x24, x24, 3044
mfu_act1_conf_deq x24, x0, u8, 0
lui x25, 4
addi x25, x25, 3072
mfu_act1_conf_deq x25, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x13
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x26, 65536
addi x26, x26, 0
mfu_act1_compute x26, x15, x19, x10
ss_pack_stride x6, x6, x2, ss4
ss_pack_stride x6, x6, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x23, ss5
ccr_decl x6
ccr_clr 2
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x26, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 2
addi x12, x12, 2090
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape7-lhs_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 12
mmu_conf x5, x6, 3
addi x7, x0, 796
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
ss_pack_stride x8, x8, x4, ss0
ss_pack_stride x8, x8, x4, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x4, ss2
ccr_decl x8
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x8, x8, x4, ss1
ss_pack_stride x8, x8, x4, ss3
l2_load_conf ss3, ss1, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x8, x8, x8, x17, ss4
ccr_decl x8
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss4
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x8, x21, x22, ss5
ss_pack_stride x22, x21, x8, ss6
ss_pack_stride x22, x21, x22, ss7
mfu_act1_conf_stride ss5, ss6, ss7
mfu_act1_conf_src1 x4, x8, x8, 0, l2
ss_pack_shape x8, x8, x21, x22, ss0
addi x23, x0, 24
mfu_act1_conf_src2 x23, ss0, 0, l2
mfu_act1_conf_src1 x17, x22, x8, 1, l2
addi x24, x0, 8
ss_pack_shape x24, x22, x21, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x24, x22, x21, x22, ss1
lui x25, 1
addi x25, x25, 512
mfu_act1_conf_dest x25, ss1
lui x26, 2
addi x26, x26, 3075
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x15, x19, x11
ss_pack_stride x8, x8, x2, ss3
ss_pack_stride x8, x8, x2, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss4
ccr_decl x8
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 784
addi x6, x0, 12
mmu_conf x5, x6, 3
addi x7, x0, 796
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
ss_pack_stride x8, x8, x4, ss0
ss_pack_stride x8, x8, x4, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x4, ss2
ccr_decl x8
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x8, x8, x4, ss1
ss_pack_stride x8, x8, x4, ss3
l2_load_conf ss3, ss1, fp16, fp32
addi x17, x0, 1536
ss_pack_shape x8, x8, x8, x17, ss4
ccr_decl x8
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load x19, x18, ss4
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x8, x21, x22, ss5
ss_pack_stride x22, x21, x8, ss6
ss_pack_stride x22, x21, x22, ss7
mfu_act1_conf_stride ss5, ss6, ss7
mfu_act1_conf_src1 x4, x8, x8, 0, l2
ss_pack_shape x8, x8, x21, x22, ss0
addi x23, x0, 24
mfu_act1_conf_src2 x23, ss0, 0, l2
mfu_act1_conf_src1 x17, x22, x8, 1, l2
addi x24, x0, 8
ss_pack_shape x24, x22, x21, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x24, x22, x21, x22, ss1
lui x25, 1
addi x25, x25, 512
mfu_act1_conf_dest x25, ss1
lui x26, 2
addi x26, x26, 3075
mfu_act1_conf_deq x26, x0, u8, 0
lui x27, 4
addi x27, x27, 3072
mfu_act1_conf_deq x27, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x28, 65536
addi x28, x28, 0
mfu_act1_compute x28, x15, x19, x11
ss_pack_stride x8, x8, x2, ss3
ss_pack_stride x8, x8, x2, ss3
l2_store_conf ss3, ss3, fp16, fp32
ss_pack_shape x8, x8, x8, x25, ss4
ccr_decl x8
ccr_clr 2
lw x30, x0, 4
lui x29, 0
addi x29, x29, 0
add x29, x30, x29
l2_store x29, x28, ss4
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 2
addi x12, x12, 2090
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# case: test_binary[rhs_shape7-lhs_shape2]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 128
mmu_conf x3, x4, 2
addi x5, x0, 528
addi x6, x0, 24
mmu_conf x5, x6, 3
addi x7, x0, 552
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
addi x15, x0, 576
ss_pack_stride x14, x14, x15, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 192
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x20, x0, 8
ss_pack_shape x20, x14, x14, x4, ss5
ccr_decl x14
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 64
addi x25, x0, 3
ss_pack_stride x8, x24, x25, ss6
ss_pack_stride x8, x24, x14, ss7
ss_pack_stride x8, x24, x25, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x8, x24, x25, ss0
mfu_act1_conf_src2 x20, ss0, 0, l2
addi x26, x0, 1024
mfu_act1_conf_src1 x26, x25, x14, 1, l2
ss_pack_shape x20, x8, x24, x14, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x20, x8, x24, x25, ss2
lui x27, 1
addi x27, x27, 3072
mfu_act1_conf_dest x27, ss2
lui x28, 2
addi x28, x28, 3076
mfu_act1_conf_deq x28, x0, u8, 0
lui x29, 4
addi x29, x29, 3072
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x30, 65536
addi x30, x30, 0
mfu_act1_compute x30, x17, x22, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x15, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x20, x14, x14, x2, ss5
ccr_decl x14
ccr_clr 2
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x30, ss5
ss_pack_stride x14, x14, x15, ss4
ss_pack_stride x14, x14, x19, ss7
l2_load_conf ss7, ss4, i8, i8
ss_pack_shape x14, x14, x14, x19, ss6
ccr_decl x14
ccr_set 3, 1
lw x6, x0, 0
addi x3, x0, 384
add x3, x6, x3
lui x5, 196608
addi x5, x5, 384
l2_load x5, x3, ss6
ss_pack_stride x14, x14, x19, ss7
ss_pack_stride x14, x14, x24, ss0
l2_load_conf ss0, ss7, fp16, fp32
ss_pack_shape x20, x14, x14, x24, ss1
ccr_decl x14
ccr_set 4, 1
lw x10, x0, 8
addi x7, x0, 554
add x7, x10, x7
lui x9, 131073
addi x9, x9, 2048
l2_load x9, x7, ss1
ss_pack_stride x14, x24, x25, ss2
ss_pack_stride x14, x24, x14, ss3
ss_pack_stride x8, x24, x25, ss5
mfu_act1_conf_stride ss2, ss3, ss5
mfu_act1_conf_src1 x19, x14, x14, 0, l2
ss_pack_shape x14, x14, x24, x25, ss4
mfu_act1_conf_src2 x20, ss4, 0, l2
addi x12, x0, 512
mfu_act1_conf_src1 x12, x25, x14, 1, l2
ss_pack_shape x20, x14, x24, x14, ss6
mfu_act1_conf_src2 x14, ss6, 1, l2
ss_pack_shape x20, x14, x24, x25, ss7
addi x13, x0, 1536
mfu_act1_conf_dest x13, ss7
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x25
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x16, 65538
addi x16, x16, 2048
lui x18, 262144
addi x18, x18, 28
mfu_act1_compute x16, x5, x9, x18
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x15, ss1
l2_store_conf ss1, ss0, fp16, fp32
ss_pack_shape x20, x14, x14, x19, ss2
ccr_decl x14
ccr_clr 5
lw x21, x0, 4
addi x4, x0, 1536
add x4, x21, x4
l2_store x4, x16, ss2
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 128
mmu_conf x3, x4, 2
addi x5, x0, 528
addi x6, x0, 24
mmu_conf x5, x6, 3
addi x7, x0, 552
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
addi x15, x0, 576
ss_pack_stride x14, x14, x15, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 196608
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 192
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x4, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x20, x0, 8
ss_pack_shape x20, x14, x14, x4, ss5
ccr_decl x14
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 64
addi x25, x0, 3
ss_pack_stride x8, x24, x25, ss6
ss_pack_stride x8, x24, x14, ss7
ss_pack_stride x8, x24, x25, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x8, x24, x25, ss0
mfu_act1_conf_src2 x20, ss0, 0, l2
addi x26, x0, 1024
mfu_act1_conf_src1 x26, x25, x14, 1, l2
ss_pack_shape x20, x8, x24, x14, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x20, x8, x24, x25, ss2
lui x27, 1
addi x27, x27, 3072
mfu_act1_conf_dest x27, ss2
lui x28, 2
addi x28, x28, 3076
mfu_act1_conf_deq x28, x0, u8, 0
lui x29, 4
addi x29, x29, 3072
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x30, 65536
addi x30, x30, 0
mfu_act1_compute x30, x17, x22, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x15, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x20, x14, x14, x2, ss5
ccr_decl x14
ccr_clr 2
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x30, ss5
ss_pack_stride x14, x14, x15, ss4
ss_pack_stride x14, x14, x19, ss7
l2_load_conf ss7, ss4, i8, i8
ss_pack_shape x14, x14, x14, x19, ss6
ccr_decl x14
ccr_set 3, 1
lw x6, x0, 0
addi x3, x0, 384
add x3, x6, x3
lui x5, 196608
addi x5, x5, 384
l2_load x5, x3, ss6
ss_pack_stride x14, x14, x19, ss7
ss_pack_stride x14, x14, x24, ss0
l2_load_conf ss0, ss7, fp16, fp32
ss_pack_shape x20, x14, x14, x24, ss1
ccr_decl x14
ccr_set 4, 1
lw x10, x0, 8
addi x7, x0, 554
add x7, x10, x7
lui x9, 131073
addi x9, x9, 2048
l2_load x9, x7, ss1
ss_pack_stride x14, x24, x25, ss2
ss_pack_stride x14, x24, x14, ss3
ss_pack_stride x8, x24, x25, ss5
mfu_act1_conf_stride ss2, ss3, ss5
mfu_act1_conf_src1 x19, x14, x14, 0, l2
ss_pack_shape x14, x14, x24, x25, ss4
mfu_act1_conf_src2 x20, ss4, 0, l2
addi x12, x0, 512
mfu_act1_conf_src1 x12, x25, x14, 1, l2
ss_pack_shape x20, x14, x24, x14, ss6
mfu_act1_conf_src2 x14, ss6, 1, l2
ss_pack_shape x20, x14, x24, x25, ss7
addi x13, x0, 1536
mfu_act1_conf_dest x13, ss7
mfu_act1_conf_deq x28, x0, u8, 0
mfu_act1_conf_deq x29, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x25
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x16, 65538
addi x16, x16, 2048
lui x18, 262144
addi x18, x18, 28
mfu_act1_compute x16, x5, x9, x18
ss_pack_stride x14, x14, x2, ss0
ss_pack_stride x14, x14, x15, ss1
l2_store_conf ss1, ss0, fp16, fp32
ss_pack_shape x20, x14, x14, x19, ss2
ccr_decl x14
ccr_clr 5
lw x21, x0, 4
addi x4, x0, 1536
add x4, x21, x4
l2_store x4, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 2
addi x13, x13, 2090
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# case: test_binary[rhs_shape7-lhs_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 688
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 692
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 693
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
lui x10, 1
addi x10, x10, 512
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x18
addi x27, x0, 192
ss_pack_stride x8, x8, x27, ss6
ss_pack_stride x8, x8, x27, ss7
l2_load_conf ss7, ss6, fp16, fp32
addi x28, x0, 1536
ss_pack_shape x8, x8, x8, x28, ss0
ccr_decl x8
ccr_set 3, 1
lw x31, x0, 8
addi x29, x0, 84
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load x30, x29, ss0
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x8, ss1
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x28, x19, x8, 1, l2
ss_pack_shape x21, x19, x20, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x1, 2
addi x1, x1, 3076
mfu_act1_conf_deq x1, x0, u8, 0
mfu_act1_conf_deq x1, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x23, x30, x25
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x4, x0, 4
lui x3, 0
addi x3, x3, 0
add x3, x4, x3
l2_store x3, x12, ss6
end x0
# case: test_binary[rhs_shape8-lhs_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
mmu_conf x3, x2, 2
addi x4, x0, 1168
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 1169
mmu_conf x6, x5, 4
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
ss_pack_stride x5, x5, x2, ss3
ss_pack_stride x5, x5, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
lui x16, 1
addi x16, x16, 512
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 8
addi x17, x0, 42
add x17, x19, x17
lui x18, 65536
addi x18, x18, 0
l2_load x18, x17, ss5
ss_pack_stride x5, x5, x12, ss1
addi x20, x0, 64
ss_pack_stride x12, x20, x12, ss6
ss_pack_stride x12, x20, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x21, x0, 1536
mfu_act1_conf_src2 x21, ss2, 0, l2
mfu_act1_conf_src1 x16, x5, x5, 1, l2
addi x22, x0, 8
ss_pack_shape x22, x12, x20, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x22, x12, x20, x12, ss7
mfu_act1_conf_dest x16, ss7
lui x23, 2
addi x23, x23, 2948
mfu_act1_conf_deq x23, x0, u8, 0
lui x24, 4
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x25, 131072
addi x25, x25, 0
mfu_act1_compute x25, x14, x18, x9
ss_pack_stride x5, x5, x2, ss4
ss_pack_stride x5, x5, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_clr 2
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x25, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
mmu_conf x3, x2, 2
addi x4, x0, 1168
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 1169
mmu_conf x6, x5, 4
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
ss_pack_stride x5, x5, x2, ss3
ss_pack_stride x5, x5, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
lui x16, 1
addi x16, x16, 512
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 8
addi x17, x0, 42
add x17, x19, x17
lui x18, 65536
addi x18, x18, 0
l2_load x18, x17, ss5
ss_pack_stride x5, x5, x12, ss1
addi x20, x0, 64
ss_pack_stride x12, x20, x12, ss6
ss_pack_stride x12, x20, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x21, x0, 1536
mfu_act1_conf_src2 x21, ss2, 0, l2
mfu_act1_conf_src1 x16, x5, x5, 1, l2
addi x22, x0, 8
ss_pack_shape x22, x12, x20, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x22, x12, x20, x12, ss7
mfu_act1_conf_dest x16, ss7
lui x23, 2
addi x23, x23, 2948
mfu_act1_conf_deq x23, x0, u8, 0
lui x24, 4
addi x24, x24, 3072
mfu_act1_conf_deq x24, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x25, 131072
addi x25, x25, 0
mfu_act1_compute x25, x14, x18, x9
ss_pack_stride x5, x5, x2, ss4
ss_pack_stride x5, x5, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_clr 2
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x25, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 5
addi x12, x12, 2090
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape8-lhs_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
mmu_conf x3, x2, 2
addi x4, x0, 1168
addi x5, x0, 12
mmu_conf x4, x5, 3
addi x6, x0, 1180
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 192
ss_pack_stride x7, x7, x13, ss0
ss_pack_stride x7, x7, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x7, x7, x7, x13, ss2
ccr_decl x7
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x7, x7, x2, ss3
ss_pack_stride x7, x7, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
lui x17, 1
addi x17, x17, 512
ss_pack_shape x7, x7, x7, x17, ss5
ccr_decl x7
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss5
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x7, x21, x22, ss6
ss_pack_stride x22, x21, x22, ss7
ss_pack_stride x22, x21, x22, ss7
mfu_act1_conf_stride ss6, ss7, ss7
mfu_act1_conf_src1 x13, x7, x7, 0, l2
ss_pack_shape x7, x7, x21, x22, ss0
addi x23, x0, 24
mfu_act1_conf_src2 x23, ss0, 0, l2
mfu_act1_conf_src1 x17, x7, x7, 1, l2
addi x24, x0, 8
ss_pack_shape x24, x22, x21, x22, ss1
mfu_act1_conf_src2 x7, ss1, 1, l2
ss_pack_shape x24, x22, x21, x22, ss1
mfu_act1_conf_dest x17, ss1
lui x25, 2
addi x25, x25, 3074
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 131072
addi x27, x27, 0
mfu_act1_compute x27, x15, x19, x10
ss_pack_stride x7, x7, x2, ss4
ss_pack_stride x7, x7, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x17, ss5
ccr_decl x7
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
mmu_conf x3, x2, 2
addi x4, x0, 1168
addi x5, x0, 12
mmu_conf x4, x5, 3
addi x6, x0, 1180
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 192
ss_pack_stride x7, x7, x13, ss0
ss_pack_stride x7, x7, x13, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x7, x7, x7, x13, ss2
ccr_decl x7
ccr_set 0, 1
lw x16, x0, 0
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
l2_load x15, x14, ss2
ss_pack_stride x7, x7, x2, ss3
ss_pack_stride x7, x7, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
lui x17, 1
addi x17, x17, 512
ss_pack_shape x7, x7, x7, x17, ss5
ccr_decl x7
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 42
add x18, x20, x18
lui x19, 65536
addi x19, x19, 0
l2_load x19, x18, ss5
addi x21, x0, 64
addi x22, x0, 3
ss_pack_stride x7, x21, x22, ss6
ss_pack_stride x22, x21, x22, ss7
ss_pack_stride x22, x21, x22, ss7
mfu_act1_conf_stride ss6, ss7, ss7
mfu_act1_conf_src1 x13, x7, x7, 0, l2
ss_pack_shape x7, x7, x21, x22, ss0
addi x23, x0, 24
mfu_act1_conf_src2 x23, ss0, 0, l2
mfu_act1_conf_src1 x17, x7, x7, 1, l2
addi x24, x0, 8
ss_pack_shape x24, x22, x21, x22, ss1
mfu_act1_conf_src2 x7, ss1, 1, l2
ss_pack_shape x24, x22, x21, x22, ss1
mfu_act1_conf_dest x17, ss1
lui x25, 2
addi x25, x25, 3074
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x22
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 131072
addi x27, x27, 0
mfu_act1_compute x27, x15, x19, x10
ss_pack_stride x7, x7, x2, ss4
ss_pack_stride x7, x7, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x7, x7, x7, x17, ss5
ccr_decl x7
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 5
addi x12, x12, 2090
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# case: test_binary[rhs_shape8-lhs_shape2]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
mmu_conf x3, x2, 2
addi x4, x0, 784
addi x5, x0, 24
mmu_conf x4, x5, 3
addi x6, x0, 808
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x2, ss2
ccr_decl x13
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss3
l2_load_conf ss3, ss0, fp16, fp32
addi x18, x0, 8
ss_pack_shape x18, x13, x13, x2, ss4
ccr_decl x13
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 65536
addi x20, x20, 0
l2_load x20, x19, ss4
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x7, x22, x23, ss5
ss_pack_stride x7, x22, x23, ss5
ss_pack_stride x7, x22, x23, ss5
mfu_act1_conf_stride ss5, ss5, ss5
mfu_act1_conf_src1 x2, x13, x13, 0, l2
ss_pack_shape x13, x7, x22, x23, ss6
mfu_act1_conf_src2 x18, ss6, 0, l2
lui x24, 1
addi x24, x24, 3072
mfu_act1_conf_src1 x24, x13, x13, 1, l2
ss_pack_shape x18, x7, x22, x23, ss7
mfu_act1_conf_src2 x13, ss7, 1, l2
ss_pack_shape x18, x7, x22, x23, ss7
mfu_act1_conf_dest x24, ss7
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 131072
addi x27, x27, 0
mfu_act1_compute x27, x16, x20, x10
ss_pack_stride x13, x13, x2, ss3
ss_pack_stride x13, x13, x14, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x18, x13, x13, x2, ss4
ccr_decl x13
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss4
ss_pack_stride x13, x13, x14, ss0
addi x30, x0, 192
ss_pack_stride x13, x13, x30, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x30, ss2
ccr_decl x13
ccr_set 3, 1
lw x3, x0, 0
addi x31, x0, 384
add x31, x3, x31
lui x1, 196608
addi x1, x1, 384
l2_load x1, x31, ss2
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x30, ss5
l2_load_conf ss5, ss0, fp16, fp32
ss_pack_shape x18, x13, x13, x30, ss6
ccr_decl x13
ccr_set 4, 1
lw x6, x0, 8
addi x4, x0, 1578
add x4, x6, x4
lui x5, 65538
addi x5, x5, 2048
l2_load x5, x4, ss6
ss_pack_stride x13, x22, x23, ss7
ss_pack_stride x13, x22, x23, ss7
ss_pack_stride x7, x22, x23, ss3
mfu_act1_conf_stride ss7, ss7, ss3
mfu_act1_conf_src1 x30, x13, x13, 0, l2
ss_pack_shape x13, x13, x22, x23, ss4
mfu_act1_conf_src2 x18, ss4, 0, l2
addi x8, x0, 1536
mfu_act1_conf_src1 x8, x13, x13, 1, l2
ss_pack_shape x18, x13, x22, x23, ss1
mfu_act1_conf_src2 x13, ss1, 1, l2
ss_pack_shape x18, x13, x22, x23, ss1
mfu_act1_conf_dest x8, ss1
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x23
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x9, 131074
addi x9, x9, 2048
lui x11, 262144
addi x11, x11, 28
mfu_act1_compute x9, x1, x5, x11
ss_pack_stride x13, x13, x2, ss2
ss_pack_stride x13, x13, x14, ss0
l2_store_conf ss0, ss2, fp16, fp32
ss_pack_shape x18, x13, x13, x30, ss6
ccr_decl x13
ccr_clr 5
lw x15, x0, 4
addi x12, x0, 1536
add x12, x15, x12
l2_store x12, x9, ss6
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
mmu_conf x3, x2, 2
addi x4, x0, 784
addi x5, x0, 24
mmu_conf x4, x5, 3
addi x6, x0, 808
addi x7, x0, 2
mmu_conf x6, x7, 4
addi x8, x0, 21
l2_load_w_conf x8, x8, fp16, fp16, 0
lw x11, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 262144
addi x10, x10, 0
addi x12, x0, 23
l2_load_w x10, x9, x12
addi x13, x0, 1
addi x14, x0, 576
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x2, ss2
ccr_decl x13
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x2, ss3
l2_load_conf ss3, ss0, fp16, fp32
addi x18, x0, 8
ss_pack_shape x18, x13, x13, x2, ss4
ccr_decl x13
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 65536
addi x20, x20, 0
l2_load x20, x19, ss4
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x7, x22, x23, ss5
ss_pack_stride x7, x22, x23, ss5
ss_pack_stride x7, x22, x23, ss5
mfu_act1_conf_stride ss5, ss5, ss5
mfu_act1_conf_src1 x2, x13, x13, 0, l2
ss_pack_shape x13, x7, x22, x23, ss6
mfu_act1_conf_src2 x18, ss6, 0, l2
lui x24, 1
addi x24, x24, 3072
mfu_act1_conf_src1 x24, x13, x13, 1, l2
ss_pack_shape x18, x7, x22, x23, ss7
mfu_act1_conf_src2 x13, ss7, 1, l2
ss_pack_shape x18, x7, x22, x23, ss7
mfu_act1_conf_dest x24, ss7
lui x25, 2
addi x25, x25, 3076
mfu_act1_conf_deq x25, x0, u8, 0
lui x26, 4
addi x26, x26, 3072
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x27, 131072
addi x27, x27, 0
mfu_act1_compute x27, x16, x20, x10
ss_pack_stride x13, x13, x2, ss3
ss_pack_stride x13, x13, x14, ss0
l2_store_conf ss0, ss3, fp16, fp32
ss_pack_shape x18, x13, x13, x2, ss4
ccr_decl x13
ccr_clr 2
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x27, ss4
ss_pack_stride x13, x13, x14, ss0
addi x30, x0, 192
ss_pack_stride x13, x13, x30, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x13, x13, x13, x30, ss2
ccr_decl x13
ccr_set 3, 1
lw x3, x0, 0
addi x31, x0, 384
add x31, x3, x31
lui x1, 196608
addi x1, x1, 384
l2_load x1, x31, ss2
ss_pack_stride x13, x13, x14, ss0
ss_pack_stride x13, x13, x30, ss5
l2_load_conf ss5, ss0, fp16, fp32
ss_pack_shape x18, x13, x13, x30, ss6
ccr_decl x13
ccr_set 4, 1
lw x6, x0, 8
addi x4, x0, 1578
add x4, x6, x4
lui x5, 65538
addi x5, x5, 2048
l2_load x5, x4, ss6
ss_pack_stride x13, x22, x23, ss7
ss_pack_stride x13, x22, x23, ss7
ss_pack_stride x7, x22, x23, ss3
mfu_act1_conf_stride ss7, ss7, ss3
mfu_act1_conf_src1 x30, x13, x13, 0, l2
ss_pack_shape x13, x13, x22, x23, ss4
mfu_act1_conf_src2 x18, ss4, 0, l2
addi x8, x0, 1536
mfu_act1_conf_src1 x8, x13, x13, 1, l2
ss_pack_shape x18, x13, x22, x23, ss1
mfu_act1_conf_src2 x13, ss1, 1, l2
ss_pack_shape x18, x13, x22, x23, ss1
mfu_act1_conf_dest x8, ss1
mfu_act1_conf_deq x25, x0, u8, 0
mfu_act1_conf_deq x26, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x23
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x9, 131074
addi x9, x9, 2048
lui x11, 262144
addi x11, x11, 28
mfu_act1_compute x9, x1, x5, x11
ss_pack_stride x13, x13, x2, ss2
ss_pack_stride x13, x13, x14, ss0
l2_store_conf ss0, ss2, fp16, fp32
ss_pack_shape x18, x13, x13, x30, ss6
ccr_decl x13
ccr_clr 5
lw x15, x0, 4
addi x12, x0, 1536
add x12, x15, x12
l2_store x12, x9, ss6
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 5
addi x13, x13, 2090
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# case: test_binary[rhs_shape8-lhs_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 288
mmu_conf x3, x4, 2
addi x5, x0, 880
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 884
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 885
mmu_conf x9, x8, 5
ss_pack_stride x8, x8, x2, ss0
ss_pack_stride x8, x8, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
lui x10, 1
addi x10, x10, 512
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 8
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 64
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 8
addi x24, x0, 42
add x24, x26, x24
lui x25, 196608
addi x25, x25, 0
l2_load_w x25, x24, x18
ss_pack_stride x8, x8, x2, ss1
ss_pack_stride x8, x8, x2, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 8
addi x27, x0, 84
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss2
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
ss_pack_stride x19, x20, x19, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x10, x8, x8, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_src2 x8, ss5, 1, l2
ss_pack_shape x21, x19, x20, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
mfu_act1_conf_deq x30, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x23, x28, x25
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_clr 0
lw x1, x0, 4
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x12, ss2
end x0
# case: test_binary[rhs_shape9-lhs_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 9
mmu_conf x1, x2, 1
addi x3, x0, 25
mmu_conf x3, x2, 2
addi x4, x0, 34
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 35
mmu_conf x6, x5, 4
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
ss_pack_stride x5, x5, x2, ss3
ss_pack_stride x5, x5, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x16, x0, 72
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 8
addi x17, x0, 42
add x17, x19, x17
lui x18, 65536
addi x18, x18, 0
l2_load x18, x17, ss5
ss_pack_stride x5, x5, x12, ss1
ss_pack_stride x12, x5, x12, ss6
ss_pack_stride x12, x5, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x20, x0, 24
mfu_act1_conf_src2 x20, ss2, 0, l2
mfu_act1_conf_src1 x16, x5, x5, 1, l2
addi x21, x0, 8
ss_pack_shape x21, x12, x5, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x21, x12, x5, x12, ss7
mfu_act1_conf_dest x16, ss7
lui x22, 2
addi x22, x22, 3042
mfu_act1_conf_deq x22, x0, u8, 0
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x24, 131072
addi x24, x24, 0
mfu_act1_compute x24, x14, x18, x9
ss_pack_stride x5, x5, x2, ss4
ss_pack_stride x5, x5, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_clr 2
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x24, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 9
mmu_conf x1, x2, 1
addi x3, x0, 25
mmu_conf x3, x2, 2
addi x4, x0, 34
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 35
mmu_conf x6, x5, 4
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 262144
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 3
ss_pack_stride x5, x5, x12, ss0
ss_pack_stride x5, x5, x12, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x5, x5, x5, x12, ss2
ccr_decl x5
ccr_set 0, 1
lw x15, x0, 0
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 196608
addi x14, x14, 0
l2_load x14, x13, ss2
ss_pack_stride x5, x5, x2, ss3
ss_pack_stride x5, x5, x2, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x16, x0, 72
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_set 1, 1
lw x19, x0, 8
addi x17, x0, 42
add x17, x19, x17
lui x18, 65536
addi x18, x18, 0
l2_load x18, x17, ss5
ss_pack_stride x5, x5, x12, ss1
ss_pack_stride x12, x5, x12, ss6
ss_pack_stride x12, x5, x12, ss6
mfu_act1_conf_stride ss1, ss6, ss6
mfu_act1_conf_src1 x12, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x12, ss2
addi x20, x0, 24
mfu_act1_conf_src2 x20, ss2, 0, l2
mfu_act1_conf_src1 x16, x5, x5, 1, l2
addi x21, x0, 8
ss_pack_shape x21, x12, x5, x12, ss7
mfu_act1_conf_src2 x5, ss7, 1, l2
ss_pack_shape x21, x12, x5, x12, ss7
mfu_act1_conf_dest x16, ss7
lui x22, 2
addi x22, x22, 3042
mfu_act1_conf_deq x22, x0, u8, 0
lui x23, 4
addi x23, x23, 3072
mfu_act1_conf_deq x23, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x12
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x24, 131072
addi x24, x24, 0
mfu_act1_compute x24, x14, x18, x9
ss_pack_stride x5, x5, x2, ss4
ss_pack_stride x5, x5, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x5, x5, x5, x16, ss5
ccr_decl x5
ccr_clr 2
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x24, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
addi x7, x0, 3
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 330
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x7, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x7, ss2
mfu_act1_conf_dest x7, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x7
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 32
mfu_act1_compute x17, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x17, ss2
end x0
# case: test_binary[rhs_shape9-lhs_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 604
addi x6, x0, 9
mmu_conf x5, x6, 3
addi x7, x0, 613
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 192
ss_pack_stride x8, x8, x14, ss0
ss_pack_stride x8, x8, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x8, x8, x6, ss3
ss_pack_stride x8, x8, x6, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x18, x0, 72
ss_pack_shape x8, x8, x8, x18, ss5
ccr_decl x8
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 196608
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x8, x22, x23, ss6
ss_pack_stride x23, x8, x23, ss7
ss_pack_stride x23, x22, x23, ss0
mfu_act1_conf_stride ss6, ss7, ss0
mfu_act1_conf_src1 x14, x8, x8, 0, l2
ss_pack_shape x8, x8, x22, x23, ss1
addi x24, x0, 24
mfu_act1_conf_src2 x24, ss1, 0, l2
mfu_act1_conf_src1 x23, x8, x22, 1, l2
addi x25, x0, 8
ss_pack_shape x25, x23, x8, x23, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x25, x23, x22, x23, ss3
lui x26, 1
addi x26, x26, 512
mfu_act1_conf_dest x26, ss3
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
lui x28, 4
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x29, 65536
addi x29, x29, 0
mfu_act1_compute x29, x16, x20, x11
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x26, ss5
ccr_decl x8
ccr_clr 2
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x29, ss5
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 12
mmu_conf x3, x4, 2
addi x5, x0, 604
addi x6, x0, 9
mmu_conf x5, x6, 3
addi x7, x0, 613
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 192
ss_pack_stride x8, x8, x14, ss0
ss_pack_stride x8, x8, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x8, x8, x8, x14, ss2
ccr_decl x8
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x8, x8, x6, ss3
ss_pack_stride x8, x8, x6, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x18, x0, 72
ss_pack_shape x8, x8, x8, x18, ss5
ccr_decl x8
ccr_set 1, 1
lw x21, x0, 8
addi x19, x0, 42
add x19, x21, x19
lui x20, 196608
addi x20, x20, 0
l2_load x20, x19, ss5
addi x22, x0, 64
addi x23, x0, 3
ss_pack_stride x8, x22, x23, ss6
ss_pack_stride x23, x8, x23, ss7
ss_pack_stride x23, x22, x23, ss0
mfu_act1_conf_stride ss6, ss7, ss0
mfu_act1_conf_src1 x14, x8, x8, 0, l2
ss_pack_shape x8, x8, x22, x23, ss1
addi x24, x0, 24
mfu_act1_conf_src2 x24, ss1, 0, l2
mfu_act1_conf_src1 x23, x8, x22, 1, l2
addi x25, x0, 8
ss_pack_shape x25, x23, x8, x23, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x25, x23, x22, x23, ss3
lui x26, 1
addi x26, x26, 512
mfu_act1_conf_dest x26, ss3
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
lui x28, 4
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x23
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x29, 65536
addi x29, x29, 0
mfu_act1_compute x29, x16, x20, x11
ss_pack_stride x8, x8, x2, ss4
ss_pack_stride x8, x8, x2, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x26, ss5
ccr_decl x8
ccr_clr 2
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x29, ss5
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 41
mmu_conf x5, x4, 3
addi x6, x0, 42
mmu_conf x6, x4, 4
addi x7, x0, 192
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 330
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 64
addi x17, x0, 3
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 384
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 6
mmu_conf x3, x4, 2
addi x5, x0, 598
mmu_conf x5, x4, 3
addi x6, x0, 604
addi x7, x0, 1
mmu_conf x6, x7, 4
addi x8, x0, 605
mmu_conf x8, x7, 5
addi x9, x0, 9
ss_pack_stride x7, x7, x9, ss0
ss_pack_stride x7, x7, x9, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x10, x0, 72
ss_pack_shape x7, x7, x7, x10, ss2
ccr_decl x7
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x17, x0, 12
addi x15, x0, 344
add x15, x17, x15
lui x16, 196608
addi x16, x16, 128
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
ss_pack_stride x19, x7, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x7, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x7, x7, 0, l2
addi x20, x0, 8
ss_pack_shape x20, x19, x7, x19, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x20, x19, x7, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65538
addi x22, x22, 1024
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 386
add x23, x25, x23
lui x24, 196608
addi x24, x24, 64
l2_load_w x24, x23, x18
ss_pack_stride x19, x7, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x7, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x7, x7, 0, l2
ss_pack_shape x20, x19, x7, x19, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x7, x7, x7, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x7, ss4, 1, l2
ss_pack_shape x20, x19, x7, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x26, 2
addi x26, x26, 3076
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x0, x24
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x7
ccr_set 1, 1
lw x29, x0, 12
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 196608
addi x28, x28, 0
l2_load_w x28, x27, x18
addi x30, x0, 192
ss_pack_stride x7, x7, x30, ss6
ss_pack_stride x7, x7, x30, ss7
l2_load_conf ss7, ss6, i8, i8
ss_pack_shape x7, x7, x7, x30, ss0
ccr_decl x7
ccr_set 3, 1
lw x2, x0, 0
lui x31, 0
addi x31, x31, 0
add x31, x2, x31
lui x1, 131072
addi x1, x1, 0
l2_load x1, x31, ss0
ss_pack_stride x19, x7, x19, ss3
addi x3, x0, 64
ss_pack_stride x7, x3, x19, ss1
ss_pack_stride x19, x3, x19, ss2
mfu_act1_conf_stride ss3, ss1, ss2
mfu_act1_conf_src1 x19, x7, x3, 0, l2
ss_pack_shape x20, x19, x7, x19, ss5
mfu_act1_conf_src2 x7, ss5, 0, l2
mfu_act1_conf_src1 x30, x7, x7, 1, l2
ss_pack_shape x7, x7, x3, x19, ss4
addi x5, x0, 24
mfu_act1_conf_src2 x5, ss4, 1, l2
ss_pack_shape x20, x19, x3, x19, ss6
lui x4, 1
addi x4, x4, 512
mfu_act1_conf_dest x4, ss6
addi x6, x0, 255
mfu_act1_conf_deq x26, x6, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x8, x0, 4
ccr_decl x8
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x22, x12, x1, x28
addi x9, x0, 576
ss_pack_stride x7, x7, x9, ss7
ss_pack_stride x7, x7, x9, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x7, x7, x7, x4, ss0
ccr_decl x7
ccr_clr 2
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
l2_store x11, x22, ss0
end x0
# case: test_binary[rhs_shape9-lhs_shape2]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 424
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 430
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
addi x15, x0, 576
ss_pack_stride x14, x14, x15, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 9
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x6, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x20, x0, 8
ss_pack_shape x20, x14, x14, x6, ss5
ccr_decl x14
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 64
addi x25, x0, 3
ss_pack_stride x8, x24, x25, ss6
ss_pack_stride x8, x14, x25, ss7
ss_pack_stride x8, x24, x25, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x8, x24, x25, ss0
mfu_act1_conf_src2 x20, ss0, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x20, x8, x14, x25, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x20, x8, x24, x25, ss2
lui x26, 1
addi x26, x26, 3072
mfu_act1_conf_dest x26, ss2
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
lui x28, 4
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x29, 65536
addi x29, x29, 0
mfu_act1_compute x29, x17, x22, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x15, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x20, x14, x14, x2, ss5
ccr_decl x14
ccr_clr 2
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x29, ss5
ss_pack_stride x14, x14, x15, ss4
addi x1, x0, 192
ss_pack_stride x14, x14, x1, ss7
l2_load_conf ss7, ss4, i8, i8
ss_pack_shape x14, x14, x14, x1, ss6
ccr_decl x14
ccr_set 3, 1
lw x5, x0, 0
addi x3, x0, 384
add x3, x5, x3
lui x4, 131072
addi x4, x4, 384
l2_load x4, x3, ss6
ss_pack_stride x14, x14, x19, ss0
ss_pack_stride x14, x14, x25, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x20, x14, x14, x25, ss2
ccr_decl x14
ccr_set 4, 1
lw x10, x0, 8
addi x7, x0, 66
add x7, x10, x7
lui x9, 196608
addi x9, x9, 96
l2_load x9, x7, ss2
ss_pack_stride x14, x24, x25, ss3
ss_pack_stride x14, x14, x25, ss1
ss_pack_stride x8, x24, x25, ss5
mfu_act1_conf_stride ss3, ss1, ss5
mfu_act1_conf_src1 x1, x14, x14, 0, l2
ss_pack_shape x14, x14, x24, x25, ss4
mfu_act1_conf_src2 x20, ss4, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x20, x14, x14, x25, ss2
mfu_act1_conf_src2 x14, ss2, 1, l2
ss_pack_shape x20, x14, x24, x25, ss7
addi x12, x0, 1536
mfu_act1_conf_dest x12, ss7
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x25
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x13, 65538
addi x13, x13, 2048
lui x16, 262144
addi x16, x16, 28
mfu_act1_compute x13, x4, x9, x16
ss_pack_stride x14, x14, x2, ss6
ss_pack_stride x14, x14, x15, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x20, x14, x14, x1, ss3
ccr_decl x14
ccr_clr 5
lw x6, x0, 4
addi x18, x0, 1536
add x18, x6, x18
l2_store x18, x13, ss3
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 24
mmu_conf x3, x4, 2
addi x5, x0, 424
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 430
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
addi x15, x0, 576
ss_pack_stride x14, x14, x15, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x14, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x18, x0, 0
lui x16, 0
addi x16, x16, 0
add x16, x18, x16
lui x17, 131072
addi x17, x17, 0
l2_load x17, x16, ss2
addi x19, x0, 9
ss_pack_stride x14, x14, x19, ss3
ss_pack_stride x14, x14, x6, ss4
l2_load_conf ss4, ss3, fp16, fp32
addi x20, x0, 8
ss_pack_shape x20, x14, x14, x6, ss5
ccr_decl x14
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 64
addi x25, x0, 3
ss_pack_stride x8, x24, x25, ss6
ss_pack_stride x8, x14, x25, ss7
ss_pack_stride x8, x24, x25, ss6
mfu_act1_conf_stride ss6, ss7, ss6
mfu_act1_conf_src1 x2, x14, x14, 0, l2
ss_pack_shape x14, x8, x24, x25, ss0
mfu_act1_conf_src2 x20, ss0, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x20, x8, x14, x25, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x20, x8, x24, x25, ss2
lui x26, 1
addi x26, x26, 3072
mfu_act1_conf_dest x26, ss2
lui x27, 2
addi x27, x27, 3075
mfu_act1_conf_deq x27, x0, u8, 0
lui x28, 4
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf mul, 1, 0
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x29, 65536
addi x29, x29, 0
mfu_act1_compute x29, x17, x22, x11
ss_pack_stride x14, x14, x2, ss3
ss_pack_stride x14, x14, x15, ss4
l2_store_conf ss4, ss3, fp16, fp32
ss_pack_shape x20, x14, x14, x2, ss5
ccr_decl x14
ccr_clr 2
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x29, ss5
ss_pack_stride x14, x14, x15, ss4
addi x1, x0, 192
ss_pack_stride x14, x14, x1, ss7
l2_load_conf ss7, ss4, i8, i8
ss_pack_shape x14, x14, x14, x1, ss6
ccr_decl x14
ccr_set 3, 1
lw x5, x0, 0
addi x3, x0, 384
add x3, x5, x3
lui x4, 131072
addi x4, x4, 384
l2_load x4, x3, ss6
ss_pack_stride x14, x14, x19, ss0
ss_pack_stride x14, x14, x25, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x20, x14, x14, x25, ss2
ccr_decl x14
ccr_set 4, 1
lw x10, x0, 8
addi x7, x0, 66
add x7, x10, x7
lui x9, 196608
addi x9, x9, 96
l2_load x9, x7, ss2
ss_pack_stride x14, x24, x25, ss3
ss_pack_stride x14, x14, x25, ss1
ss_pack_stride x8, x24, x25, ss5
mfu_act1_conf_stride ss3, ss1, ss5
mfu_act1_conf_src1 x1, x14, x14, 0, l2
ss_pack_shape x14, x14, x24, x25, ss4
mfu_act1_conf_src2 x20, ss4, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x20, x14, x14, x25, ss2
mfu_act1_conf_src2 x14, ss2, 1, l2
ss_pack_shape x20, x14, x24, x25, ss7
addi x12, x0, 1536
mfu_act1_conf_dest x12, ss7
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x25
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x13, 65538
addi x13, x13, 2048
lui x16, 262144
addi x16, x16, 28
mfu_act1_compute x13, x4, x9, x16
ss_pack_stride x14, x14, x2, ss6
ss_pack_stride x14, x14, x15, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x20, x14, x14, x1, ss3
ccr_decl x14
ccr_clr 5
lw x6, x0, 4
addi x18, x0, 1536
add x18, x6, x18
l2_store x18, x13, ss3
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 72
mmu_conf x1, x2, 1
addi x3, x0, 88
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 90
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 91
mmu_conf x7, x6, 4
addi x8, x0, 576
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
addi x13, x0, 330
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 64
ss_pack_stride x17, x18, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1152
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 18
mmu_conf x3, x4, 2
addi x5, x0, 610
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 616
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 617
mmu_conf x9, x8, 5
addi x10, x0, 9
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x11, x0, 72
ss_pack_shape x8, x8, x8, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 12
addi x16, x0, 372
add x16, x18, x16
lui x17, 196608
addi x17, x17, 128
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 3
ss_pack_stride x20, x8, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x8, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_dest x11, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x13, x0, x17
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 12
addi x24, x0, 414
add x24, x26, x24
lui x25, 196608
addi x25, x25, 64
l2_load_w x25, x24, x19
ss_pack_stride x20, x8, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x8, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_dest x11, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x13, x23, x0, x25
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x30, x0, 12
lui x28, 0
addi x28, x28, 0
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x19
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
ss_pack_shape x8, x8, x8, x2, ss0
ccr_decl x8
ccr_set 3, 1
lw x3, x0, 0
lui x31, 0
addi x31, x31, 0
add x31, x3, x31
lui x1, 131072
addi x1, x1, 0
l2_load x1, x31, ss0
ss_pack_stride x20, x8, x20, ss3
addi x4, x0, 64
ss_pack_stride x20, x4, x20, ss1
ss_pack_stride x20, x4, x20, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x20, x8, x4, 0, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x2, x8, x8, 1, l2
ss_pack_shape x8, x20, x4, x20, ss2
mfu_act1_conf_src2 x21, ss2, 1, l2
ss_pack_shape x21, x20, x4, x20, ss4
lui x5, 1
addi x5, x5, 512
mfu_act1_conf_dest x5, ss4
addi x6, x0, 255
mfu_act1_conf_deq x27, x6, u8, 0
lui x7, 2
addi x7, x7, 3075
mfu_act1_conf_deq x7, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x9, x0, 4
ccr_decl x9
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x23, x13, x1, x29
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x5, ss6
ccr_decl x8
ccr_clr 2
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x23, ss6
end x0
# case: test_binary[rhs_shape9-lhs_shape3]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 598
addi x8, x0, 2
mmu_conf x7, x8, 4
addi x9, x0, 21
l2_load_w_conf x9, x9, fp16, fp16, 0
lw x12, x0, 8
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 262144
addi x11, x11, 0
addi x13, x0, 23
l2_load_w x11, x10, x13
addi x14, x0, 1
addi x15, x0, 576
ss_pack_stride x14, x14, x15, ss0
ss_pack_stride x14, x14, x2, ss1
l2_load_conf ss1, ss0, i8, i8
addi x16, x0, 8
ss_pack_shape x16, x14, x14, x2, ss2
ccr_decl x14
ccr_set 0, 1
lw x19, x0, 0
lui x17, 0
addi x17, x17, 0
add x17, x19, x17
lui x18, 131072
addi x18, x18, 0
l2_load x18, x17, ss2
addi x20, x0, 9
ss_pack_stride x14, x14, x20, ss3
ss_pack_stride x14, x14, x6, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x16, x14, x14, x6, ss5
ccr_decl x14
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 196608
addi x22, x22, 0
l2_load x22, x21, ss5
addi x24, x0, 64
addi x25, x0, 3
ss_pack_stride x8, x24, x25, ss6
ss_pack_stride x8, x14, x25, ss7
ss_pack_stride x8, x24, x25, ss6
mfu_act1_conf_stride ss6, ss7, ss6
lui x26, 1
addi x26, x26, 3072
mfu_act1_conf_src1 x26, x14, x14, 0, l2
ss_pack_shape x16, x8, x24, x25, ss0
mfu_act1_conf_src2 x14, ss0, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x16, x8, x14, x25, ss1
mfu_act1_conf_src2 x14, ss1, 1, l2
ss_pack_shape x16, x8, x24, x25, ss0
mfu_act1_conf_dest x26, ss0
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
lui x28, 4
addi x28, x28, 3072
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x25
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x29, 65536
addi x29, x29, 0
mfu_act1_compute x29, x18, x22, x11
ss_pack_stride x14, x14, x2, ss2
ss_pack_stride x14, x14, x15, ss3
l2_store_conf ss3, ss2, fp16, fp32
ss_pack_shape x16, x14, x14, x2, ss4
ccr_decl x14
ccr_clr 2
lw x31, x0, 4
lui x30, 0
addi x30, x30, 0
add x30, x31, x30
l2_store x30, x29, ss4
ss_pack_stride x14, x14, x15, ss3
ss_pack_stride x14, x14, x4, ss5
l2_load_conf ss5, ss3, i8, i8
ss_pack_shape x16, x14, x14, x4, ss7
ccr_decl x14
ccr_set 3, 1
lw x5, x0, 0
addi x1, x0, 384
add x1, x5, x1
lui x3, 131073
addi x3, x3, 3072
l2_load x3, x1, ss7
ss_pack_stride x14, x14, x20, ss6
ss_pack_stride x14, x14, x25, ss1
l2_load_conf ss1, ss6, fp16, fp32
ss_pack_shape x16, x14, x14, x25, ss0
ccr_decl x14
ccr_set 4, 1
lw x10, x0, 8
addi x7, x0, 66
add x7, x10, x7
lui x9, 196608
addi x9, x9, 96
l2_load x9, x7, ss0
ss_pack_stride x14, x24, x25, ss2
ss_pack_stride x14, x14, x25, ss1
ss_pack_stride x8, x24, x25, ss4
mfu_act1_conf_stride ss2, ss1, ss4
addi x12, x0, 1536
mfu_act1_conf_src1 x12, x14, x14, 0, l2
ss_pack_shape x16, x14, x24, x25, ss3
mfu_act1_conf_src2 x14, ss3, 0, l2
mfu_act1_conf_src1 x25, x14, x24, 1, l2
ss_pack_shape x16, x14, x14, x25, ss0
mfu_act1_conf_src2 x14, ss0, 1, l2
ss_pack_shape x16, x14, x24, x25, ss3
mfu_act1_conf_dest x12, ss3
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x28, x0, disable, 1
mfu_act1_conf_quant disable
ccr_decl x25
ccr_clr 3
ccr_clr 4
ccr_set 5, 1
lui x13, 65538
addi x13, x13, 2048
lui x17, 262144
addi x17, x17, 28
mfu_act1_compute x13, x3, x9, x17
ss_pack_stride x14, x14, x2, ss5
ss_pack_stride x14, x14, x15, ss7
l2_store_conf ss7, ss5, fp16, fp32
ss_pack_shape x16, x14, x14, x4, ss6
ccr_decl x14
ccr_clr 5
lw x6, x0, 4
addi x19, x0, 1536
add x19, x6, x19
l2_store x19, x13, ss6
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 384
mmu_conf x1, x2, 1
addi x3, x0, 400
addi x4, x0, 192
mmu_conf x3, x4, 2
addi x5, x0, 592
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 330
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 576
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x14, x0, 8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 64
addi x19, x0, 3
ss_pack_stride x6, x18, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x18, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
lui x20, 1
addi x20, x20, 3072
mfu_act1_conf_src1 x20, x12, x12, 0, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x6, x18, x19, ss5
mfu_act1_conf_dest x20, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x22, 131072
addi x22, x22, 0
mfu_act1_compute x22, x16, x0, x9
ss_pack_stride x12, x12, x2, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x14, x12, x12, x2, ss2
ccr_decl x12
ccr_clr 1
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x22, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x2, ss6
l2_load_conf ss6, ss0, fp16, fp32
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 1536
add x25, x27, x25
lui x26, 65538
addi x26, x26, 2048
l2_load x26, x25, ss7
addi x28, x0, 1536
mfu_act1_conf_src1 x28, x12, x12, 0, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x14, x12, x18, x19, ss3
mfu_act1_conf_dest x28, ss3
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x29, 131073
addi x29, x29, 3072
lui x30, 196608
addi x30, x30, 28
mfu_act1_compute x29, x26, x0, x30
ss_pack_stride x12, x12, x2, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x14, x12, x12, x4, ss7
ccr_decl x12
ccr_clr 3
lw x1, x0, 4
addi x31, x0, 384
add x31, x1, x31
l2_store x31, x29, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 576
mmu_conf x1, x2, 1
addi x3, x0, 592
addi x4, x0, 144
mmu_conf x3, x4, 2
addi x5, x0, 736
addi x6, x0, 6
mmu_conf x5, x6, 3
addi x7, x0, 742
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 743
mmu_conf x9, x8, 5
addi x10, x0, 9
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
addi x11, x0, 72
ss_pack_shape x8, x8, x8, x11, ss2
ccr_decl x8
ccr_set 0, 1
lw x14, x0, 4
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load x13, x12, ss2
addi x15, x0, 21
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x18, x0, 12
addi x16, x0, 330
add x16, x18, x16
lui x17, 196608
addi x17, x17, 128
addi x19, x0, 23
l2_load_w x17, x16, x19
addi x20, x0, 3
ss_pack_stride x20, x8, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x8, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
addi x21, x0, 8
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_dest x11, ss5
lui x22, 4
addi x22, x22, 3072
mfu_act1_conf_deq x22, x0, disable, 0
mfu_act1_conf_deq x22, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x23, 65538
addi x23, x23, 1024
mfu_act1_compute x23, x13, x0, x17
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x26, x0, 12
addi x24, x0, 372
add x24, x26, x24
lui x25, 196608
addi x25, x25, 64
l2_load_w x25, x24, x19
ss_pack_stride x20, x8, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x20, x8, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x11, x8, x8, 0, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_dest x11, ss5
lui x27, 2
addi x27, x27, 3076
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x20
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x13, x23, x0, x25
l2_load_w_conf x15, x15, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x30, x0, 12
lui x28, 0
addi x28, x28, 0
add x28, x30, x28
lui x29, 196608
addi x29, x29, 0
l2_load_w x29, x28, x19
ss_pack_stride x8, x8, x2, ss6
ss_pack_stride x8, x8, x2, ss7
l2_load_conf ss7, ss6, i8, i8
lui x31, 1
addi x31, x31, 512
ss_pack_shape x8, x8, x8, x31, ss0
ccr_decl x8
ccr_set 3, 1
lw x4, x0, 0
lui x1, 0
addi x1, x1, 0
add x1, x4, x1
lui x3, 131072
addi x3, x3, 0
l2_load x3, x1, ss0
ss_pack_stride x20, x8, x20, ss3
addi x5, x0, 64
ss_pack_stride x20, x5, x20, ss1
ss_pack_stride x20, x5, x20, ss1
mfu_act1_conf_stride ss3, ss1, ss1
mfu_act1_conf_src1 x20, x8, x5, 0, l2
ss_pack_shape x21, x20, x8, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x31, x8, x8, 1, l2
ss_pack_shape x21, x20, x5, x20, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x21, x20, x5, x20, ss2
mfu_act1_conf_dest x31, ss2
addi x6, x0, 255
mfu_act1_conf_deq x27, x6, u8, 0
mfu_act1_conf_deq x27, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x7, x0, 4
ccr_decl x7
ccr_clr 0
ccr_clr 3
ccr_clr 1
ccr_set 2, 1
mfu_act1_compute x23, x13, x3, x29
ss_pack_stride x8, x8, x2, ss7
ss_pack_stride x8, x8, x2, ss7
l2_store_conf ss7, ss7, fp16, fp32
ss_pack_shape x8, x8, x8, x31, ss0
ccr_decl x8
ccr_clr 2
lw x10, x0, 8
lui x9, 0
addi x9, x9, 0
add x9, x10, x9
l2_store x9, x23, ss0
end x0
