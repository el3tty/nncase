# case: test_clip[op_versions_and_value_format0-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format1-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format2-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3073
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format3-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format4-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format5-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3075
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format6-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3076
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
# case: test_clip[op_versions_and_value_format7-6.0-None-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 24
mmu_conf x1, x2, 1
addi x3, x0, 40
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 44
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 45
mmu_conf x7, x6, 4
addi x8, x0, 192
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 8
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 384
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 42
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x17, x18, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x18, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x18, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x24, 2
addi x24, x24, 3075
mfu_act1_conf_deq x24, x0, u8, 0
mfu_act1_conf_deq x24, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
