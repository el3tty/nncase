# case: test_upsample[scale0-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 12
mmu_conf x1, x2, 1
addi x3, x0, 28
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 30
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 31
mmu_conf x7, x6, 4
addi x8, x0, 24
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 4
ss_pack_stride x4, x17, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 192
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 28
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x4, x17, x18, ss3
ss_pack_stride x0, x0, x0, ss4
addi x24, x0, 6
addi x25, x0, 8
ss_pack_stride x4, x24, x25, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x18, x4, x4, 0, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x24, x25, ss7
addi x26, x0, 96
mfu_act1_conf_dest x26, ss7
lui x27, 2
addi x27, x27, 3050
mfu_act1_conf_deq x27, x0, u8, 0
mfu_act1_conf_deq x27, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x26, ss0
ss_pack_stride x6, x6, x26, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x26, ss1
ccr_decl x6
ccr_clr 0
lw x29, x0, 4
lui x28, 0
addi x28, x28, 0
add x28, x29, x28
l2_store x28, x10, ss1
end x0
# case: test_upsample[scale1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 36
mmu_conf x1, x2, 1
addi x3, x0, 52
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 54
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 55
mmu_conf x7, x6, 4
addi x8, x0, 24
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 32
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
addi x18, x0, 4
ss_pack_stride x4, x17, x18, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x17, x18, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_dest x8, ss5
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 576
mfu_act1_compute x20, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x23, x0, 8
addi x21, x0, 28
add x21, x23, x21
lui x22, 131072
addi x22, x22, 0
l2_load_w x22, x21, x16
ss_pack_stride x4, x17, x18, ss3
ss_pack_stride x0, x0, x0, ss4
addi x24, x0, 9
ss_pack_stride x4, x24, x1, ss6
mfu_act1_conf_stride ss3, ss4, ss6
mfu_act1_conf_src1 x18, x18, x17, 0, l2
ss_pack_shape x6, x4, x17, x18, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x4, x24, x1, ss7
addi x25, x0, 288
mfu_act1_conf_dest x25, ss7
lui x26, 2
addi x26, x26, 3064
mfu_act1_conf_deq x26, x0, u8, 0
mfu_act1_conf_deq x26, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x22
ss_pack_stride x6, x6, x25, ss0
ss_pack_stride x6, x6, x25, ss0
l2_store_conf ss0, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x25, ss1
ccr_decl x6
ccr_clr 0
lw x28, x0, 4
lui x27, 0
addi x27, x27, 0
add x27, x28, x27
l2_store x27, x10, ss1
end x0
