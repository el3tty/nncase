# case: test_unary[in_shape0]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 7
l2_load_w_conf x6, x6, fp16, fp16, 0
lw x9, x0, 8
addi x7, x0, 28
add x7, x9, x7
lui x8, 196608
addi x8, x8, 0
addi x10, x0, 23
l2_load_w x8, x7, x10
ss_pack_stride x4, x4, x1, ss0
ss_pack_stride x4, x4, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
l2_load x12, x11, ss2
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x14, 2
addi x14, x14, 2998
mfu_act1_conf_deq x14, x0, u8, 0
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x2
ccr_clr 0
ccr_set 1, 1
lui x16, 65536
addi x16, x16, 0
mfu_act1_compute x16, x12, x0, x8
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x4, x4, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_clr 1
lw x18, x0, 4
lui x17, 0
addi x17, x17, 0
add x17, x18, x17
l2_store x17, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
mmu_conf x3, x2, 2
addi x4, x0, 20
addi x5, x0, 1
mmu_conf x4, x5, 3
addi x6, x0, 21
mmu_conf x6, x5, 4
ss_pack_stride x5, x5, x1, ss0
ss_pack_stride x5, x5, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x13, x0, 8
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 131072
addi x12, x12, 32
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x5
ccr_set 1, 1
lw x20, x0, 8
addi x18, x0, 14
add x18, x20, x18
lui x19, 131072
addi x19, x19, 0
l2_load_w x19, x18, x14
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x5, x5, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x5, x5, 0, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_src2 x5, ss2, 0, l2
mfu_act1_conf_src1 x5, x5, x5, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x5, ss3, 1, l2
ss_pack_shape x5, x5, x5, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x21, 2
addi x21, x21, 2998
addi x22, x0, 255
mfu_act1_conf_deq x21, x22, u8, 0
mfu_act1_conf_deq x21, x22, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x8, x16, x0, x19
ss_pack_stride x5, x5, x1, ss1
ss_pack_stride x5, x5, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x5, x5, x5, x1, ss2
ccr_decl x5
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x8, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x1, ss0
ss_pack_stride x4, x4, x1, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
addi x11, x0, 42
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 4
addi x15, x15, 3072
mfu_act1_conf_deq x15, x0, disable, 0
mfu_act1_conf_deq x15, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x4, x4, x1, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 22
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 23
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 131072
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 49
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 56
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load_w x13, x12, x7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 2
addi x15, x15, 2998
mfu_act1_conf_deq x15, x0, u8, 0
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 131072
addi x16, x16, 32
mfu_act1_compute x16, x9, x0, x13
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x6, x6, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 22
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 23
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 131072
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 49
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 154
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load_w x13, x12, x7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 2
addi x15, x15, 2998
mfu_act1_conf_deq x15, x0, u8, 0
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 131072
addi x16, x16, 32
mfu_act1_compute x16, x9, x0, x13
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x6, x6, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x1, ss0
ss_pack_stride x4, x4, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
addi x11, x0, 252
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 2
addi x15, x15, 2998
mfu_act1_conf_deq x15, x0, u8, 0
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x4, x4, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 2
mmu_conf x1, x2, 1
addi x3, x0, 18
addi x4, x0, 1
mmu_conf x3, x4, 2
addi x5, x0, 19
mmu_conf x5, x4, 3
addi x6, x0, 20
mmu_conf x6, x4, 4
ss_pack_stride x4, x4, x1, ss0
ss_pack_stride x4, x4, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_set 0, 1
lw x9, x0, 0
lui x7, 0
addi x7, x7, 0
add x7, x9, x7
lui x8, 65536
addi x8, x8, 0
l2_load x8, x7, ss2
addi x10, x0, 7
l2_load_w_conf x10, x10, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x13, x0, 8
addi x11, x0, 266
add x11, x13, x11
lui x12, 131072
addi x12, x12, 0
addi x14, x0, 23
l2_load_w x12, x11, x14
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x4, x4, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x4, x4, 0, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_src2 x4, ss2, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x4, ss3, 1, l2
ss_pack_shape x4, x4, x4, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 2
addi x15, x15, 2998
mfu_act1_conf_deq x15, x0, u8, 0
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 65536
addi x16, x16, 32
mfu_act1_compute x16, x8, x0, x12
ss_pack_stride x4, x4, x1, ss1
ss_pack_stride x4, x4, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x4, x4, x4, x1, ss2
ccr_decl x4
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# tile: k230/ptq TileLayerGroup_6
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 4
mmu_conf x1, x2, 1
addi x3, x0, 20
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 22
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 23
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x1, ss0
ss_pack_stride x6, x6, x1, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 131072
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 49
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 8
addi x12, x0, 280
add x12, x14, x12
lui x13, 65536
addi x13, x13, 0
l2_load_w x13, x12, x7
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x1, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x1, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x1, ss2
mfu_act1_conf_dest x1, ss2
lui x15, 2
addi x15, x15, 2998
mfu_act1_conf_deq x15, x0, u8, 0
mfu_act1_conf_deq x15, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
addi x17, x0, 3
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x16, 131072
addi x16, x16, 32
mfu_act1_compute x16, x9, x0, x13
ss_pack_stride x6, x6, x1, ss1
ss_pack_stride x6, x6, x1, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x1, ss2
ccr_decl x6
ccr_clr 2
lw x19, x0, 4
lui x18, 0
addi x18, x18, 0
add x18, x19, x18
l2_store x18, x16, ss2
end x0
# case: test_unary[in_shape1]
# tile: k230/ptq TileAct1_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 84
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# tile: k230/ptq TileAct1_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 126
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 65536
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x19, 131072
addi x19, x19, 0
mfu_act1_compute x19, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x21, x0, 4
lui x20, 0
addi x20, x20, 0
add x20, x21, x20
l2_store x20, x19, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, fp16, fp32
addi x22, x0, 256
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_set 2, 1
lw x25, x0, 0
lui x23, 1
addi x23, x23, 2048
add x23, x25, x23
lui x24, 65536
addi x24, x24, 1024
l2_load x24, x23, ss7
mfu_act1_conf_src1 x22, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x22, ss3
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x26, 131072
addi x26, x26, 512
lui x27, 196608
addi x27, x27, 28
mfu_act1_compute x26, x24, x0, x27
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, i8, i8
ss_pack_shape x12, x12, x12, x22, ss7
ccr_decl x12
ccr_clr 3
lw x29, x0, 4
addi x28, x0, 512
add x28, x29, x28
l2_store x28, x26, ss7
end x0
# tile: k230/ptq TileAct1_2
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 49
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 168
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x19, 2
addi x19, x19, 3075
mfu_act1_conf_deq x19, x0, u8, 0
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
ccr_decl x18
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x24, x0, 256
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 512
add x25, x27, x25
lui x26, 131072
addi x26, x26, 512
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x18
ccr_clr 2
ccr_set 3, 1
lui x28, 65536
addi x28, x28, 1024
mfu_act1_compute x28, x26, x0, x9
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x28, ss7
end x0
# tile: k230/ptq TileAct1_3
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 49
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 266
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x19, 2
addi x19, x19, 3075
mfu_act1_conf_deq x19, x0, u8, 0
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
ccr_decl x18
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x24, x0, 256
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 512
add x25, x27, x25
lui x26, 131072
addi x26, x26, 512
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x18
ccr_clr 2
ccr_set 3, 1
lui x28, 65536
addi x28, x28, 1024
mfu_act1_compute x28, x26, x0, x9
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x28, ss7
end x0
# tile: k230/ptq TileAct1_4
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 364
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# tile: k230/ptq TileAct1_5
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 21
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 406
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
ss_pack_stride x6, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x6, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x18, 2
addi x18, x18, 3075
mfu_act1_conf_deq x18, x0, u8, 0
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 0
ccr_set 1, 1
lui x20, 65536
addi x20, x20, 0
mfu_act1_compute x20, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x20, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x23, x0, 256
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_set 2, 1
lw x26, x0, 0
addi x24, x0, 512
add x24, x26, x24
lui x25, 131072
addi x25, x25, 512
l2_load x25, x24, ss7
mfu_act1_conf_src1 x23, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x23, ss3
mfu_act1_conf_deq x18, x0, u8, 0
mfu_act1_conf_deq x19, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x6
ccr_clr 2
ccr_set 3, 1
lui x27, 65536
addi x27, x27, 1024
lui x28, 196608
addi x28, x28, 28
mfu_act1_compute x27, x25, x0, x28
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x23, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x27, ss7
end x0
# tile: k230/ptq TileAct1_6
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 64
mmu_conf x1, x2, 1
addi x3, x0, 80
addi x4, x0, 32
mmu_conf x3, x4, 2
addi x5, x0, 112
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 49
l2_load_w_conf x7, x7, fp16, fp16, 0
lw x10, x0, 8
addi x8, x0, 448
add x8, x10, x8
lui x9, 196608
addi x9, x9, 0
addi x11, x0, 23
l2_load_w x9, x8, x11
addi x12, x0, 1
addi x13, x0, 768
ss_pack_stride x12, x12, x13, ss0
addi x14, x0, 512
ss_pack_stride x12, x12, x14, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_set 0, 1
lw x17, x0, 0
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 131072
addi x16, x16, 0
l2_load x16, x15, ss2
addi x18, x0, 2
ss_pack_stride x18, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x14, x12, x12, 0, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_src2 x12, ss5, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x18, x1, x1, ss5
mfu_act1_conf_dest x14, ss5
lui x19, 2
addi x19, x19, 3075
mfu_act1_conf_deq x19, x0, u8, 0
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 0, 1
ccr_decl x18
ccr_clr 0
ccr_set 1, 1
lui x21, 65536
addi x21, x21, 0
mfu_act1_compute x21, x16, x0, x9
ss_pack_stride x12, x12, x14, ss1
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss1, fp16, fp32
ss_pack_shape x12, x12, x12, x14, ss2
ccr_decl x12
ccr_clr 1
lw x23, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x23, x22
l2_store x22, x21, ss2
ss_pack_stride x12, x12, x13, ss0
ss_pack_stride x12, x12, x14, ss6
l2_load_conf ss6, ss0, i8, i8
addi x24, x0, 256
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_set 2, 1
lw x27, x0, 0
addi x25, x0, 512
add x25, x27, x25
lui x26, 131072
addi x26, x26, 512
l2_load x26, x25, ss7
mfu_act1_conf_src1 x24, x12, x12, 0, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_src2 x12, ss3, 0, l2
mfu_act1_conf_src1 x12, x12, x12, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x12, ss4, 1, l2
ss_pack_shape x12, x12, x1, x1, ss3
mfu_act1_conf_dest x24, ss3
mfu_act1_conf_deq x19, x0, u8, 0
mfu_act1_conf_deq x20, x0, u8, 1
mfu_act1_conf_quant disable
ccr_decl x18
ccr_clr 2
ccr_set 3, 1
lui x28, 65536
addi x28, x28, 1024
mfu_act1_compute x28, x26, x0, x9
ss_pack_stride x12, x12, x14, ss6
ss_pack_stride x12, x12, x13, ss0
l2_store_conf ss0, ss6, fp16, fp32
ss_pack_shape x12, x12, x12, x24, ss7
ccr_decl x12
ccr_clr 3
lw x30, x0, 4
lui x29, 1
addi x29, x29, 2048
add x29, x30, x29
l2_store x29, x28, ss7
end x0
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 4
mmu_conf x3, x4, 2
addi x5, x0, 116
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 117
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65536
addi x19, x19, 1536
mfu_act1_compute x19, x10, x0, x14
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x22, x0, 8
addi x20, x0, 42
add x20, x22, x20
lui x21, 131072
addi x21, x21, 0
l2_load_w x21, x20, x16
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x17, x1, x1, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss5
mfu_act1_conf_dest x8, ss5
lui x23, 2
addi x23, x23, 3075
addi x24, x0, 255
mfu_act1_conf_deq x23, x24, u8, 0
mfu_act1_conf_deq x23, x24, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 2
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x19, x0, x21
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 0
lw x26, x0, 4
lui x25, 0
addi x25, x25, 0
add x25, x26, x25
l2_store x25, x10, ss2
end x0
