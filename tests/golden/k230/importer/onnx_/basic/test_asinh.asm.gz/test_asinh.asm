# case: test_asinh[in_shape0]
