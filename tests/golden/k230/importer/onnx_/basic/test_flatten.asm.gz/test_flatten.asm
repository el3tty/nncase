# case: test_flatten[1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 864
mmu_conf x1, x2, 1
addi x3, x0, 880
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 901
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 903
mmu_conf x7, x6, 4
addi x8, x0, 905
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 2816
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 48
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x21, 65539
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x4, x19, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss6, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x1, x0, 216
dm_load_w_conf 0, 0, 3, 3, x1
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss7, pu
addi x2, x0, 24
ss_pack_stride x2, x4, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x4, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x9
ccr_clr 4
addi x5, x0, 42
dm_load_act0 0, 0, x26, x5, pu, 1
addi x7, x0, 46
ss_pack_stride x18, x7, x7, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x8, x0, 19
ss_pack_shape x9, x18, x8, x7, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x18, x8, x7, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x8, x7, ss5
pu_of_conf1 0, 0, x18, x0, ss5
ss_pack_shape x9, x18, x8, x7, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x18, x4, x19, ss6
lui x11, 65540
addi x11, x11, 2448
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_shape x9, x18, x8, x7, ss2
lui x13, 65536
addi x13, x13, 1748
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
addi x14, x0, 10
ss_pack_shape x9, x18, x14, x19, ss3
ccr_decl x9
ccr_clr 2
lui x16, 65540
addi x16, x16, 3360
dm_load_l1 0, 0, x16, x0, ss3, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
ss_pack_stride x2, x14, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x18, x14, x19, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x26, x5, pu, 1
addi x10, x0, 8
ss_pack_shape x9, x18, x10, x7, ss4
ccr_decl x9
ccr_set 0, 1
lui x20, 65537
addi x20, x20, 3496
dm_store_of 0, 0, x20, ss4, pu
ss_pack_shape x9, x18, x10, x7, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x10, x7, ss1
pu_of_conf1 0, 0, x18, x0, ss1
ss_pack_shape x9, x18, x10, x7, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x15, 2
addi x15, x15, 2252
ss_pack_stride x9, x9, x15, ss5
ss_pack_stride x9, x9, x15, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss6
ccr_decl x9
ccr_clr 0
lw x24, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x24, x22
l2_store x22, x12, ss6
end x0
# case: test_flatten[2-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 864
mmu_conf x1, x2, 1
addi x3, x0, 880
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 901
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 903
mmu_conf x7, x6, 4
addi x8, x0, 905
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 2816
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 48
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x21, 65539
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x4, x19, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss6, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x1, x0, 216
dm_load_w_conf 0, 0, 3, 3, x1
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss7, pu
addi x2, x0, 24
ss_pack_stride x2, x4, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x4, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x9
ccr_clr 4
addi x5, x0, 42
dm_load_act0 0, 0, x26, x5, pu, 1
addi x7, x0, 46
ss_pack_stride x18, x7, x7, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x8, x0, 19
ss_pack_shape x9, x18, x8, x7, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x18, x8, x7, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x8, x7, ss5
pu_of_conf1 0, 0, x18, x0, ss5
ss_pack_shape x9, x18, x8, x7, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x18, x4, x19, ss6
lui x11, 65540
addi x11, x11, 2448
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_shape x9, x18, x8, x7, ss2
lui x13, 65536
addi x13, x13, 1748
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
addi x14, x0, 10
ss_pack_shape x9, x18, x14, x19, ss3
ccr_decl x9
ccr_clr 2
lui x16, 65540
addi x16, x16, 3360
dm_load_l1 0, 0, x16, x0, ss3, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
ss_pack_stride x2, x14, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x18, x14, x19, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x26, x5, pu, 1
addi x10, x0, 8
ss_pack_shape x9, x18, x10, x7, ss4
ccr_decl x9
ccr_set 0, 1
lui x20, 65537
addi x20, x20, 3496
dm_store_of 0, 0, x20, ss4, pu
ss_pack_shape x9, x18, x10, x7, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x10, x7, ss1
pu_of_conf1 0, 0, x18, x0, ss1
ss_pack_shape x9, x18, x10, x7, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x15, 2
addi x15, x15, 2252
ss_pack_stride x9, x9, x15, ss5
ss_pack_stride x9, x9, x15, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss6
ccr_decl x9
ccr_clr 0
lw x24, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x24, x22
l2_store x22, x12, ss6
end x0
# case: test_flatten[3-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 864
mmu_conf x1, x2, 1
addi x3, x0, 880
addi x4, x0, 21
mmu_conf x3, x4, 2
addi x5, x0, 901
addi x6, x0, 2
mmu_conf x5, x6, 3
addi x7, x0, 903
mmu_conf x7, x6, 4
addi x8, x0, 905
addi x9, x0, 1
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 2816
ss_pack_stride x9, x9, x10, ss0
ss_pack_stride x9, x9, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x9, x9, x9, x10, ss2
ccr_decl x9
ccr_set 0, 1
lw x13, x0, 0
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 262144
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 3
addi x19, x0, 48
ss_pack_stride x18, x19, x19, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x18, x19, x19, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x9, x9, 0, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_src2 x9, ss5, 0, l2
mfu_act1_conf_src1 x9, x9, x9, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x9, ss4, 1, l2
ss_pack_shape x9, x18, x19, x19, ss5
mfu_act1_conf_dest x10, ss5
lui x20, 4
addi x20, x20, 3072
mfu_act1_conf_deq x20, x0, disable, 0
mfu_act1_conf_deq x20, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x18
ccr_clr 0
ccr_clr 1
ccr_set 2, 2
lui x21, 65539
addi x21, x21, 1536
mfu_act1_compute x21, x12, x0, x15
l2_load_w_conf x18, x18, i8, i8, 0
ccr_decl x9
ccr_set 3, 1
lw x24, x0, 8
addi x22, x0, 42
add x22, x24, x22
lui x23, 327680
addi x23, x23, 0
l2_load_w x23, x22, x6
l2_load_w_conf x4, x4, fp16, fp16, 0
ccr_decl x9
ccr_set 4, 1
lw x27, x0, 8
addi x25, x0, 45
add x25, x27, x25
lui x26, 196608
addi x26, x26, 0
l2_load_w x26, x25, x17
ss_pack_stride x18, x19, x19, ss3
dm_load_l1_conf 0, 0, ss3, i8, if_
ss_pack_shape x9, x18, x4, x19, ss6
ccr_decl x9
ccr_clr 2
dm_load_l1 0, 0, x21, x0, ss6, if_
addi x28, x0, 81
l2_load_w_conf x28, x28, i8, i8, 0
ccr_decl x9
ccr_set 5, 1
lw x31, x0, 8
addi x29, x0, 87
add x29, x31, x29
lui x30, 131072
addi x30, x30, 0
l2_load_w x30, x29, x6
addi x1, x0, 216
dm_load_w_conf 0, 0, 3, 3, x1
dm_load_w_conf2 0, 0, x9, x18
pu_w_conf 0, 0, 3, 3
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x18, x18, ss7
ccr_decl x6
ccr_clr 5
ccr_clr 3
dm_load_w 0, 0, x30, x23, ss7, pu
addi x2, x0, 24
ss_pack_stride x2, x4, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x18, x0
ss_pack_shape x9, x18, x4, x19, ss6
pu_fetchif_conf3 0, 0, x0, x9, ss6
ss_pack_shape x0, x0, x0, x0, ss4
pu_fetchif_conf4 0, 0, x0, ss4
addi x3, x0, 31
pu_fetchif_conf_deq 0, 0, x3, x0, u8
ccr_decl x9
ccr_clr 4
addi x5, x0, 42
dm_load_act0 0, 0, x26, x5, pu, 1
addi x7, x0, 46
ss_pack_stride x18, x7, x7, ss1
dm_store_of_conf 0, 0, ss1, fp16
addi x8, x0, 19
ss_pack_shape x9, x18, x8, x7, ss2
dm_store_of 0, 0, x12, ss2, pu
ss_pack_shape x9, x18, x8, x7, ss2
act0_src1_conf 0, 0, pu, ss2, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x8, x7, ss5
pu_of_conf1 0, 0, x18, x0, ss5
ss_pack_shape x9, x18, x8, x7, ss2
pu_of_conf2 0, 0, x0, ss2
pu_compute_conf 0, 0, 0, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_shape x9, x18, x4, x19, ss6
lui x11, 65540
addi x11, x11, 2448
dm_load_l1 0, 0, x11, x0, ss6, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
dm_load_act0 0, 0, x26, x5, pu, 1
ss_pack_shape x9, x18, x8, x7, ss2
lui x13, 65536
addi x13, x13, 1748
dm_store_of 0, 0, x13, ss2, pu
act0_compute x0, 0, pu, dm, fp16, 1
pu_compute 0, none
addi x14, x0, 10
ss_pack_shape x9, x18, x14, x19, ss3
ccr_decl x9
ccr_clr 2
lui x16, 65540
addi x16, x16, 3360
dm_load_l1 0, 0, x16, x0, ss3, if_
ss_pack_stride x0, x18, x18, ss7
dm_load_w 0, 0, x30, x23, ss7, pu
ss_pack_stride x2, x14, x19, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
ss_pack_shape x9, x18, x14, x19, ss3
pu_fetchif_conf3 0, 0, x0, x9, ss3
dm_load_act0 0, 0, x26, x5, pu, 1
addi x10, x0, 8
ss_pack_shape x9, x18, x10, x7, ss4
ccr_decl x9
ccr_set 0, 1
lui x20, 65537
addi x20, x20, 3496
dm_store_of 0, 0, x20, ss4, pu
ss_pack_shape x9, x18, x10, x7, ss4
act0_src1_conf 0, 0, pu, ss4, 30
act0_compute x0, 0, pu, dm, fp16, 1
ss_pack_stride x18, x10, x7, ss1
pu_of_conf1 0, 0, x18, x0, ss1
ss_pack_shape x9, x18, x10, x7, ss4
pu_of_conf2 0, 0, x0, ss4
pu_compute 0, none
lui x15, 2
addi x15, x15, 2252
ss_pack_stride x9, x9, x15, ss5
ss_pack_stride x9, x9, x15, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x9, x9, x9, x15, ss6
ccr_decl x9
ccr_clr 0
lw x24, x0, 4
lui x22, 0
addi x22, x22, 0
add x22, x24, x22
l2_store x22, x12, ss6
end x0
