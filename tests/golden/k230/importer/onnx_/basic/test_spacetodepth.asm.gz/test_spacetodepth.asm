# case: test_spacetodepth[2-in_shape0]
# case: test_spacetodepth[4-in_shape0]
