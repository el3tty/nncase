# case: test_scatter_nd[in_shape0-indices0-updates_shape0]
# case: test_scatter_nd[in_shape1-indices1-updates_shape1]
# case: test_scatter_nd[in_shape2-indices2-updates_shape2]
