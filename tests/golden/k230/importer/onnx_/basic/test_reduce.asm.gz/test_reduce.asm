# case: test_reduce[1-0-axes0-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes0-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes0-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes0-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes0-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes1-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes1-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes10-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes10-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes11-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes11-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes2-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes2-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes3-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes3-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes4-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes4-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes5-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes5-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3075
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[1-0-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3953
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3046
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes6-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 3975
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes6-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[1-0-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3957
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3035
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes7-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 3951
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-0-axes7-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes8-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes8-ReduceSum-10-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[1-0-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[1-0-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[1-0-axes9-ReduceProd-10-in_shape0]
# case: test_reduce[1-0-axes9-ReduceSum-1-in_shape0]
# case: test_reduce[1-0-axes9-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes0-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[1-None-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes0-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3083
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes0-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2124
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes0-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 5
addi x23, x23, 1406
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes0-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes1-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes1-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes10-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes10-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes11-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes11-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes2-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes2-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes3-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes3-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes4-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes4-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes5-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[1-None-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes5-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3144
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes5-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2105
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes5-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 5
addi x23, x23, 1434
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[1-None-axes5-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[1-None-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 4033
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3053
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes6-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 3944
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes6-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[1-None-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3991
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3039
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes7-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 3975
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[1-None-axes7-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes8-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes8-ReduceSum-10-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[1-None-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[1-None-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[1-None-axes9-ReduceProd-10-in_shape0]
# case: test_reduce[1-None-axes9-ReduceSum-1-in_shape0]
# case: test_reduce[1-None-axes9-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes0-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes0-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes1-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes1-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes10-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes10-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes11-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes11-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes2-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes2-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes3-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes3-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes4-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes4-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes5-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes5-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[11-0-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3994
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3032
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes6-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 4011
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes6-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[11-0-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3968
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3034
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes7-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 4020
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-0-axes7-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes8-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes8-ReduceSum-10-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[11-0-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[11-0-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[11-0-axes9-ReduceProd-10-in_shape0]
# case: test_reduce[11-0-axes9-ReduceSum-1-in_shape0]
# case: test_reduce[11-0-axes9-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes0-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[11-None-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes0-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3174
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes0-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2124
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes0-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 5
addi x23, x23, 1462
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes0-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes1-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes1-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes10-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes10-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes11-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes11-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes2-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes2-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes3-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes3-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes4-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes4-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes5-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[11-None-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes5-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3136
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes5-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2115
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes5-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, sum, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 5
addi x23, x23, 1428
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[11-None-axes5-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[11-None-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3979
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3037
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes6-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 3928
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes6-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3075
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[11-None-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3979
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3035
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes7-ReduceSum-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, sum, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 4
addi x23, x23, 4031
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[11-None-axes7-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes8-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes8-ReduceSum-10-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[11-None-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[11-None-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[11-None-axes9-ReduceProd-10-in_shape0]
# case: test_reduce[11-None-axes9-ReduceSum-1-in_shape0]
# case: test_reduce[11-None-axes9-ReduceSum-10-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[13-0-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3990
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-0-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3045
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-0-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[13-0-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3075
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3902
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-0-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3049
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-0-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[13-0-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[13-0-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[13-0-axes9-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes0-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[13-None-axes0-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes0-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3113
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[13-None-axes0-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes0-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2068
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[13-None-axes0-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes0-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes0-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes1-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes1-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes1-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes10-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes10-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes10-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes11-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes11-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes11-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes2-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes2-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes2-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes3-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes3-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes3-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes4-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes4-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes4-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes5-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, max, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x1, x1, x0, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x20, ss3
end x0
# case: test_reduce[13-None-axes5-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes5-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, average, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3128
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[13-None-axes5-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes5-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 512
mmu_conf x1, x2, 1
addi x3, x0, 528
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 530
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 531
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65538
addi x20, x20, 0
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x1, x6, x18, ss7
mfu_transpose_conf ss7, ss5, i8, HWNC
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_transpose x10, x20, ss6
ss_pack_stride x1, x6, x18, ss7
ss_pack_stride x1, x6, x1, ss0
mfu_pdp1_conf1 1, 1, ss7, min, ss0
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x1, x1, x21, ss4
mfu_pdp1_conf4 x17, x6, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 2100
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x1, x1, x6, x17, ss1
ccr_decl x4
ccr_clr 0
ccr_set 2, 1
mfu_pdp1_compute x20, x10, ss1
ss_pack_stride x1, x6, x1, ss0
ss_pack_stride x1, x6, x6, ss2
l2_store_conf ss2, ss0, fp16, fp32
ss_pack_shape x1, x1, x6, x6, ss3
ccr_decl x6
ccr_clr 2
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x20, ss3
end x0
# case: test_reduce[13-None-axes5-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes5-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes5-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes6-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3064
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[13-None-axes6-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes6-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3995
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-None-axes6-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes6-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3031
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-None-axes6-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes6-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes6-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes7-ReduceMax-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, max, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
mfu_pdp1_conf3 x6, x6, x0, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x21, 2
addi x21, x21, 3076
mfu_pdp1_conf_deq x21, x0, u8
lui x22, 6
addi x22, x22, 3065
mfu_pdp1_conf_quant x22, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x24, x0, 4
lui x23, 0
addi x23, x23, 0
add x23, x24, x23
l2_store x23, x10, ss1
end x0
# case: test_reduce[13-None-axes7-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes7-ReduceMean-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, average, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 0
addi x21, x21, 3584
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 3076
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 4013
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-None-axes7-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes7-ReduceMin-1-in_shape0]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 96
mmu_conf x1, x2, 1
addi x3, x0, 112
addi x4, x0, 2
mmu_conf x3, x4, 2
addi x5, x0, 114
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 115
mmu_conf x7, x6, 4
addi x8, x0, 768
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 0
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 21
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 8
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 0
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 3
ss_pack_stride x17, x1, x1, ss3
ss_pack_stride x0, x0, x0, ss4
addi x18, x0, 32
ss_pack_stride x17, x1, x18, ss5
mfu_act1_conf_stride ss3, ss4, ss5
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x17, x1, x1, ss6
mfu_act1_conf_dest x8, ss6
lui x19, 4
addi x19, x19, 3072
mfu_act1_conf_deq x19, x0, disable, 0
mfu_act1_conf_deq x19, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x17
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x20, 65536
addi x20, x20, 1536
mfu_act1_compute x20, x10, x0, x14
ss_pack_stride x17, x1, x18, ss5
ss_pack_stride x17, x6, x1, ss7
mfu_pdp1_conf1 1, 1, ss5, min, ss7
mfu_pdp1_conf2 x6, x6, x1, x1
ss_pack_shape x0, x0, x0, x0, ss4
lui x21, 6
addi x21, x21, 3064
mfu_pdp1_conf3 x6, x6, x21, ss4
mfu_pdp1_conf4 x1, x1, x19, 0, 0
lui x22, 2
addi x22, x22, 4
mfu_pdp1_conf_deq x22, x0, u8
lui x23, 6
addi x23, x23, 3028
mfu_pdp1_conf_quant x23, x0, disable
ss_pack_shape x6, x17, x1, x1, ss6
ccr_decl x4
ccr_clr 2
ccr_set 0, 1
mfu_pdp1_compute x10, x20, ss6
ss_pack_stride x17, x6, x1, ss7
ss_pack_stride x17, x6, x6, ss0
l2_store_conf ss0, ss7, fp16, fp32
ss_pack_shape x6, x17, x6, x6, ss1
ccr_decl x6
ccr_clr 0
lw x25, x0, 4
lui x24, 0
addi x24, x24, 0
add x24, x25, x24
l2_store x24, x10, ss1
end x0
# case: test_reduce[13-None-axes7-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes7-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes7-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes8-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes8-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes8-ReduceProd-10-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMax-1-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMax-10-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMean-1-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMean-10-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMin-1-in_shape0]
# case: test_reduce[13-None-axes9-ReduceMin-10-in_shape0]
# case: test_reduce[13-None-axes9-ReduceProd-1-in_shape0]
# case: test_reduce[13-None-axes9-ReduceProd-10-in_shape0]
