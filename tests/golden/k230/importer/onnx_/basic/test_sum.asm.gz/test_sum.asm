# case: test_sum[in_shape0]
# case: test_sum[in_shape1]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 9
mmu_conf x1, x2, 1
addi x3, x0, 25
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 28
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 29
mmu_conf x7, x6, 4
ss_pack_stride x6, x6, x6, ss0
ss_pack_stride x6, x6, x6, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x6, ss2
ccr_decl x6
ccr_set 0, 1
lw x10, x0, 4
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x14, x0, 12
lui x12, 0
addi x12, x12, 0
add x12, x14, x12
lui x13, 131072
addi x13, x13, 64
addi x15, x0, 23
l2_load_w x13, x12, x15
ss_pack_stride x6, x6, x6, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x6, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x6, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x6, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x6, ss2
mfu_act1_conf_dest x6, ss2
lui x16, 4
addi x16, x16, 3072
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x17, 65536
addi x17, x17, 96
mfu_act1_compute x17, x9, x0, x13
addi x18, x0, 48
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x6, x18, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss6
ccr_decl x6
ccr_set 3, 1
lw x21, x0, 0
lui x19, 0
addi x19, x19, 0
add x19, x21, x19
lui x20, 65536
addi x20, x20, 192
l2_load x20, x19, ss6
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x24, x0, 12
addi x22, x0, 14
add x22, x24, x22
lui x23, 131072
addi x23, x23, 32
l2_load_w x23, x22, x15
ss_pack_stride x6, x6, x18, ss5
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x18, ss5
mfu_act1_conf_stride ss5, ss3, ss5
mfu_act1_conf_src1 x18, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x18, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x18, ss6
mfu_act1_conf_dest x18, ss6
mfu_act1_conf_deq x16, x0, disable, 0
mfu_act1_conf_deq x16, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x9, x20, x0, x23
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x27, x0, 12
addi x25, x0, 28
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load_w x26, x25, x15
ss_pack_stride x6, x6, x18, ss5
ss_pack_stride x6, x6, x6, ss1
ss_pack_stride x6, x6, x18, ss5
mfu_act1_conf_stride ss5, ss1, ss5
mfu_act1_conf_src1 x18, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x18, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x6, ss2
mfu_act1_conf_src2 x18, ss2, 1, l2
ss_pack_shape x6, x6, x6, x18, ss6
mfu_act1_conf_dest x18, ss6
lui x28, 2
addi x28, x28, 3074
mfu_act1_conf_deq x28, x0, u8, 0
lui x29, 2
addi x29, x29, 2945
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x20, x9, x17, x26
ss_pack_stride x6, x6, x18, ss5
ss_pack_stride x6, x6, x18, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss6
ccr_decl x6
ccr_clr 3
lw x1, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x20, ss6
end x0
# case: test_sum[in_shape2]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 9
mmu_conf x1, x2, 1
addi x3, x0, 25
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 28
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 29
mmu_conf x7, x6, 4
addi x8, x0, 48
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x8, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_dest x8, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65536
addi x18, x18, 96
mfu_act1_compute x18, x10, x0, x14
ss_pack_stride x6, x6, x6, ss4
ss_pack_stride x6, x6, x6, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x6, ss6
ccr_decl x6
ccr_set 3, 1
lw x21, x0, 0
lui x19, 0
addi x19, x19, 0
add x19, x21, x19
lui x20, 65536
addi x20, x20, 192
l2_load x20, x19, ss6
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x24, x0, 12
addi x22, x0, 14
add x22, x24, x22
lui x23, 131072
addi x23, x23, 32
l2_load_w x23, x22, x16
ss_pack_stride x6, x6, x6, ss5
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x6, ss5
mfu_act1_conf_stride ss5, ss3, ss5
mfu_act1_conf_src1 x6, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x6, ss6
mfu_act1_conf_src2 x6, ss6, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x6, ss6
mfu_act1_conf_dest x6, ss6
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x20, x0, x23
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x27, x0, 12
addi x25, x0, 28
add x25, x27, x25
lui x26, 131072
addi x26, x26, 0
l2_load_w x26, x25, x16
ss_pack_stride x6, x6, x6, ss5
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
mfu_act1_conf_stride ss5, ss1, ss1
mfu_act1_conf_src1 x6, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x6, ss6
mfu_act1_conf_src2 x8, ss6, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_src2 x6, ss2, 1, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_dest x8, ss2
lui x28, 2
addi x28, x28, 2922
mfu_act1_conf_deq x28, x0, u8, 0
lui x29, 2
addi x29, x29, 3074
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x20, x10, x18, x26
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x1, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x20, ss2
end x0
# case: test_sum[in_shape3]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 448
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 451
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 452
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2304
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 48
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65537
addi x19, x19, 512
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss6
l2_load_conf ss6, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65538
addi x21, x21, 1024
l2_load x21, x20, ss2
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
lui x23, 0
addi x23, x23, 0
add x23, x25, x23
lui x24, 131072
addi x24, x24, 32
l2_load_w x24, x23, x16
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 14
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss3, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
mfu_act1_conf_deq x29, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x30, x0, 4
ccr_decl x30
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss6
ss_pack_stride x6, x6, x8, ss6
l2_store_conf ss6, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x1, x0, 8
lui x31, 0
addi x31, x31, 0
add x31, x1, x31
l2_store x31, x21, ss2
end x0
# case: test_sum[in_shape4]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 448
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 451
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 452
mmu_conf x7, x6, 4
addi x8, x0, 48
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x6, x8, ss1
mfu_act1_conf_stride ss1, ss3, ss1
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_src2 x6, ss2, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_dest x8, ss2
lui x17, 4
addi x17, x17, 3072
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x18, 65537
addi x18, x18, 512
mfu_act1_compute x18, x10, x0, x14
lui x19, 1
addi x19, x19, 2304
ss_pack_stride x6, x6, x19, ss4
ss_pack_stride x6, x6, x19, ss5
l2_load_conf ss5, ss4, fp16, fp32
ss_pack_shape x6, x6, x6, x19, ss6
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65538
addi x21, x21, 1024
l2_load x21, x20, ss6
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 14
add x23, x25, x23
lui x24, 131072
addi x24, x24, 32
l2_load_w x24, x23, x16
ss_pack_stride x6, x8, x8, ss7
ss_pack_stride x0, x0, x0, ss3
ss_pack_stride x6, x8, x8, ss7
mfu_act1_conf_stride ss7, ss3, ss7
mfu_act1_conf_src1 x19, x6, x6, 0, l2
ss_pack_shape x6, x6, x8, x8, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss3
mfu_act1_conf_src2 x6, ss3, 1, l2
ss_pack_shape x6, x6, x8, x8, ss0
mfu_act1_conf_dest x19, ss0
mfu_act1_conf_deq x17, x0, disable, 0
mfu_act1_conf_deq x17, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 28
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x6, x8, x8, ss7
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x8, x8, ss7
mfu_act1_conf_stride ss7, ss1, ss7
mfu_act1_conf_src1 x19, x6, x6, 0, l2
ss_pack_shape x6, x6, x8, x8, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x8, ss2
mfu_act1_conf_src2 x8, ss2, 1, l2
ss_pack_shape x6, x6, x8, x8, ss0
mfu_act1_conf_dest x19, ss0
lui x29, 2
addi x29, x29, 3076
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3033
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x18, x27
ss_pack_stride x6, x6, x19, ss5
ss_pack_stride x6, x6, x19, ss5
l2_store_conf ss5, ss5, fp16, fp32
ss_pack_shape x6, x6, x6, x19, ss6
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x21, ss6
end x0
# case: test_sum[in_shape5]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 448
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 451
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 452
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2304
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
lui x13, 0
addi x13, x13, 0
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 48
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65537
addi x19, x19, 512
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x17, ss6
ss_pack_stride x6, x6, x17, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x17, ss0
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65538
addi x21, x21, 1024
l2_load x21, x20, ss0
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 14
add x23, x25, x23
lui x24, 131072
addi x24, x24, 32
l2_load_w x24, x23, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x6, x17, ss7
mfu_act1_conf_stride ss7, ss4, ss7
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_dest x17, ss0
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 28
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss7, ss3, ss3
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x17, ss0, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3075
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x21, ss2
end x0
# case: test_sum[in_shape6]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 864
mmu_conf x1, x2, 1
addi x3, x0, 880
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 976
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 980
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 981
mmu_conf x9, x8, 5
lui x10, 2
addi x10, x10, 2816
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 48
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65539
addi x22, x22, 1536
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
lui x26, 1
addi x26, x26, 2304
ss_pack_stride x8, x8, x26, ss6
ss_pack_stride x8, x8, x26, ss7
l2_load_conf ss7, ss6, i8, i8
ss_pack_shape x8, x8, x8, x26, ss0
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 0
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss0
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x8, x20, x20, ss1
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x26, x8, x8, 1, l2
ss_pack_shape x8, x8, x20, x20, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
lui x31, 2
addi x31, x31, 4086
mfu_act1_conf_deq x31, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x28, x24
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x12, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 448
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 451
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 452
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2304
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
addi x13, x0, 84
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 48
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65537
addi x19, x19, 512
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x17, ss6
ss_pack_stride x6, x6, x17, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x17, ss0
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65538
addi x21, x21, 1024
l2_load x21, x20, ss0
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 98
add x23, x25, x23
lui x24, 131072
addi x24, x24, 32
l2_load_w x24, x23, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x6, x17, ss7
mfu_act1_conf_stride ss7, ss4, ss7
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_dest x17, ss0
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 112
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss7, ss3, ss3
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x17, ss0, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3071
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x21, ss2
end x0
# case: test_sum[in_shape7]
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 864
mmu_conf x1, x2, 1
addi x3, x0, 880
addi x4, x0, 96
mmu_conf x3, x4, 2
addi x5, x0, 976
addi x6, x0, 4
mmu_conf x5, x6, 3
addi x7, x0, 980
addi x8, x0, 1
mmu_conf x7, x8, 4
addi x9, x0, 981
mmu_conf x9, x8, 5
lui x10, 2
addi x10, x10, 2816
ss_pack_stride x8, x8, x10, ss0
ss_pack_stride x8, x8, x10, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss2
ccr_decl x8
ccr_set 0, 1
lw x13, x0, 4
lui x11, 0
addi x11, x11, 0
add x11, x13, x11
lui x12, 65536
addi x12, x12, 0
l2_load x12, x11, ss2
addi x14, x0, 21
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x17, x0, 12
lui x15, 0
addi x15, x15, 0
add x15, x17, x15
lui x16, 196608
addi x16, x16, 64
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 3
addi x20, x0, 48
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x8, x8, x8, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x8, ss4, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x21, 4
addi x21, x21, 3072
mfu_act1_conf_deq x21, x0, disable, 0
mfu_act1_conf_deq x21, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x19
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x22, 65539
addi x22, x22, 1536
mfu_act1_compute x22, x12, x0, x16
l2_load_w_conf x14, x14, fp16, fp16, 0
ccr_decl x8
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 42
add x23, x25, x23
lui x24, 196608
addi x24, x24, 0
l2_load_w x24, x23, x18
lui x26, 1
addi x26, x26, 2304
ss_pack_stride x8, x8, x26, ss6
ss_pack_stride x8, x8, x26, ss7
l2_load_conf ss7, ss6, i8, i8
ss_pack_shape x8, x8, x8, x26, ss0
ccr_decl x8
ccr_set 3, 1
lw x29, x0, 0
lui x27, 0
addi x27, x27, 0
add x27, x29, x27
lui x28, 131072
addi x28, x28, 0
l2_load x28, x27, ss0
ss_pack_stride x19, x20, x20, ss3
ss_pack_stride x8, x20, x20, ss1
ss_pack_stride x19, x20, x20, ss3
mfu_act1_conf_stride ss3, ss1, ss3
mfu_act1_conf_src1 x10, x8, x8, 0, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_src2 x8, ss5, 0, l2
mfu_act1_conf_src1 x26, x8, x8, 1, l2
ss_pack_shape x8, x8, x20, x20, ss2
mfu_act1_conf_src2 x19, ss2, 1, l2
ss_pack_shape x8, x19, x20, x20, ss5
mfu_act1_conf_dest x10, ss5
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 0
lui x31, 2
addi x31, x31, 4093
mfu_act1_conf_deq x31, x0, u8, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
ccr_decl x6
ccr_clr 2
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x12, x22, x28, x24
ss_pack_stride x8, x8, x10, ss4
ss_pack_stride x8, x8, x10, ss4
l2_store_conf ss4, ss4, fp16, fp32
ss_pack_shape x8, x8, x8, x10, ss6
ccr_decl x8
ccr_clr 0
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x12, ss6
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 432
mmu_conf x1, x2, 1
addi x3, x0, 448
addi x4, x0, 3
mmu_conf x3, x4, 2
addi x5, x0, 451
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 452
mmu_conf x7, x6, 4
lui x8, 1
addi x8, x8, 2304
ss_pack_stride x6, x6, x8, ss0
ss_pack_stride x6, x6, x8, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_set 0, 1
lw x11, x0, 4
lui x9, 0
addi x9, x9, 0
add x9, x11, x9
lui x10, 65536
addi x10, x10, 0
l2_load x10, x9, ss2
addi x12, x0, 7
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x15, x0, 12
addi x13, x0, 84
add x13, x15, x13
lui x14, 131072
addi x14, x14, 64
addi x16, x0, 23
l2_load_w x14, x13, x16
addi x17, x0, 48
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x8, x6, x6, 0, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65537
addi x19, x19, 512
mfu_act1_compute x19, x10, x0, x14
ss_pack_stride x6, x6, x17, ss6
ss_pack_stride x6, x6, x17, ss7
l2_load_conf ss7, ss6, fp16, fp32
ss_pack_shape x6, x6, x6, x17, ss0
ccr_decl x6
ccr_set 3, 1
lw x22, x0, 0
lui x20, 0
addi x20, x20, 0
add x20, x22, x20
lui x21, 65538
addi x21, x21, 1024
l2_load x21, x20, ss0
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x25, x0, 12
addi x23, x0, 98
add x23, x25, x23
lui x24, 131072
addi x24, x24, 32
l2_load_w x24, x23, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x6, x6, x17, ss7
mfu_act1_conf_stride ss7, ss4, ss7
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x6, ss0, 0, l2
mfu_act1_conf_src1 x6, x6, x6, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x6, ss4, 1, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_dest x17, ss0
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
ccr_decl x4
ccr_clr 3
ccr_clr 1
ccr_set 0, 1
mfu_act1_compute x10, x21, x0, x24
l2_load_w_conf x12, x12, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x28, x0, 12
addi x26, x0, 112
add x26, x28, x26
lui x27, 131072
addi x27, x27, 0
l2_load_w x27, x26, x16
ss_pack_stride x6, x6, x17, ss7
ss_pack_stride x6, x17, x17, ss3
ss_pack_stride x6, x17, x17, ss3
mfu_act1_conf_stride ss7, ss3, ss3
mfu_act1_conf_src1 x17, x6, x6, 0, l2
ss_pack_shape x6, x6, x6, x17, ss0
mfu_act1_conf_src2 x17, ss0, 0, l2
mfu_act1_conf_src1 x8, x6, x6, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_src2 x6, ss5, 1, l2
ss_pack_shape x6, x6, x17, x17, ss5
mfu_act1_conf_dest x8, ss5
lui x29, 2
addi x29, x29, 3075
mfu_act1_conf_deq x29, x0, u8, 0
lui x30, 2
addi x30, x30, 3076
mfu_act1_conf_deq x30, x0, u8, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x31, x0, 4
ccr_decl x31
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
mfu_act1_compute x21, x10, x19, x27
ss_pack_stride x6, x6, x8, ss1
ss_pack_stride x6, x6, x8, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x6, x6, x6, x8, ss2
ccr_decl x6
ccr_clr 3
lw x2, x0, 8
lui x1, 0
addi x1, x1, 0
add x1, x2, x1
l2_store x1, x21, ss2
end x0
