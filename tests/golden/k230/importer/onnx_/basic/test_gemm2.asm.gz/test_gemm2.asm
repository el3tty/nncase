# case: test_gemm2
# tile: k230/ptq TileLayerGroup_0
addi x1, x0, 16
mmu_conf x0, x1, 0
addi x2, x0, 784
mmu_conf x1, x2, 1
addi x3, x0, 800
addi x4, x0, 112
mmu_conf x3, x4, 2
addi x5, x0, 912
addi x6, x0, 1
mmu_conf x5, x6, 3
addi x7, x0, 913
mmu_conf x7, x6, 4
addi x8, x0, 914
mmu_conf x8, x6, 5
lui x9, 2
addi x9, x9, 2176
ss_pack_stride x6, x6, x9, ss0
ss_pack_stride x6, x6, x9, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_set 0, 1
lw x12, x0, 0
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
lui x11, 65536
addi x11, x11, 0
l2_load x11, x10, ss2
addi x13, x0, 7
l2_load_w_conf x13, x13, fp16, fp16, 0
ccr_decl x6
ccr_set 1, 1
lw x16, x0, 8
lui x14, 0
addi x14, x14, 0
add x14, x16, x14
lui x15, 196608
addi x15, x15, 0
addi x17, x0, 23
l2_load_w x15, x14, x17
addi x18, x0, 56
ss_pack_stride x6, x6, x18, ss3
ss_pack_stride x6, x6, x18, ss4
l2_load_conf ss4, ss3, fp16, fp32
ss_pack_shape x6, x6, x6, x18, ss5
ccr_decl x6
ccr_set 2, 1
lw x21, x0, 8
addi x19, x0, 14
add x19, x21, x19
lui x20, 131072
addi x20, x20, 0
l2_load x20, x19, ss5
ss_pack_stride x6, x4, x18, ss6
ss_pack_stride x6, x6, x18, ss4
ss_pack_stride x6, x4, x18, ss6
mfu_act1_conf_stride ss6, ss4, ss6
mfu_act1_conf_src1 x9, x6, x6, 0, l2
ss_pack_shape x6, x6, x4, x18, ss7
mfu_act1_conf_src2 x6, ss7, 0, l2
mfu_act1_conf_src1 x18, x6, x6, 1, l2
ss_pack_shape x6, x6, x6, x18, ss5
mfu_act1_conf_src2 x4, ss5, 1, l2
ss_pack_shape x6, x6, x4, x18, ss7
mfu_act1_conf_dest x9, ss7
lui x22, 3
addi x22, x22, 2039
addi x23, x0, 113
mfu_act1_conf_deq x22, x23, u8, 0
mfu_act1_conf_deq x22, x23, disable, 1
mfu_act1_conf_quant disable
mfu_act1_conf add, 1, 0
addi x25, x0, 4
ccr_decl x25
ccr_clr 0
ccr_clr 2
ccr_clr 1
ccr_set 3, 1
lui x24, 65539
addi x24, x24, 256
mfu_act1_compute x24, x11, x20, x15
ss_pack_stride x6, x6, x9, ss1
ss_pack_stride x6, x6, x9, ss1
l2_store_conf ss1, ss1, fp16, fp32
ss_pack_shape x6, x6, x6, x9, ss2
ccr_decl x6
ccr_clr 3
lw x27, x0, 4
lui x26, 0
addi x26, x26, 0
add x26, x27, x26
l2_store x26, x24, ss2
end x0
# tile: k230/ptq TileTransposeMatmul_0
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 2048
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 2064
mmu_conf x3, x2, 2
lui x4, 1
addi x4, x4, 16
addi x5, x0, 1568
mmu_conf x4, x5, 3
lui x6, 1
addi x6, x6, 1584
addi x7, x0, 1536
mmu_conf x6, x7, 4
lui x8, 2
addi x8, x8, 3120
addi x9, x0, 480
mmu_conf x8, x9, 5
lui x10, 2
addi x10, x10, 3600
addi x11, x0, 25
mmu_conf x10, x11, 6
lui x12, 2
addi x12, x12, 3625
addi x13, x0, 2
mmu_conf x12, x13, 7
addi x14, x0, 32
l2_load_w_conf x14, x14, i8, i8, 0
lw x17, x0, 8
addi x15, x0, 238
add x15, x17, x15
lui x16, 458752
addi x16, x16, 0
addi x18, x0, 23
l2_load_w x16, x15, x18
addi x19, x0, 24
l2_load_w_conf x19, x19, i8, i8, 0
lw x22, x0, 8
addi x20, x0, 270
add x20, x22, x20
lui x21, 458752
addi x21, x21, 32
l2_load_w x21, x20, x18
addi x23, x0, 392
l2_load_w_conf x23, x23, fp16, fp16, 0
lw x26, x0, 8
addi x24, x0, 294
add x24, x26, x24
lui x25, 393216
addi x25, x25, 0
l2_load_w x25, x24, x18
addi x27, x0, 1
addi x28, x0, 224
ss_pack_stride x27, x27, x28, ss0
lui x29, 6
addi x29, x29, 512
ss_pack_stride x27, x27, x29, ss1
l2_load_conf ss1, ss0, i8, i8
ss_pack_shape x27, x27, x27, x29, ss2
ccr_decl x27
ccr_set 0, 2
lw x1, x0, 0
lui x30, 0
addi x30, x30, 0
add x30, x1, x30
lui x31, 196608
addi x31, x31, 0
l2_load x31, x30, ss2
addi x3, x0, 768
l2_load_w_conf x3, x3, i8, i8, 0
ccr_decl x27
ccr_set 1, 1
lw x5, x0, 8
addi x2, x0, 1078
add x2, x5, x2
lui x4, 327680
addi x4, x4, 0
l2_load_w x4, x2, x18
dm_load_w_conf 0, 0, 1, 1, x19
dm_load_w_conf2 0, 0, x27, x14
pu_w_conf 0, 0, 1, 1
dm_load_w_conf_deq 0, 0, u8
ss_pack_stride x0, x19, x14, ss3
ccr_decl x27
ccr_clr 1
dm_load_w 0, 0, x4, x16, ss3, pu
addi x6, x0, 112
ss_pack_stride x27, x6, x28, ss4
addi x7, x0, 1024
ss_pack_stride x19, x27, x7, ss5
mfu_transpose_conf ss5, ss4, i8, NWCH
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x13
ccr_clr 0
ccr_set 2, 1
lui x8, 262144
addi x8, x8, 0
mfu_transpose x8, x31, ss6
ss_pack_stride x19, x27, x7, ss5
dm_load_l1_conf 0, 0, ss5, i8, if_
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss7, if_
ss_pack_stride x19, x27, x6, ss0
pu_fetchif_conf1 0, 0, 1, 1, ss0
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x27, x19, x27, x6, ss7
pu_fetchif_conf3 0, 0, x0, x27, ss7
ss_pack_shape x0, x0, x0, x0, ss1
pu_fetchif_conf4 0, 0, x0, ss1
addi x9, x0, 31
pu_fetchif_conf_deq 0, 0, x9, x0, u8
ss_pack_stride x14, x27, x6, ss2
pu_of_conf1 0, 0, x14, x0, ss2
ss_pack_shape x27, x14, x27, x6, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ccr_decl x27
ccr_set 3, 1
lw x12, x0, 8
addi x10, x0, 1846
add x10, x12, x10
lui x11, 327680
addi x11, x11, 768
l2_load_w x11, x10, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 3
dm_load_w 0, 0, x11, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 4, 1
lui x15, 262150
addi x15, x15, 0
lui x17, 196608
addi x17, x17, 24
mfu_transpose x15, x17, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss7, if_
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ccr_decl x27
ccr_set 1, 1
lw x22, x0, 8
lui x20, 1
addi x20, x20, 2614
add x20, x22, x20
lui x21, 327680
addi x21, x21, 1536
l2_load_w x21, x20, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 1
dm_load_w 0, 0, x21, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 2, 1
lui x23, 196608
addi x23, x23, 48
mfu_transpose x8, x23, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 3, 1
lw x26, x0, 8
lui x24, 1
addi x24, x24, 3382
add x24, x26, x24
lui x25, 327681
addi x25, x25, 2304
l2_load_w x25, x24, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 3
dm_load_w 0, 0, x25, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 4, 1
lui x29, 196608
addi x29, x29, 72
mfu_transpose x15, x29, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 1, 1
lw x3, x0, 8
lui x30, 1
addi x30, x30, 54
add x30, x3, x30
lui x1, 327681
addi x1, x1, 3072
l2_load_w x1, x30, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 1
dm_load_w 0, 0, x1, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 2, 1
lui x2, 196608
addi x2, x2, 96
mfu_transpose x8, x2, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 3, 1
lw x28, x0, 8
lui x5, 1
addi x5, x5, 822
add x5, x28, x5
lui x4, 327681
addi x4, x4, 3840
l2_load_w x4, x5, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 3
dm_load_w 0, 0, x4, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 4, 1
lui x31, 196608
addi x31, x31, 120
mfu_transpose x15, x31, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 1, 1
lw x9, x0, 8
lui x13, 1
addi x13, x13, 1590
add x13, x9, x13
lui x7, 327681
addi x7, x7, 512
l2_load_w x7, x13, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 1
dm_load_w 0, 0, x7, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 2, 1
lui x10, 196608
addi x10, x10, 144
mfu_transpose x8, x10, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 3, 1
lw x17, x0, 8
lui x12, 2
addi x12, x12, 2358
add x12, x17, x12
lui x11, 327681
addi x11, x11, 1280
l2_load_w x11, x12, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 3
dm_load_w 0, 0, x11, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 4, 1
lui x20, 196608
addi x20, x20, 168
mfu_transpose x15, x20, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss7, if_
pu_compute 0, none
ccr_decl x27
ccr_set 1, 1
lw x23, x0, 8
lui x22, 2
addi x22, x22, 3126
add x22, x23, x22
lui x21, 327682
addi x21, x21, 2048
l2_load_w x21, x22, x18
ss_pack_stride x0, x19, x14, ss4
ccr_decl x27
ccr_clr 1
dm_load_w 0, 0, x21, x16, ss4, pu
ss_pack_shape x27, x27, x6, x19, ss6
ccr_decl x27
ccr_set 2, 1
lui x24, 196608
addi x24, x24, 192
mfu_transpose x8, x24, ss6
ss_pack_shape x27, x19, x27, x6, ss7
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss7, if_
pu_compute 0, none
addi x26, x0, 256
l2_load_w_conf x26, x26, i8, i8, 0
ccr_decl x27
ccr_set 3, 1
lw x30, x0, 8
lui x25, 2
addi x25, x25, 3894
add x25, x30, x25
lui x29, 327682
addi x29, x29, 2816
addi x3, x0, 7
l2_load_w x29, x25, x3
addi x1, x0, 8
ss_pack_stride x0, x1, x14, ss5
ccr_decl x27
ccr_clr 3
dm_load_w 0, 0, x29, x16, ss5, pu
ss_pack_shape x27, x27, x6, x1, ss0
ccr_decl x27
ccr_set 4, 1
lui x2, 196608
addi x2, x2, 216
mfu_transpose x15, x2, ss0
ss_pack_shape x27, x1, x27, x6, ss1
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss1, if_
pu_fetchif_conf2 0, 0, x1, x0
ss_pack_shape x27, x1, x27, x6, ss1
pu_fetchif_conf3 0, 0, x0, x27, ss1
lui x5, 393216
addi x5, x5, 0
addi x28, x0, 448
dm_load_act0 0, 0, x5, x28, pu, 1
addi x4, x0, 1024
ss_pack_stride x14, x27, x4, ss2
dm_store_of_conf 0, 0, ss2, i8
ss_pack_shape x27, x14, x27, x6, ss3
ccr_decl x27
ccr_set 5, 1
lui x31, 65536
addi x31, x31, 0
dm_store_of 0, 0, x31, ss3, pu
ss_pack_shape x27, x14, x27, x6, ss3
act0_src1_conf 0, 0, pu, ss3, 27
act0_compute x0, 0, pu, dm, u8, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
ss_pack_stride x14, x27, x4, ss2
ss_pack_stride x27, x4, x14, ss4
mfu_transpose_conf ss4, ss2, i8, NHWC
ss_pack_shape x27, x14, x27, x6, ss3
addi x9, x0, 2
ccr_decl x9
ccr_clr 5
ccr_set 6, 1
lui x13, 131072
addi x13, x13, 0
mfu_transpose x13, x31, ss3
ss_pack_stride x27, x4, x14, ss4
addi x7, x0, 56
ss_pack_stride x27, x6, x7, ss6
l2_store_conf ss6, ss4, i8, i8
ss_pack_shape x27, x27, x6, x14, ss7
ccr_decl x27
ccr_clr 6
lw x12, x0, 4
lui x10, 0
addi x10, x10, 0
add x10, x12, x10
l2_store x10, x13, ss7
addi x17, x0, 576
l2_load_w_conf x17, x17, i8, i8, 0
ccr_decl x27
ccr_set 7, 1
lw x22, x0, 8
lui x11, 2
addi x11, x11, 54
add x11, x22, x11
lui x20, 327682
addi x20, x20, 3584
l2_load_w x20, x11, x18
dm_load_w_conf2 0, 0, x27, x19
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 7
lui x23, 458752
addi x23, x23, 32
dm_load_w 0, 0, x20, x23, ss5, pu
addi x21, x0, 224
ss_pack_stride x27, x6, x21, ss0
ss_pack_stride x19, x27, x4, ss1
mfu_transpose_conf ss1, ss0, i8, NWCH
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 2, 1
lui x24, 196608
addi x24, x24, 0
mfu_transpose x8, x24, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss3, if_
pu_fetchif_conf2 0, 0, x19, x0
ss_pack_shape x27, x19, x27, x6, ss3
pu_fetchif_conf3 0, 0, x0, x27, ss3
ss_pack_stride x19, x27, x6, ss4
pu_of_conf1 0, 0, x19, x0, ss4
ss_pack_shape x27, x19, x27, x6, ss3
pu_of_conf2 0, 0, x0, ss3
pu_compute_conf 0, 0, 0, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ccr_decl x27
ccr_set 8, 1
lw x30, x0, 8
lui x26, 2
addi x26, x26, 630
add x26, x30, x26
lui x25, 327682
addi x25, x25, 64
l2_load_w x25, x26, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 8
dm_load_w 0, 0, x25, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 4, 1
lui x3, 196608
addi x3, x3, 24
mfu_transpose x15, x3, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss3, if_
pu_compute_conf 0, 0, 1, 0, psum, 1, pu_mode_normal
pu_compute 0, none
ccr_decl x27
ccr_set 7, 1
lw x2, x0, 8
lui x29, 2
addi x29, x29, 1206
add x29, x2, x29
lui x16, 327682
addi x16, x16, 640
l2_load_w x16, x29, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 7
dm_load_w 0, 0, x16, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 2, 1
lui x1, 196608
addi x1, x1, 48
mfu_transpose x8, x1, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 8, 1
lw x31, x0, 8
lui x5, 2
addi x5, x5, 1782
add x5, x31, x5
lui x28, 327682
addi x28, x28, 1216
l2_load_w x28, x5, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 8
dm_load_w 0, 0, x28, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 4, 1
lui x9, 196608
addi x9, x9, 72
mfu_transpose x15, x9, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 7, 1
lw x13, x0, 8
lui x7, 3
addi x7, x7, 2358
add x7, x13, x7
lui x14, 327682
addi x14, x14, 1792
l2_load_w x14, x7, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 7
dm_load_w 0, 0, x14, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 2, 1
lui x10, 196608
addi x10, x10, 96
mfu_transpose x8, x10, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 8, 1
lw x11, x0, 8
lui x12, 3
addi x12, x12, 2934
add x12, x11, x12
lui x17, 327683
addi x17, x17, 2368
l2_load_w x17, x12, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 8
dm_load_w 0, 0, x17, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 4, 1
lui x22, 196608
addi x22, x22, 120
mfu_transpose x15, x22, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 7, 1
lw x4, x0, 8
lui x20, 3
addi x20, x20, 3510
add x20, x4, x20
lui x21, 327683
addi x21, x21, 2944
l2_load_w x21, x20, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 7
dm_load_w 0, 0, x21, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 2, 1
lui x24, 196608
addi x24, x24, 144
mfu_transpose x8, x24, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 8, 1
lw x25, x0, 8
lui x26, 3
addi x26, x26, 4086
add x26, x25, x26
lui x30, 327683
addi x30, x30, 3520
l2_load_w x30, x26, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 8
dm_load_w 0, 0, x30, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 4, 1
lui x3, 196608
addi x3, x3, 168
mfu_transpose x15, x3, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss3, if_
pu_compute 0, none
ccr_decl x27
ccr_set 7, 1
lw x16, x0, 8
lui x29, 3
addi x29, x29, 566
add x29, x16, x29
lui x2, 327683
addi x2, x2, 0
l2_load_w x2, x29, x18
ss_pack_stride x0, x19, x19, ss5
ccr_decl x27
ccr_clr 7
dm_load_w 0, 0, x2, x23, ss5, pu
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_set 2, 1
lui x1, 196608
addi x1, x1, 192
mfu_transpose x8, x1, ss2
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_clr 2
dm_load_l1 0, 0, x8, x0, ss3, if_
pu_compute 0, none
addi x5, x0, 192
l2_load_w_conf x5, x5, i8, i8, 0
ccr_decl x27
ccr_set 8, 1
lw x9, x0, 8
lui x31, 3
addi x31, x31, 1142
add x31, x9, x31
lui x28, 327683
addi x28, x28, 576
addi x7, x0, 7
l2_load_w x28, x31, x7
addi x13, x0, 8
ss_pack_stride x0, x13, x19, ss6
ccr_decl x27
ccr_clr 8
dm_load_w 0, 0, x28, x23, ss6, pu
ss_pack_shape x27, x27, x6, x13, ss7
addi x10, x0, 2
ccr_decl x10
ccr_clr 0
ccr_set 4, 1
lui x14, 196608
addi x14, x14, 216
mfu_transpose x15, x14, ss7
ss_pack_shape x27, x13, x27, x6, ss0
ccr_decl x27
ccr_clr 4
dm_load_l1 0, 0, x15, x0, ss0, if_
pu_fetchif_conf2 0, 0, x13, x0
ss_pack_shape x27, x13, x27, x6, ss0
pu_fetchif_conf3 0, 0, x0, x27, ss0
lui x12, 393216
addi x12, x12, 448
addi x11, x0, 336
dm_load_act0 0, 0, x12, x11, pu, 1
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x27
ccr_set 5, 1
lui x17, 65536
addi x17, x17, 0
dm_store_of 0, 0, x17, ss3, pu
ss_pack_shape x27, x19, x27, x6, ss3
act0_src1_conf 0, 0, pu, ss3, 27
act0_compute x0, 0, pu, dm, u8, 1
pu_compute_conf 0, 0, 1, 0, act0, 1, pu_mode_normal
pu_compute 0, none
addi x22, x0, 32
addi x20, x0, 1024
ss_pack_stride x22, x27, x20, ss1
ss_pack_stride x27, x20, x22, ss4
mfu_transpose_conf ss4, ss1, i8, NHWC
ss_pack_shape x27, x19, x27, x6, ss3
ccr_decl x10
ccr_clr 5
ccr_set 6, 1
lui x4, 131072
addi x4, x4, 0
mfu_transpose x4, x17, ss3
ss_pack_stride x27, x20, x22, ss4
addi x21, x0, 56
ss_pack_stride x27, x6, x21, ss5
l2_store_conf ss5, ss4, i8, i8
ss_pack_shape x27, x27, x6, x19, ss2
ccr_decl x27
ccr_clr 6
lw x26, x0, 4
addi x24, x0, 32
add x24, x26, x24
l2_store x24, x4, ss2
end x0
# tile: k230/ptq TileLayerGroup_1
addi x1, x0, 16
mmu_conf x0, x1, 0
lui x2, 1
addi x2, x2, 3136
mmu_conf x1, x2, 1
lui x3, 1
addi x3, x3, 3152
addi x4, x0, 1
mmu_conf x3, x4, 2
lui x5, 1
addi x5, x5, 3153
mmu_conf x5, x4, 3
lui x6, 1
addi x6, x6, 3154
mmu_conf x6, x4, 4
lui x7, 6
addi x7, x7, 512
ss_pack_stride x4, x4, x7, ss0
ss_pack_stride x4, x4, x7, ss1
l2_load_conf ss1, ss0, fp16, fp32
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_set 0, 1
lw x10, x0, 0
lui x8, 0
addi x8, x8, 0
add x8, x10, x8
lui x9, 65536
addi x9, x9, 0
l2_load x9, x8, ss2
addi x11, x0, 7
l2_load_w_conf x11, x11, fp16, fp16, 0
ccr_decl x4
ccr_set 1, 1
lw x14, x0, 8
lui x12, 3
addi x12, x12, 1334
add x12, x14, x12
lui x13, 131072
addi x13, x13, 0
addi x15, x0, 23
l2_load_w x13, x12, x15
addi x16, x0, 112
addi x17, x0, 224
ss_pack_stride x4, x16, x17, ss3
ss_pack_stride x0, x0, x0, ss4
ss_pack_stride x4, x16, x17, ss3
mfu_act1_conf_stride ss3, ss4, ss3
mfu_act1_conf_src1 x7, x4, x4, 0, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_src2 x4, ss5, 0, l2
mfu_act1_conf_src1 x4, x4, x4, 1, l2
ss_pack_shape x0, x0, x0, x0, ss4
mfu_act1_conf_src2 x4, ss4, 1, l2
ss_pack_shape x4, x4, x16, x17, ss5
mfu_act1_conf_dest x7, ss5
lui x18, 4
addi x18, x18, 3072
mfu_act1_conf_deq x18, x0, disable, 0
mfu_act1_conf_deq x18, x0, disable, 1
mfu_act1_conf_quant u8
mfu_act1_conf add, 1, 0
addi x20, x0, 3
ccr_decl x20
ccr_clr 0
ccr_clr 1
ccr_set 2, 1
lui x19, 65548
addi x19, x19, 1024
mfu_act1_compute x19, x9, x0, x13
ss_pack_stride x4, x4, x7, ss1
ss_pack_stride x4, x4, x7, ss1
l2_store_conf ss1, ss1, i8, i8
ss_pack_shape x4, x4, x4, x7, ss2
ccr_decl x4
ccr_clr 2
lw x22, x0, 4
lui x21, 0
addi x21, x21, 0
add x21, x22, x21
l2_store x21, x19, ss2
end x0
